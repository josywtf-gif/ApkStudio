package app.apkstudio;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import java.security.MessageDigest;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProjectActivity extends LogActivity {
    private File project;
    private String channel = ReleaseChannels.STABLE;
    private String versionNameExtra;
    private Linux linux;
    private final List<String> files = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private Button bBuild, bInstall;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        String projectName = getIntent().getStringExtra("name");
        String versionName = getIntent().getStringExtra("version");
        versionNameExtra = versionName;
        channel = ReleaseChannels.normalize(getIntent().getStringExtra("channel"));
        File container = new File(Util.projectsDir(this), projectName);
        File channelDir = ReleaseChannels.channelDir(container, channel);
        project = versionName == null ? channelDir : new File(channelDir, versionName);
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        root.addView(Ui.header(this, projectName, ReleaseChannels.title(channel).toUpperCase(), true, null));
        bBuild = new Button(this);
        bBuild.setText("Собрать"); Ui.button(bBuild, this, true);
        bInstall = new Button(this);
        bInstall.setText("Установить"); Ui.button(bInstall, this, false);
        bInstall.setEnabled(false);
        Button bAdd = new Button(this);
        bAdd.setText("+ Файл"); Ui.button(bAdd, this, false);
        Button bChanges = new Button(this);
        bChanges.setText("Изменения"); Ui.button(bChanges, this, false);
        Ui.add(root, Ui.row(this, bBuild, bInstall), this, 0);


        LinearLayout section = new LinearLayout(this);
        section.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView filesTitle = new TextView(this);
        filesTitle.setText("Файлы проекта");
        Ui.title(filesTitle, 16);
        section.addView(filesTitle, new LinearLayout.LayoutParams(0, -2, 1));
        bAdd.setMinHeight(0);
        bChanges.setMinHeight(0);
        section.addView(bChanges, new LinearLayout.LayoutParams(-2, dp(38)));
        section.addView(bAdd, new LinearLayout.LayoutParams(-2, dp(38)));
        Ui.add(root, section, this, 14);

        ListView list = new ListView(this);
        adapter = Ui.cardAdapter(this, files);
        list.setAdapter(adapter);
        Ui.styleList(list, this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
        lp.topMargin = dp(8);
        root.addView(list, lp);
        Ui.add(root, makeProgressView(), this, 8);
        setContentView(root);

        bBuild.setOnClickListener(v -> {
            if (Runner.get().isRunning() && Runner.get().owns(owner())) Runner.get().cancel();
            else build();
        });
        bInstall.setOnClickListener(v -> install());
        bAdd.setOnClickListener(v -> addFileDialog());
        bChanges.setOnClickListener(v -> {
            File f = new File(project, Versions.CHANGES);
            String text;
            try { text = f.isFile() ? Util.read(f) : "Для этой версии нет сравнения: она первая или добавлена без ZIP."; }
            catch (Exception e) { text = String.valueOf(e.getMessage()); }
            new AlertDialog.Builder(this).setTitle("Изменения версии").setMessage(text)
                    .setPositiveButton("Понятно", null).show();
        });
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, EditorActivity.class);
            i.putExtra("project", project.getPath());
            i.putExtra("path", files.get(pos));
            startActivity(i);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String rel = files.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Удалить " + rel + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        new File(project, rel).delete();
                        refresh();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    String owner() { return "project:" + project.getParentFile().getParentFile().getName() + "/" + channel + "/" + project.getName(); }

    @Override
    void stateChanged(boolean running) {
        bBuild.setText(running ? "Прекратить" : (hasReadyApk() ? "Пересобрать" : "Собрать"));
        bBuild.setEnabled(true);
        setInstallAvailable(!running && hasReadyApk());
        if (!running) refresh();
    }

    private void setInstallAvailable(boolean available) {
        bInstall.setEnabled(available);
        bInstall.setAlpha(available ? 1f : 0.38f);
    }

    private boolean hasReadyApk() { return latestApk() != null && hasSignedApk(latestApk()); }

    private boolean hasSignedApk(File apk) {
        if (apk == null || !apk.isFile() || apk.length() <= 0) return false;
        try {
            int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            PackageInfo info = getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            if (info == null) return false;
            if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
                Signature[] signers = info.signingInfo.getApkContentsSigners();
                return signers != null && signers.length > 0;
            }
            return info.signatures != null && info.signatures.length > 0;
        } catch (Exception e) { return false; }
    }

    private void refresh() {
        bBuild.setText(Runner.get().isRunning() && Runner.get().owns(owner()) ? "Прекратить" : (hasReadyApk() ? "Пересобрать" : "Собрать"));
        setInstallAvailable(!Runner.get().isRunning() && hasReadyApk());
        files.clear();
        Util.listFiles(project, project, files);
        adapter.notifyDataSetChanged();
    }

    private void build() {
        if (!linux.installed()) {
            Toast.makeText(this, "Сначала установите среду сборки", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, EnvActivity.class));
            return;
        }
        // Stable builds are allowed directly; Beta is an optional, separate channel.
        startBuild();
    }

    private void startBuild() {
        List<String> args = new ArrayList<>(Arrays.asList("assembleDebug"));
        Runner.get().clear();
        logView.setText("");
        String projectName = project.getParentFile().getParentFile().getName();
        Runner.get().start(this, owner(), "Сборка " + ReleaseChannels.title(channel) + " · " + project.getName(),
                log -> {
                    File mark = new File(project, ChannelActivity.ERROR_MARKER);
                    mark.delete();
                    try { linux.build(log, project, args); }
                    catch (Exception e) {
                        try { new java.io.FileOutputStream(mark).close(); } catch (Exception ignored) {}
                        throw e;
                    }
                }, projectName, versionNameExtra, channel);
    }

    private File latestApk() {
        File[] apks = new File(project, "build/apk").listFiles((d, n) -> n.endsWith(".apk"));
        if (apks == null || apks.length == 0) return null;
        File best = apks[0];
        for (File f : apks) {
            boolean fd = f.getName().contains("debug");
            boolean bd = best.getName().contains("debug");
            if ((fd && !bd) || (fd == bd && f.lastModified() > best.lastModified())) best = f;
        }
        return best;
    }

    private void install() {
        File apk = latestApk();
        if (apk == null || !hasSignedApk(apk)) {
            setInstallAvailable(false);
            Toast.makeText(this, "Сначала соберите и подпишите APK", Toast.LENGTH_LONG).show();
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Разрешите установку из этого источника", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        try {
            int flags = Build.VERSION.SDK_INT >= 28
                    ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            PackageInfo candidate = getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            if (candidate == null) throw new Exception("Не удалось прочитать APK");
            String pkg = candidate.packageName;
            long version = Build.VERSION.SDK_INT >= 28 ? candidate.getLongVersionCode() : candidate.versionCode;
            String cert = certificateFingerprint(candidate);
            StringBuilder report = new StringBuilder("Пакет: ").append(pkg)
                    .append("\nВерсия: ").append(version)
                    .append("\nПодпись SHA-256: ").append(cert);
            try {
                PackageInfo installed = getPackageManager().getPackageInfo(pkg, flags);
                long installedVersion = Build.VERSION.SDK_INT >= 28 ? installed.getLongVersionCode() : installed.versionCode;
                String installedCert = certificateFingerprint(installed);
                report.append("\nУстановлена версия: ").append(installedVersion);
                if (!cert.equals(installedCert)) {
                    new AlertDialog.Builder(this).setTitle("Подпись не совпадает")
                            .setMessage(report + "\n\nAndroid не разрешит обновление поверх установленной версии: сертификаты разные. Для обновления без удаления восстановите прежний ключ. Если он потерян, Android потребует удалить старую версию; данные приложения могут быть потеряны.")
                            .setPositiveButton("Понятно", null).show();
                    return;
                }
                if (version < installedVersion) {
                    new AlertDialog.Builder(this).setTitle("Версия ниже установленной")
                            .setMessage(report + "\n\nСборка получила меньший versionCode. Пересоберите проект — ApkStudio автоматически увеличивает versionCode при каждой сборке.")
                            .setPositiveButton("Понятно", null).show();
                    return;
                }
                report.append("\n\nПодпись совпадает — можно обновить приложение.");
            } catch (PackageManager.NameNotFoundException notInstalled) {
                report.append("\n\nПриложение ещё не установлено — будет выполнена первая установка.");
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка проверки APK: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String certificateFingerprint(PackageInfo info) throws Exception {
        Signature[] signatures;
        if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
            signatures = info.signingInfo.getApkContentsSigners();
        } else {
            signatures = info.signatures;
        }
        if (signatures == null || signatures.length == 0) return "неизвестно";
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray());
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format(java.util.Locale.US, "%02X", b & 0xff));
        return out.toString();
    }

    private void addFileDialog() {
        EditText et = new EditText(this);
        et.setHint("например app/src/main/res/layout/main.xml");
        et.setSingleLine(); Ui.input(et, this);
        new AlertDialog.Builder(this)
                .setTitle("Новый файл")
                .setView(et)
                .setPositiveButton("Создать", (d, w) -> {
                    String rel = et.getText().toString().trim();
                    if (rel.isEmpty()) return;
                    try {
                        File f = new File(project, rel);
                        if (!f.getCanonicalPath().startsWith(project.getCanonicalPath() + File.separator)) {
                            throw new Exception("Недопустимый путь");
                        }
                        if (!f.exists()) Util.write(f, "");
                        refresh();
                    } catch (Exception e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}
