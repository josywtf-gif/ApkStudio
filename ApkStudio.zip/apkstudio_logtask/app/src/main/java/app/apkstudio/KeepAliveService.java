package app.apkstudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the current job visible in the notification shade while it runs. */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "job";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getBooleanExtra("stop", false)) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent != null ? intent.getStringExtra("title") : null;
        String projectName = intent != null ? intent.getStringExtra("projectName") : null;
        String projectVersion = intent != null ? intent.getStringExtra("projectVersion") : null;
        String channel = intent != null ? intent.getStringExtra("channel") : null;
        try {
            Notification n = makeNotification(this, title, 0, "Запуск", projectName, projectVersion, channel);
            startForeground(NOTIFICATION_ID, n);
        } catch (Throwable t) {
            Runner.get().log("WARN: foreground service: " + t);
        }
        return START_NOT_STICKY;
    }

    static void updateNotification(Context context, String title, int percent, String message,
                                   String projectName, String projectVersion, String channel) {
        // Notifications are updated directly; no extra service start is needed for each percentage.
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, makeNotification(context, title, percent, message,
                    projectName, projectVersion, channel));
        } catch (Throwable ignored) { }
    }

    private static Notification makeNotification(Context context, String title, int percent, String message,
                                                  String projectName, String projectVersion, String channel) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "ApkStudio · Сборка и задачи", NotificationManager.IMPORTANCE_LOW));
        }
        Intent open;
        if (projectName != null && channel != null) {
            open = new Intent(context, ProjectActivity.class);
            open.putExtra("name", projectName);
            open.putExtra("version", projectVersion);
            open.putExtra("channel", channel);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        } else {
            open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            if (open == null) open = new Intent(context, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        PendingIntent content = PendingIntent.getActivity(context, 1001, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        builder.setContentTitle("ApkStudio")
                .setContentText((title == null ? "Выполняется задача" : title) + " · " + percent + "% — " + (message == null ? "" : message))
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setProgress(100, Math.max(0, Math.min(100, percent)), false);
        return builder.build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
