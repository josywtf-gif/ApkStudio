package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.Button;
import android.net.Uri;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact, collapsible job panel shared by setup and build screens. */
abstract class LogActivity extends Activity implements Runner.Listener {
    protected TextView logView;
    protected ScrollView logScroll;
    private ProgressBar progressBar;
    private TextView progressText;
    private LinearLayout jobPanel;
    private Button toggleLog;
    private Button saveLog;
    private int shownProgress = 0;
    private android.animation.ValueAnimator progressAnimator;
    private static final int REQ_SAVE_LOG = 901;
    private boolean logExpanded = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder pendingLog = new StringBuilder();
    private String lastMilestone = "";
    private boolean flushPosted;
    private final Runnable etaTicker = new Runnable() {
        @Override public void run() {
            if (!Runner.get().isRunning()) return;
            updateProgressLabel(Runner.get().getProgress(), Runner.get().getProgressMessage());
            handler.postDelayed(this, 1000L);
        }
    };

    protected int dp(int v) { return Ui.dp(this, v); }

    protected LinearLayout makeProgressView() {
        jobPanel = Ui.card(this);
        jobPanel.setVisibility(android.view.View.GONE);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        progressText = new TextView(this);
        progressText.setText("Ожидание");
        progressText.setTextColor(Ui.TEXT);
        progressText.setTextSize(12);
        head.addView(progressText, new LinearLayout.LayoutParams(0, -2, 1));
        saveLog = new Button(this);
        saveLog.setText("Сохранить лог");
        Ui.button(saveLog, this, false);
        saveLog.setVisibility(android.view.View.GONE);
        saveLog.setOnClickListener(v -> saveLog());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, dp(38));
        sp.rightMargin = dp(6);
        head.addView(saveLog, sp);
        toggleLog = new Button(this);
        toggleLog.setText("⌃");
        toggleLog.setTextSize(22);
        toggleLog.setGravity(android.view.Gravity.CENTER);
        toggleLog.setContentDescription("Показать лог");
        toggleLog.setRotation(0f);
        Ui.button(toggleLog, this, false);
        toggleLog.setOnClickListener(v -> setLogExpanded(!logExpanded));
        head.addView(toggleLog, new LinearLayout.LayoutParams(dp(42), dp(38)));
        jobPanel.addView(head);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(android.view.View.GONE);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(7));
        pp.topMargin = dp(10);
        jobPanel.addView(progressBar, pp);
        // The log lives in the same card as the progress bar: no separate block, no divider.
        makeLogView();
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(-1, 0);
        lgp.topMargin = dp(8);
        logScroll.setVisibility(android.view.View.GONE);
        jobPanel.addView(logScroll, lgp);
        return jobPanel;
    }

    private ScrollView makeLogView() {
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10.5f);
        logView.setTextColor(android.graphics.Color.rgb(185, 204, 222));
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.setFillViewport(false);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.addView(logView);
        return logScroll;
    }

    private void setLogExpanded(boolean expanded) {
        logExpanded = expanded;
        if (toggleLog != null) {
            toggleLog.setText("⌃");
            toggleLog.setContentDescription(expanded ? "Скрыть лог" : "Показать лог");
            toggleLog.animate().rotation(expanded ? 180f : 0f).setDuration(320).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        }
        if (logScroll == null) return;
        final android.view.ViewGroup.MarginLayoutParams lp = (android.view.ViewGroup.MarginLayoutParams) logScroll.getLayoutParams();
        final int full = dp(170);
        final int from = lp.height < 0 ? full : lp.height;
        final int to = expanded ? full : 0;
        if (expanded) {
            lp.height = 0;
            logScroll.setVisibility(android.view.View.VISIBLE);
            logScroll.setLayoutParams(lp);
        }
        android.animation.ValueAnimator anim = android.animation.ValueAnimator.ofInt(expanded ? 0 : from, to);
        anim.setDuration(320);
        anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            lp.height = (Integer) a.getAnimatedValue();
            logScroll.setLayoutParams(lp);
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (logExpanded) { lp.height = full; }
                else { logScroll.setVisibility(android.view.View.GONE); lp.height = 0; }
                logScroll.setLayoutParams(lp);
            }
        });
        anim.start();
    }

    private void applyVisibility(boolean running) {
        boolean show = Runner.get().owns(owner()) && (running || Runner.get().hasResult());
        if (jobPanel != null) {
            if (show && jobPanel.getVisibility() != android.view.View.VISIBLE) {
                jobPanel.setAlpha(0f);
                jobPanel.setVisibility(android.view.View.VISIBLE);
                jobPanel.animate().alpha(1f).setDuration(220).start();
            } else if (!show) jobPanel.setVisibility(android.view.View.GONE);
        }
        if (progressBar != null) progressBar.setVisibility(show && running ? android.view.View.VISIBLE : android.view.View.GONE);
        if (saveLog != null) saveLog.setVisibility(show && !running && Runner.get().hasResult() ? android.view.View.VISIBLE : android.view.View.GONE);
        if (logScroll != null && logExpanded) {
            logScroll.getLayoutParams().height = dp(170);
            logScroll.setVisibility(show ? android.view.View.VISIBLE : android.view.View.GONE);
        } else if (logScroll != null) {
            logScroll.getLayoutParams().height = 0;
            logScroll.setVisibility(android.view.View.GONE);
        }
    }

    /** Log channel: a screen sees only logs of jobs it started. */
    abstract String owner();

    @Override
    public String logOwner() { return owner(); }

    abstract void stateChanged(boolean running);

    @Override
    protected void onResume() {
        super.onResume();
        // Keep the saved transcript chronological (oldest -> newest), while the
        // on-screen viewer shows the latest activity at the top.
        String s = Runner.get().attach(this);
        String chronological = s.replaceAll("(?m)^APKSTUDIO_PROGRESS:.*\\n?", "");
        logView.setText(colorize(newestFirst(chronological)));
        if (logScroll != null) logScroll.post(() -> logScroll.scrollTo(0, 0));
        boolean mine = Runner.get().owns(owner());
        if (mine) onProgress(Runner.get().getProgress(), Runner.get().getProgressMessage());
        boolean running = Runner.get().isRunning();
        applyVisibility(running);
        stateChanged(running);
        if (running) handler.post(etaTicker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Runner.get().detach(this);
        handler.removeCallbacksAndMessages(null);
        flushPending();
    }

    private static final int RED = android.graphics.Color.rgb(255, 82, 82);
    private static final int GREEN = android.graphics.Color.rgb(76, 217, 100);

    private static final int NORMAL = android.graphics.Color.rgb(185, 204, 222);

    /** The on-screen journal shows the full transcript with colour by severity. */
    private static CharSequence colorize(String text) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int pos = 0;
        while (pos < text.length()) {
            int nl = text.indexOf('\n', pos);
            int end = nl < 0 ? text.length() : nl + 1;
            int start = sb.length();
            sb.append(text, pos, end);
            String line = text.substring(pos, nl < 0 ? text.length() : nl).trim();
            int color = isErrorLine(line) ? RED : isSuccessLine(line) ? GREEN : NORMAL;
            sb.setSpan(new ForegroundColorSpan(color), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            pos = end;
        }
        return sb;
    }

    private static boolean isErrorLine(String s) {
        if (s.startsWith("✖")) return true;
        if (s.startsWith("\tat ") || s.startsWith("at ") || s.startsWith("... ")) return false;
        String l = s.toLowerCase(java.util.Locale.ROOT);
        return l.contains("error:") || l.contains("ошибка") || l.contains("exception")
                || l.contains("failed") || l.contains("failure") || l.contains("fatal")
                || l.contains("не удалось") || l.contains("не найден") || l.startsWith("e: ")
                || l.startsWith("=== failed") || l.contains("не пройдена");
    }

    private static boolean isSuccessLine(String s) {
        if (s.startsWith("✔")) return true;
        String l = s.toLowerCase(java.util.Locale.ROOT);
        return l.startsWith("=== ok") || l.contains("build successful") || l.contains("успешно")
                || l.startsWith("apk создан") || l.startsWith("apk подписан")
                || l.startsWith("подпись проверена") || l.contains("установлен")
                || l.contains("готово");
    }

    private void addMilestone(String line) { addLine(line, true); }

    private void addLine(String line, boolean dedupe) {
        if (line == null || line.trim().isEmpty()) return;
        if (dedupe) { if (line.equals(lastMilestone)) return; lastMilestone = line; }
        synchronized (pendingLog) {
            pendingLog.append(line).append('\n');
            if (pendingLog.length() > 200_000) pendingLog.delete(0, pendingLog.length() - 100_000);
        }
        if (!flushPosted) {
            flushPosted = true;
            handler.postDelayed(() -> { flushPosted = false; flushPending(); }, 80);
        }
    }

    @Override
    public void onLog(String line) {
        if (line != null && !line.startsWith("APKSTUDIO_PROGRESS:") && !line.trim().isEmpty()) addLine(line, false);
    }

    /** Reorders a chronological batch so the newest line is always displayed first. */
    private static String newestFirst(String text) {
        if (text == null || text.isEmpty()) return "";
        String[] lines = text.split("\n", -1);
        StringBuilder out = new StringBuilder(text.length());
        for (int i = lines.length - 1; i >= 0; i--) {
            if (i == 0 && lines[i].isEmpty()) continue; // discard trailing split item
            out.append(lines[i]);
            if (i > 0 || text.endsWith("\n")) out.append('\n');
        }
        return out.toString();
    }

    private void flushPending() {
        final String chunk;
        synchronized (pendingLog) {
            if (pendingLog.length() == 0) return;
            chunk = pendingLog.toString();
            pendingLog.setLength(0);
        }
        if (logView == null) return;
        // New messages are prepended, not appended. Reverse each batch to retain
        // the correct newest-first order when several lines arrive together.
        SpannableStringBuilder combined = new SpannableStringBuilder(colorize(newestFirst(chunk)));
        combined.append(logView.getText());
        int extra = combined.length() - 300_000;
        if (extra > 0) combined.delete(300_000, combined.length()); // discard oldest lines at the bottom
        logView.setText(combined);
        if (logScroll != null) logScroll.post(() -> logScroll.scrollTo(0, 0));
    }

    @Override
    public void onProgress(int percent, String message) {
        if (message != null && !message.trim().isEmpty()) addMilestone("• " + message.trim());
        runOnUiThread(() -> {
            if (progressBar != null) {
                if (progressAnimator != null) progressAnimator.cancel();
                progressAnimator = android.animation.ValueAnimator.ofInt(shownProgress, percent);
                progressAnimator.setDuration(420);
                progressAnimator.setInterpolator(new android.view.animation.DecelerateInterpolator());
                progressAnimator.addUpdateListener(a -> {
                    shownProgress = (Integer) a.getAnimatedValue();
                    progressBar.setProgress(shownProgress);
                });
                progressAnimator.start();
            }
            updateProgressLabel(percent, message);
        });
    }

    private void updateProgressLabel(int percent, String message) {
        if (progressText == null) return;
        long remaining = Runner.get().getEstimatedRemainingMillis();
        String eta = remaining < 0 ? "Осталось: рассчитываем…" : "Осталось: " + formatDuration(remaining);
        if (percent >= 100) eta = "Завершение";
        progressText.setText(percent + "%  ·  " + message + "  ·  " + eta);
    }

    private static String formatDuration(long millis) {
        long seconds = Math.max(0L, millis / 1000L);
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        if (hours > 0) return hours + " ч " + minutes + " мин";
        if (minutes > 0) return minutes + " мин " + secs + " сек";
        return secs + " сек";
    }

    private void saveLog() {
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(android.content.Intent.EXTRA_TITLE, "ApkStudio-log.txt");
        startActivityForResult(intent, REQ_SAVE_LOG);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_LOG || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
            if (out == null) throw new java.io.IOException("Не удалось открыть файл");
            out.write(Runner.get().snapshot(owner()).getBytes(StandardCharsets.UTF_8));
            android.widget.Toast.makeText(this, "Лог сохранён", android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Не удалось сохранить лог: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onState(boolean running) {
        runOnUiThread(() -> {
            flushPending();
            applyVisibility(running);
            stateChanged(running);
            handler.removeCallbacks(etaTicker);
            if (running) handler.post(etaTicker);
        });
    }
}
