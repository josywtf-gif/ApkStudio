package app.apkstudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Dedicated, consistently styled version list for one release channel. */
public class ChannelActivity extends Activity {
    private static final int REQ_ZIP = 41;
    private String projectName;
    private String channel;
    private File channelDir;
    private final List<File> versions = new ArrayList<>();
    private android.widget.BaseAdapter adapter;
    private TextView emptyView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        projectName = getIntent().getStringExtra("name");
        channel = ReleaseChannels.normalize(getIntent().getStringExtra("channel"));
        File root = new File(Util.projectsDir(this), projectName);
        try { Versions.ensureChannelStructure(root); }
        catch (Exception e) { Toast.makeText(this, "Не удалось подготовить проект: " + e.getMessage(), Toast.LENGTH_LONG).show(); finish(); return; }
        channelDir = ReleaseChannels.channelDir(root, channel);
        channelDir.mkdirs();

        LinearLayout page = new LinearLayout(this);
        Ui.page(page, this);
        page.addView(Ui.header(this, projectName, ReleaseChannels.title(channel).toUpperCase(), true, null));

        Button add = new Button(this);
        add.setText("＋  Добавить ZIP");
        Ui.button(add, this, true);
        Ui.add(page, add, this, 0);
        add.setOnClickListener(v -> pickZip());
        Ui.gap(page, this, 18);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Версии релиза"); Ui.title(title, 17);
        heading.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = new TextView(this);
        count.setText("ИСТОРИЯ"); Ui.muted(count); heading.addView(count);
        page.addView(heading);
        Ui.gap(page, this, 10);

        ListView list = new ListView(this);
        Ui.styleList(list, this);
        adapter = new android.widget.BaseAdapter() {
            @Override public int getCount() { return versions.size(); }
            @Override public Object getItem(int i) { return versions.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, android.view.ViewGroup parent) {
                File version = versions.get(i);
                Versions.Info info = Versions.read(version);
                float d = getResources().getDisplayMetrics().density;
                boolean signedReady = hasSignedApk(version);
                LinearLayout row = new LinearLayout(ChannelActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setClipToPadding(false);
                row.setClipChildren(false);
                row.setPadding(Ui.dp(ChannelActivity.this, 14), Ui.dp(ChannelActivity.this, 14), Ui.dp(ChannelActivity.this, 14), Ui.dp(ChannelActivity.this, 14));
                row.setBackground(Ui.shape(Ui.SURFACE, android.graphics.Color.rgb(32, 45, 66), 12, d));
                TextView name = new TextView(ChannelActivity.this);
                name.setText(info.name.isEmpty() ? projectName : info.name);
                Ui.title(name, 15);
                name.setSingleLine(true);
                name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout nameBox = new LinearLayout(ChannelActivity.this);
                nameBox.setGravity(Gravity.TOP);
                nameBox.setClipChildren(false);
                if (signedReady) name.setMaxWidth(Ui.dp(ChannelActivity.this, 190));
                nameBox.addView(name, new LinearLayout.LayoutParams(-2, -2));
                if (signedReady) {
                    TextView sign = new TextView(ChannelActivity.this);
                    sign.setText("sign");
                    sign.setTextColor(android.graphics.Color.rgb(5, 38, 29));
                    sign.setTextSize(8);
                    sign.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
                    sign.setIncludeFontPadding(false);
                    sign.setPadding(Ui.dp(ChannelActivity.this, 5), Ui.dp(ChannelActivity.this, 2), Ui.dp(ChannelActivity.this, 5), Ui.dp(ChannelActivity.this, 2));
                    sign.setBackground(Ui.shape(android.graphics.Color.rgb(92, 220, 177), 0, 7, d));
                    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
                    sp.leftMargin = Ui.dp(ChannelActivity.this, 4);
                    sign.setTranslationY(-Ui.dp(ChannelActivity.this, 9));
                    nameBox.addView(sign, sp);
                }
                row.addView(nameBox, new LinearLayout.LayoutParams(0, -2, 1));
                boolean failed = new File(version, ERROR_MARKER).exists();
                boolean isNew = !failed && !signedReady && i == 0 && versions.size() > 1;
                if (failed || isNew) {
                    TextView tag = new TextView(ChannelActivity.this);
                    tag.setText(failed ? "error" : "new");
                    tag.setTextColor(failed ? android.graphics.Color.WHITE : android.graphics.Color.rgb(8, 25, 29));
                    tag.setTextSize(12);
                    tag.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
                    tag.setPadding(Ui.dp(ChannelActivity.this, 10), Ui.dp(ChannelActivity.this, 5), Ui.dp(ChannelActivity.this, 10), Ui.dp(ChannelActivity.this, 5));
                    tag.setBackground(Ui.shape(failed ? android.graphics.Color.rgb(214, 48, 64) : Ui.ACCENT, 0, 14, d));
                    LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
                    tp.leftMargin = Ui.dp(ChannelActivity.this, 10);
                    row.addView(tag, tp);
                }
                TextView ver = new TextView(ChannelActivity.this);
                ver.setText(info.versionName.isEmpty() ? "—" : info.versionName);
                ver.setTextColor(Ui.MUTED); ver.setTextSize(15);
                ver.setGravity(Gravity.END);
                ver.setMinWidth(Ui.dp(ChannelActivity.this, 56));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-2, -2);
                vp.leftMargin = Ui.dp(ChannelActivity.this, 10);
                row.addView(ver, vp);
                return row;
            }
        };
        list.setAdapter(adapter);
        page.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        emptyView = new TextView(this);
        emptyView.setText("Пока нет версий. Нажмите «Добавить ZIP», чтобы загрузить исходники этого канала.");
        Ui.muted(emptyView);
        Ui.add(page, emptyView, this, 12);
        setContentView(page);
        list.setOnItemClickListener((parent, view, position, id) -> {
            Intent i = new Intent(this, ProjectActivity.class);
            i.putExtra("name", projectName);
            i.putExtra("channel", channel);
            i.putExtra("version", versions.get(position).getName());
            startActivity(i);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            final File version = versions.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Удалить версию?")
                    .setMessage(version.getName() + "\n\nПапка версии со всеми файлами будет удалена без возможности восстановления.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (d, w) -> new Thread(() -> {
                        Util.deleteRecursive(version);
                        runOnUiThread(() -> {
                            refresh();
                            Toast.makeText(this, version.exists() ? "Не удалось удалить полностью" : "Версия удалена", Toast.LENGTH_SHORT).show();
                        });
                    }).start())
                    .show();
            return true;
        });
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (channelDir != null) refresh();
    }

    static final String ERROR_MARKER = ".apkstudio-build-error";

    private void refresh() {
        versions.clear();
        versions.addAll(Versions.list(channelDir));
        if (adapter != null) adapter.notifyDataSetChanged();
        if (emptyView != null) emptyView.setVisibility(versions.isEmpty() ? View.VISIBLE : View.GONE);
    }


    /** True only when this version contains a readable APK with a signing certificate. */
    private boolean hasSignedApk(File version) {
        File apkDir = new File(version, "build/apk");
        File[] apks = apkDir.listFiles((dir, name) -> name.toLowerCase(java.util.Locale.ROOT).endsWith(".apk"));
        if (apks == null) return false;
        for (File apk : apks) {
            if (!apk.isFile() || apk.length() <= 0) continue;
            try {
                int flags = android.os.Build.VERSION.SDK_INT >= 28
                        ? android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
                        : android.content.pm.PackageManager.GET_SIGNATURES;
                android.content.pm.PackageInfo info = getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
                if (info == null) continue;
                if (android.os.Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
                    android.content.pm.Signature[] signers = info.signingInfo.getApkContentsSigners();
                    if (signers != null && signers.length > 0) return true;
                } else if (info.signatures != null && info.signatures.length > 0) {
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_ZIP);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_ZIP || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String zipName = "project.zip";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int index = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) zipName = c.getString(index);
            }
        } catch (Exception ignored) {}
        final String name = zipName;
        new Thread(() -> {
            String title, message;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                Versions.Result r = Versions.importZip(this, in, name, projectName, channel);
                if (r.notProject) {
                    Util.deleteRecursive(r.container);
                    throw new IllegalArgumentException("В ZIP не найден Android-проект (build.gradle или AndroidManifest.xml)");
                }
                title = "ZIP добавлен";
                message = ReleaseChannels.title(channel) + " · " + r.version.getName();
                if (!r.report.isEmpty()) message += "\n\n" + r.report;
            } catch (Exception e) { title = "Ошибка импорта"; message = String.valueOf(e.getMessage()); }
            final String t = title, m = message;
            runOnUiThread(() -> {
                refresh();
                new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("Понятно", null).show();
            });
        }).start();
    }
}
