package app.apkstudio;

import android.content.Context;
import android.os.Environment;
import android.os.Build;
import android.content.pm.PackageManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class Util {
    private Util() {}

    /** Shared ApkStudio root: /storage/emulated/0/ApkStudio. */
    static File sharedRoot(Context c) {
        if (hasSharedStoragePermission(c)
                && Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            return new File(Environment.getExternalStorageDirectory(), "ApkStudio");
        }
        // Preserve the old location until access to shared internal storage is granted.
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        return new File(base, "projects");
    }

    static boolean hasSharedStoragePermission(Context c) {
        return Build.VERSION.SDK_INT < 23
                || c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Project folders live directly under ApkStudio/, next to components/. */
    static File projectsDir(Context c) {
        File d = sharedRoot(c);
        d.mkdirs();
        return d;
    }

    /**
     * Components must live outside Android's app-specific directories so they survive uninstall.
     * Never silently fall back to getFilesDir()/Android/data: Android deletes those on uninstall.
     */
    static File componentDir(Context c) {
        File external = Environment.getExternalStorageDirectory();
        return new File(external, "ApkStudio/components");
    }

    /** One-time, non-destructive migration from the previous app-private projects folder. */
    static void ensureSharedStorage(Context c) {
        if (!hasSharedStoragePermission(c)
                || !Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) return;
        File base = c.getExternalFilesDir(null);
        if (base == null) return;
        File legacy = new File(base, "projects");
        File target = new File(Environment.getExternalStorageDirectory(), "ApkStudio");
        target.mkdirs();
        // There is exactly one canonical component directory: /ApkStudio/components.
        // Older releases used /ApkStudio/Component (uppercase) and app-private folders.
        File sharedComponents = new File(target, "components");
        sharedComponents.mkdirs();
        migrateComponentDirectory(new File(target, "Component"), sharedComponents);
        migrateComponentDirectory(new File(base, "components"), sharedComponents);
        migrateComponentDirectory(new File(base, "Component"), sharedComponents);
        migrateComponentDirectory(new File(c.getFilesDir(), "components"), sharedComponents);
        migrateComponentDirectory(new File(c.getFilesDir(), "Component"), sharedComponents);
        if (!legacy.isDirectory()) return;
        File[] projects = legacy.listFiles(File::isDirectory);
        if (projects == null) return;
        for (File oldProject : projects) {
            File newProject = new File(target, oldProject.getName());
            if (!newProject.exists()) {
                if (!oldProject.renameTo(newProject)) copyTreeMissing(oldProject, newProject);
            } else {
                // Merge only missing files; never overwrite a newer destination file.
                copyTreeMissing(oldProject, newProject);
            }
        }
    }


    /** Move legacy component stores into the single canonical lowercase directory. */
    private static void migrateComponentDirectory(File source, File canonical) {
        if (!source.isDirectory() || source.equals(canonical)) return;
        File[] children = source.listFiles();
        if (children == null) return;
        boolean complete = true;
        for (File child : children) {
            File destination = new File(canonical, child.getName());
            if (child.isDirectory()) {
                if (!destination.exists() && !destination.mkdirs()) { complete = false; continue; }
                migrateComponentDirectory(child, destination);
                if (child.exists()) complete = false;
            } else {
                try {
                    if (!destination.exists()) {
                        copyFile(child, destination);
                    } else if (!sameFile(child, destination)) {
                        // Keep a conflicting legacy copy inside the canonical store, never
                        // in a second sibling directory. It is not selected automatically.
                        File conflict = new File(new File(canonical, "legacy-conflicts"),
                                source.getName() + "-" + child.getName());
                        if (!conflict.exists()) copyFile(child, conflict);
                        if (!sameFile(child, conflict)) { complete = false; continue; }
                    }
                    if (!child.delete()) complete = false;
                } catch (IOException e) { complete = false; }
            }
        }
        if (complete) source.delete();
    }

    private static void copyFile(File source, File destination) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs())
            throw new IOException("Не удалось создать каталог миграции: " + parent);
        try (InputStream in = new FileInputStream(source)) { copy(in, destination); }
    }

    private static boolean sameFile(File a, File b) throws IOException {
        if (!a.isFile() || !b.isFile() || a.length() != b.length()) return false;
        try (InputStream x = new FileInputStream(a); InputStream y = new FileInputStream(b)) {
            byte[] xb = new byte[32768], yb = new byte[32768];
            while (true) {
                int nx = x.read(xb), ny = y.read(yb);
                if (nx != ny) return false;
                if (nx < 0) return true;
                for (int i = 0; i < nx; i++) if (xb[i] != yb[i]) return false;
            }
        }
    }

    private static void copyTreeMissing(File source, File destination) {
        if (source.isDirectory()) {
            destination.mkdirs();
            File[] children = source.listFiles();
            if (children != null) for (File child : children)
                copyTreeMissing(child, new File(destination, child.getName()));
        } else if (!destination.exists()) {
            try (InputStream in = new FileInputStream(source)) { copy(in, destination); }
            catch (IOException ignored) { /* Keep the original project intact for a later retry. */ }
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    static String read(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            return new String(readAll(in), StandardCharsets.UTF_8);
        }
    }

    static void write(File f, String s) throws IOException {
        File p = f.getParentFile();
        if (p != null) p.mkdirs();
        try (OutputStream o = new FileOutputStream(f)) {
            o.write(s.getBytes(StandardCharsets.UTF_8));
        }
    }

    static void copy(InputStream in, File out) throws IOException {
        File p = out.getParentFile();
        if (p != null) p.mkdirs();
        try (OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    static void deleteRecursive(File f) {
        if (f.isDirectory() && !java.nio.file.Files.isSymbolicLink(f.toPath())) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    static String sourceZipName(File versionDir) {
        File m = new File(versionDir, ".apkstudio-source-zip");
        if (!m.isFile()) return null;
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new FileInputStream(m), StandardCharsets.UTF_8))) {
            String l = r.readLine();
            return l == null || l.isEmpty() ? null : l;
        } catch (IOException e) { return null; }
    }

    /** Relative paths of all files, skipping the top-level "build" dir. */
    static void listFiles(File root, File dir, List<String> out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        Arrays.sort(kids);
        for (File k : kids) {
            String nm = k.getName();
            if (nm.startsWith(".apkstudio-")) continue;
            if (dir.equals(root) && k.isFile() && nm.equals(sourceZipName(root))) continue;
            if (k.isDirectory() && (nm.equals("build") || nm.equals(".gradle") || nm.equals(".git"))) continue;
            if (k.isDirectory()) listFiles(root, k, out);
            else out.add(root.toURI().relativize(k.toURI()).getPath());
        }
    }

    static void unzip(InputStream in, File dest) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        try (ZipInputStream zi = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = zi.getNextEntry()) != null) {
                File f = new File(dest, e.getName());
                if (!f.getCanonicalPath().startsWith(destPath)) {
                    throw new IOException("Bad zip entry: " + e.getName());
                }
                if (e.isDirectory()) {
                    f.mkdirs();
                } else {
                    copy(zi, f);
                }
            }
        }
    }

    /** If the archive had a single top-level folder with the project, move it up. */
    static void flatten(File dir) {
        if (isProject(dir)) return;
        File[] kids = dir.listFiles();
        if (kids == null || kids.length != 1 || !kids[0].isDirectory()) return;
        if (!isProject(kids[0])) return;
        File tmp = new File(dir.getParentFile(), dir.getName() + ".tmp");
        deleteRecursive(tmp);
        if (!kids[0].renameTo(tmp)) return;
        File[] inner = tmp.listFiles();
        if (inner != null) for (File c : inner) c.renameTo(new File(dir, c.getName()));
        deleteRecursive(tmp);
    }

    static boolean isProject(File dir) {
        for (String n : new String[]{"AndroidManifest.xml", "settings.gradle", "settings.gradle.kts",
                "build.gradle", "build.gradle.kts"}) {
            if (new File(dir, n).exists()) return true;
        }
        return false;
    }

    static String safeName(String s) {
        String r = s.replaceAll("[^A-Za-z0-9._-]", "_");
        return r.isEmpty() ? "project" : r;
    }
}
