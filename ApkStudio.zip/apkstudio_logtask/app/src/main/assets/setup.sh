#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
SDK=/opt/android-sdk
GRADLE_VER=8.9
COMP=/opt/apkstudio-components
OFFLINE=0
[ "${1:-}" = "--offline" ] && OFFLINE=1
mkdir -p "$COMP/deb-cache"
if [ "$OFFLINE" = 1 ]; then
  echo "=== РЕЖИМ БЕЗ ИНТЕРНЕТА: сетевые загрузки и apt update запрещены"
fi

# Keep downloaded Debian packages in shared Component storage so a rebuilt
# Linux rootfs can reuse them instead of downloading the same .deb files.
echo "Dir::Cache::archives \"$COMP/deb-cache/\";" > /etc/apt/apt.conf.d/99apkstudio-cache
if command -v unzip >/dev/null && [ -s "$COMP/system-packages-debian-bookworm-arm64.zip" ] \
   && ! find "$COMP/deb-cache" -name '*.deb' -print -quit | grep -q .; then
  echo "=== Восстановление кеша системных пакетов из Component"
  unzip -oq "$COMP/system-packages-debian-bookworm-arm64.zip" -d "$COMP"
fi

# Restore the Java tree when it was archived previously. apt still supplies
# system libraries and repairs an incomplete restore when necessary.
if command -v unzip >/dev/null && [ ! -x /usr/lib/jvm/java-17-openjdk-arm64/bin/javac ] \
   && [ -s "$COMP/jdk-17-openjdk-arm64.zip" ]; then
  mkdir -p /usr/lib/jvm
  unzip -oq "$COMP/jdk-17-openjdk-arm64.zip" -d /usr/lib/jvm
fi

echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/99apkstudio
echo 'force-unsafe-io' > /etc/dpkg/dpkg.cfg.d/99apkstudio

if ! command -v javac >/dev/null || ! command -v curl >/dev/null || ! command -v unzip >/dev/null || ! command -v rsync >/dev/null || ! command -v zip >/dev/null || ! command -v git >/dev/null; then
  if [ "$OFFLINE" = 1 ]; then
    echo "APKSTUDIO_PROGRESS:12:Установка системных пакетов из локального кеша"
    DEBS=("$COMP"/deb-cache/*.deb)
    if [ ! -f "${DEBS[0]}" ]; then
      echo "ERROR: локальный кеш .deb пуст; автономная установка невозможна"
      exit 41
    fi
    dpkg --unpack "${DEBS[@]}"
    dpkg --configure -a
  else
    echo "APKSTUDIO_PROGRESS:10:Обновление списка пакетов"
    echo "=== apt: JDK 17 + utils"
    apt-get update
    echo "APKSTUDIO_PROGRESS:22:Установка JDK 17 и системных утилит"
    apt-get install -y --no-install-recommends ca-certificates curl unzip zip git rsync openjdk-17-jdk-headless
  fi
fi
if ! command -v javac >/dev/null || ! command -v curl >/dev/null || ! command -v unzip >/dev/null || ! command -v rsync >/dev/null || ! command -v zip >/dev/null || ! command -v git >/dev/null; then
  echo "ERROR: системные инструменты не установлены полностью"
  exit 42
fi

# Persist Debian package archives (including the JDK and required utilities).
if find "$COMP/deb-cache" -name '*.deb' -print -quit | grep -q .; then
  (cd "$COMP" && zip -q -FS -r system-packages-debian-bookworm-arm64.zip deb-cache)
fi
if [ -x /usr/lib/jvm/java-17-openjdk-arm64/bin/javac ] \
   && [ ! -s "$COMP/jdk-17-openjdk-arm64.zip" ]; then
  (cd /usr/lib/jvm && zip -q -r "$COMP/jdk-17-openjdk-arm64.zip" java-17-openjdk-arm64)
fi

# If this is an older installation whose rootfs was unpacked before the
# Component cache existed, seed the reusable rootfs ZIP once. Failure is
# non-fatal: the current installed environment remains usable.
if [ ! -s "$COMP/debian-bookworm-arm64-rootfs.zip" ] && [ "$OFFLINE" = 0 ]; then
  echo "=== Подготовка кеша базовой Debian rootfs (однократно)"
  if curl -fL --retry 2 --connect-timeout 20 -o /tmp/rootfs.tar.gz \
      https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/dist-arm64v8/bookworm/slim/oci/blobs/rootfs.tar.gz; then
    if (cd /tmp && zip -0 -q "$COMP/debian-bookworm-arm64-rootfs.zip" rootfs.tar.gz); then
      echo "Debian rootfs сохранена в Component"
    else
      echo "WARN: не удалось упаковать rootfs в Component"
    fi
    rm -f /tmp/rootfs.tar.gz
  else
    echo "WARN: rootfs не удалось кешировать сейчас; установленная среда сохранена"
  fi
fi

mkdir -p /opt/tools /root/.gradle
ln -sf /opt/native/libaapt2.so /opt/tools/aapt2

echo "APKSTUDIO_PROGRESS:38:Проверка Android SDK"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "=== Android cmdline-tools"
  mkdir -p "$SDK/cmdline-tools"
  if [ -s "$COMP/android-commandlinetools-11076708.zip" ]; then
    echo "APKSTUDIO_PROGRESS:42:Восстановление Android command-line tools из Component"
    unzip -q -o "$COMP/android-commandlinetools-11076708.zip" -d "$SDK/cmdline-tools"
  else
    if [ "$OFFLINE" = 1 ]; then echo "ERROR: нет android-commandlinetools-11076708.zip"; exit 43; fi
    echo "APKSTUDIO_PROGRESS:42:Загрузка Android command-line tools"
    curl -fL --retry 3 -o /tmp/cmdline-tools.zip \
      https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    cp /tmp/cmdline-tools.zip "$COMP/android-commandlinetools-11076708.zip"
    unzip -q -o /tmp/cmdline-tools.zip -d "$SDK/cmdline-tools"
    rm -f /tmp/cmdline-tools.zip
  fi
  if [ -d "$SDK/cmdline-tools/cmdline-tools" ]; then
    rm -rf "$SDK/cmdline-tools/latest"
    mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  fi
fi
if [ -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ] \
   && [ ! -s "$COMP/android-commandlinetools-11076708.zip" ]; then
  (cd "$SDK/cmdline-tools" && zip -q -r "$COMP/android-commandlinetools-11076708.zip" latest)
fi

export PATH="$SDK/cmdline-tools/latest/bin:$PATH"
echo "APKSTUDIO_PROGRESS:58:Установка Android SDK и Build Tools"
# Все платформы и build-tools, которые могут понадобиться проектам, хранятся одним архивом.
SDK_ZIP="$COMP/android-sdk-full.zip"
# Platform-Tools is required by Android Gradle Plugin even when all build
# platforms are present. Keep it in the same shared component archive too.
SDK_PKGS=("platform-tools" "platforms;android-33" "platforms;android-34" "platforms;android-35" "build-tools;34.0.0" "build-tools;35.0.0")
SDK_DIRS=(platform-tools platforms/android-33 platforms/android-34 platforms/android-35 build-tools/34.0.0 build-tools/35.0.0)
sdk_complete() {
  for d in "${SDK_DIRS[@]}"; do [ -d "$SDK/$d" ] || return 1; done
  [ -x "$SDK/platform-tools/adb" ] || return 1
  # SDK license files are persisted with the SDK archive, not silently skipped.
  [ -s "$SDK/licenses/android-sdk-license" ] || return 1
  return 0
}
if ! sdk_complete; then
  for z in "$SDK_ZIP" "$COMP/android-sdk-platform-34-build-tools-34.0.0.zip"; do
    if [ -s "$z" ]; then
      echo "=== Восстановление Android SDK из Component ($(basename "$z"))"
      unzip -q -o "$z" -d "$SDK"
    fi
  done
fi
if ! sdk_complete; then
  if [ "$OFFLINE" = 1 ]; then
    echo "ERROR: android-sdk-full.zip отсутствует или не содержит все платформы/build-tools"
    exit 44
  fi
  echo "=== Android SDK licenses and packages"
  # Accept all Google SDK licenses non-interactively and fail visibly if that
  # cannot be completed. Do not mask sdkmanager/network/license errors.
  set +e
  # sdkmanager closes stdin as soon as it has consumed the last prompt;
  # `yes` then receives SIGPIPE. Silence only yes' stderr and inspect the
  # sdkmanager exit code (PIPESTATUS[1]) so the harmless pipe message does
  # not look like a failed license acceptance.
  yes 2>/dev/null | sdkmanager --sdk_root="$SDK" --licenses
  license_status=${PIPESTATUS[1]}
  set -e
  if [ "$license_status" -ne 0 ]; then
    echo "ERROR: не удалось принять лицензии Android SDK (код $license_status)"
    exit 46
  fi
  sdkmanager --sdk_root="$SDK" --install "${SDK_PKGS[@]}"
fi
if sdk_complete; then
  # Rebuild the archive so a previously cached archive without platform-tools
  # or licenses cannot keep causing the same Gradle warning.
  rm -f "$SDK_ZIP"
  (cd "$SDK" && zip -q -r "$SDK_ZIP" "${SDK_DIRS[@]}" licenses)
fi

echo "APKSTUDIO_PROGRESS:78:Проверка Gradle"
if [ ! -x /opt/gradle/bin/gradle ]; then
  echo "=== Gradle $GRADLE_VER"
  if [ -s "$COMP/gradle-$GRADLE_VER-bin.zip" ]; then
    echo "APKSTUDIO_PROGRESS:82:Восстановление Gradle из Component"
    unzip -q -o "$COMP/gradle-$GRADLE_VER-bin.zip" -d /opt
  else
    if [ "$OFFLINE" = 1 ]; then echo "ERROR: нет gradle-$GRADLE_VER-bin.zip"; exit 45; fi
    echo "APKSTUDIO_PROGRESS:82:Загрузка Gradle"
    curl -fL --retry 3 -o /tmp/gradle.zip \
      "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip"
    cp /tmp/gradle.zip "$COMP/gradle-$GRADLE_VER-bin.zip"
    unzip -q -o /tmp/gradle.zip -d /opt
    rm -f /tmp/gradle.zip
  fi
  if [ -d "/opt/gradle-$GRADLE_VER" ]; then
    rm -rf /opt/gradle
    mv "/opt/gradle-$GRADLE_VER" /opt/gradle
  fi
fi
if [ -x /opt/gradle/bin/gradle ] && [ ! -s "$COMP/gradle-$GRADLE_VER-bin.zip" ]; then
  (cd /opt && zip -q -r "$COMP/gradle-$GRADLE_VER-bin.zip" gradle)
fi

# One persistent debug certificate is used by every project and every build.
# Linux.prepare() bind-mounts ApkStudio's private signing directory here.
mkdir -p /root/.android
if [ ! -s /root/.android/debug.keystore ]; then
  echo "APKSTUDIO_PROGRESS:91:Создание постоянного ключа подписи APK"
  keytool -genkeypair -v -keystore /root/.android/debug.keystore \
    -storepass android -keypass android -alias androiddebugkey -noprompt \
    -dname "CN=Android Debug,O=Android,C=US" -validity 10000 \
    -keyalg RSA -keysize 2048
fi

cat > /root/.gradle/gradle.properties <<'EOF'
android.aapt2FromMavenOverride=/opt/tools/aapt2
org.gradle.daemon=true
org.gradle.caching=true
org.gradle.parallel=false
org.gradle.workers.max=3
org.gradle.vfs.watch=false
EOF

# Кеш Gradle-зависимостей: пробные сборки (View/Java, Kotlin, Jetpack Compose, Media3)
# загружают AGP, Kotlin и библиотеки один раз; кеш хранится в одном архиве.
DEPS_ZIP="$COMP/gradle-deps-cache.zip"
if [ ! -d /root/.gradle/caches/modules-2 ] && [ -s "$DEPS_ZIP" ]; then
  echo "APKSTUDIO_PROGRESS:92:Восстановление кеша зависимостей Gradle из Component"
  unzip -q -o "$DEPS_ZIP" -d /root/.gradle
fi
if [ "$OFFLINE" = 1 ] && [ ! -d /root/.gradle/caches/modules-2 ]; then
  echo "ERROR: кеш Gradle dependencies не восстановлен; автономная сборка не гарантируется"
  exit 46
fi

# warm_build <name> <agp> <kotlin|none> <compose: legacy|plugin|none>
warm_build() {
  local N="$1" AGP="$2" KT="$3" CMP="$4"
  local W="/tmp/apkstudio-warmup-$N"
  local WARM_SRC="$W/app/src/main/java/com/apkstudio/warm"
  rm -rf "$W"; mkdir -p "$WARM_SRC"
  local PLUGINS="    id 'com.android.application' version '$AGP' apply false"
  local APPLY="    id 'com.android.application'"
  local DEPS="    implementation 'androidx.core:core:1.13.1'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.recyclerview:recyclerview:1.3.2'"
  local EXTRA="" SRC="package com.apkstudio.warm
class W
"
  if [ "$KT" != none ]; then
    PLUGINS="$PLUGINS
    id 'org.jetbrains.kotlin.android' version '$KT' apply false"
    APPLY="$APPLY
    id 'org.jetbrains.kotlin.android'"
    EXTRA="    kotlinOptions { jvmTarget = '17' }"
    DEPS="$DEPS
    implementation 'androidx.core:core-ktx:1.13.1'
    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.8.6'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.6'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1'
    implementation 'androidx.media3:media3-exoplayer:1.4.1'
    implementation 'androidx.media3:media3-exoplayer-hls:1.4.1'
    implementation 'androidx.media3:media3-ui:1.4.1'"
  fi
  if [ "$CMP" != none ]; then
    local BOM=2024.06.00
    if [ "$CMP" = legacy ]; then
      EXTRA="$EXTRA
    buildFeatures { compose true }
    composeOptions { kotlinCompilerExtensionVersion = '1.5.14' }"
    else
      BOM=2024.10.01
      PLUGINS="$PLUGINS
    id 'org.jetbrains.kotlin.plugin.compose' version '$KT' apply false"
      APPLY="$APPLY
    id 'org.jetbrains.kotlin.plugin.compose'"
      EXTRA="$EXTRA
    buildFeatures { compose true }"
    fi
    DEPS="$DEPS
    implementation platform('androidx.compose:compose-bom:$BOM')
    implementation 'androidx.compose.ui:ui'
    implementation 'androidx.compose.ui:ui-graphics'
    implementation 'androidx.compose.ui:ui-tooling-preview'
    implementation 'androidx.compose.material3:material3'
    implementation 'androidx.compose.material:material-icons-extended'
    implementation 'androidx.compose.foundation:foundation'
    implementation 'androidx.activity:activity-compose:1.9.2'
    implementation 'androidx.navigation:navigation-compose:2.8.2'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6'
    debugImplementation 'androidx.compose.ui:ui-tooling'"
    SRC="package com.apkstudio.warm
@androidx.compose.runtime.Composable fun W() { androidx.compose.material3.Text(\"warm\") }
"
  fi
  cat > "$W/settings.gradle" <<EOF
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = 'warm'
include ':app'
EOF
  printf 'plugins {\n%s\n}\n' "$PLUGINS" > "$W/build.gradle"
  printf 'android.useAndroidX=true\nandroid.nonTransitiveRClass=true\nkotlin.code.style=official\n' > "$W/gradle.properties"
  cat > "$W/app/build.gradle" <<EOF
plugins {
$APPLY
}
android {
    namespace 'com.apkstudio.warm'
    compileSdk 34
    defaultConfig { applicationId 'com.apkstudio.warm'; minSdk 24; targetSdk 34; versionCode 1; versionName '1.0' }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
$EXTRA
}
dependencies {
$DEPS
}
EOF
  mkdir -p "$W/app/src/main/res/values"
  printf '<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="warm" android:theme="@style/Theme.AppCompat"/></manifest>\n' > "$W/app/src/main/AndroidManifest.xml"
  if [ "$KT" != none ]; then printf '%s' "$SRC" > "$WARM_SRC/W.kt"
  else printf 'package com.apkstudio.warm;\npublic class W {}\n' > "$WARM_SRC/W.java"; fi
  local rc=0
  /opt/gradle/bin/gradle -p "$W" assembleDebug --no-daemon --console=plain \
    -Dorg.gradle.jvmargs=-Xmx2048m -Pkotlin.compiler.execution.strategy=in-process || rc=$?
  rm -rf "$W"
  return $rc
}

if [ ! -s "$DEPS_ZIP" ] && [ "$OFFLINE" = 1 ]; then
  echo "ERROR: отсутствует gradle-deps-cache.zip"
  exit 47
fi
if [ ! -s "$DEPS_ZIP" ]; then
  WARM_OK=0
  echo "APKSTUDIO_PROGRESS:92:Загрузка AGP, Kotlin и библиотек (Java/View)"
  warm_build java 8.6.1 none none && WARM_OK=1 || echo "WARN: пробная сборка Java/View не удалась"
  echo "APKSTUDIO_PROGRESS:93:Загрузка Kotlin, Compose и Media3 (AGP 8.5.2, Kotlin 1.9.24)"
  warm_build k19 8.5.2 1.9.24 legacy && WARM_OK=1 || echo "WARN: пробная сборка Kotlin 1.9 + Compose не удалась"
  echo "APKSTUDIO_PROGRESS:94:Загрузка Kotlin, Compose и Media3 (AGP 8.7.3, Kotlin 2.0.21)"
  warm_build k20 8.7.3 2.0.21 plugin && WARM_OK=1 || echo "WARN: пробная сборка Kotlin 2.0 + Compose не удалась"
  if [ "$WARM_OK" = 1 ] && [ -d /root/.gradle/caches/modules-2 ]; then
    (cd /root/.gradle && zip -q -r "$DEPS_ZIP" caches/modules-2)
  else
    echo "WARN: зависимости Gradle не загружены заранее; они будут загружены при первой сборке"
  fi
fi

# Do not report a complete offline bundle when one of its required payloads is missing.
REQUIRED_COMPONENTS=(
  rootfs.tar.gz
  system-packages-debian-bookworm-arm64.zip
  jdk-17-openjdk-arm64.zip
  android-commandlinetools-11076708.zip
  android-sdk-full.zip
  "gradle-$GRADLE_VER-bin.zip"
  gradle-deps-cache.zip
)
for item in "${REQUIRED_COMPONENTS[@]}"; do
  if [ ! -s "$COMP/$item" ]; then
    echo "ERROR: обязательный компонент не подготовлен: $item"
    exit 48
  fi
done

echo "APKSTUDIO_PROGRESS:94:Проверка инструментов"
echo "=== versions"
java -version 2>&1 | head -1
/opt/gradle/bin/gradle --version 2>&1 | grep -E '^Gradle' || true
/opt/tools/aapt2 version || echo "WARN: aapt2 did not start"
/opt/tools/aapt2 version 2>&1 | head -1 > /opt/aapt2.version || true

touch /opt/.setup-done
echo "APKSTUDIO_PROGRESS:100:Среда готова"
echo "=== Environment ready"
