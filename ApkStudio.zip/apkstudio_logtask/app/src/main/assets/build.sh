#!/bin/bash
set -euo pipefail
XMX=${BUILD_XMX:-2048}
WORKERS=${BUILD_WORKERS:-3}
SRC=/project
W="/root/work/${BUILD_PROJECT_KEY:-project}"

cd "$SRC"
CHANNEL=${BUILD_CHANNEL:-stable}
case "$CHANNEL" in beta) KEY_FILE=/root/.android/beta.keystore; KEY_ALIAS=apkstudio-beta; KEY_PASS=betapass; APP_SUFFIX=.b.app ;; *) CHANNEL=stable; KEY_FILE=/root/.android/stable.keystore; KEY_ALIAS=apkstudio-stable; KEY_PASS=stablepass; APP_SUFFIX=.s.app ;; esac
mkdir -p /root/.android
if [ ! -s "$KEY_FILE" ]; then
  if [ "$CHANNEL" = stable ] && [ -s /root/.android/debug.keystore ]; then
    # Preserve the previous shared project certificate as the initial Stable key,
    # so existing base-package projects retain their historical signing identity.
    cp -n /root/.android/debug.keystore "$KEY_FILE"
    touch /root/.android/stable.legacy-key
    echo "Существующий debug.keystore сохранён как ключ Stable"
  else
    echo "Создание постоянного ключа подписи канала $CHANNEL"
    keytool -genkeypair -v -keystore "$KEY_FILE" -storepass "$KEY_PASS" -keypass "$KEY_PASS" \
      -alias "$KEY_ALIAS" -noprompt -dname "CN=ApkStudio $CHANNEL,O=ApkStudio,C=US" \
      -validity 10000 -keyalg RSA -keysize 2048
  fi
fi
# Never continue with an unreadable keystore or a missing alias: silently
# generating a replacement would make every installed copy non-updatable.
if [ "$CHANNEL" = stable ]; then
  if [ -f /root/.android/stable.legacy-key ]; then
    KEY_PASS=android
    KEY_ALIAS=androiddebugkey
  elif ! keytool -list -keystore "$KEY_FILE" -storepass "$KEY_PASS" -alias "$KEY_ALIAS" >/dev/null 2>&1 \
      && keytool -list -keystore "$KEY_FILE" -storepass android -alias androiddebugkey >/dev/null 2>&1; then
    # Recover the legacy-key mode if an older install copied the keystore but
    # was interrupted before writing its marker.
    touch /root/.android/stable.legacy-key
    KEY_PASS=android
    KEY_ALIAS=androiddebugkey
    echo "Обнаружен прежний сертификат Stable; восстановлен режим совместимости"
  fi
fi
if ! keytool -list -keystore "$KEY_FILE" -storepass "$KEY_PASS" -alias "$KEY_ALIAS" >/dev/null 2>&1; then
  echo "ОШИБКА: ключ подписи $CHANNEL повреждён, пароль неверен или alias $KEY_ALIAS отсутствует. Новый ключ автоматически не создаётся, чтобы не сломать обновления. Восстановите резервную копию из ApkStudio/Signing."
  exit 23
fi
echo "APKSTUDIO_PROGRESS:2:Подготовка канала $CHANNEL"

# Preserve the application ID and advance versionCode for Android updates.
BUILD_FILE=""
[ -f app/build.gradle ] && BUILD_FILE=app/build.gradle
[ -z "$BUILD_FILE" ] && [ -f app/build.gradle.kts ] && BUILD_FILE=app/build.gradle.kts
if [ -n "$BUILD_FILE" ]; then
  CONFIG_CODE=$(sed -nE 's/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*([0-9]+).*$/\1/p' "$BUILD_FILE" | head -n1 || true)
  if [ -n "${CONFIG_CODE:-}" ]; then
    OLD_CODE=$(cat .apkstudio-version-code 2>/dev/null || echo 0)
    [[ "$OLD_CODE" =~ ^[0-9]+$ ]] || OLD_CODE=0
    NEXT_CODE=$(( CONFIG_CODE > OLD_CODE ? CONFIG_CODE + 1 : OLD_CODE + 1 ))
    if [[ "$BUILD_FILE" == *.kts ]]; then
      sed -i -E "0,/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*[0-9]+/s//        versionCode = ${NEXT_CODE}/" "$BUILD_FILE"
    else
      sed -i -E "0,/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*[0-9]+/s//        versionCode ${NEXT_CODE}/" "$BUILD_FILE"
    fi
    printf '%s\n' "$NEXT_CODE" > .apkstudio-version-code
    echo "Автоматический versionCode: $NEXT_CODE"
  else
    echo "WARN: числовой versionCode не найден; автоувеличение пропущено"
  fi
fi

# A changed applicationId is a different Android app, not an update.
APP_ID=""
if [ -n "$BUILD_FILE" ]; then
  APP_ID=$(sed -nE "s/^[[:space:]]*applicationId[[:space:]]*=?[[:space:]]*['\"]([^'\"]+)['\"].*/\1/p" "$BUILD_FILE" | head -n1 || true)
fi
if [ -n "$APP_ID" ]; then
  PREV_ID=$(cat .apkstudio-application-id 2>/dev/null || true)
  if [ -n "$PREV_ID" ] && [ "$PREV_ID" != "$APP_ID" ]; then
    echo "WARN: applicationId изменился с $PREV_ID на $APP_ID — это будет отдельное приложение. Верните прежний ID для обновления поверх."
  fi
  printf '%s\n' "$APP_ID" > .apkstudio-application-id
fi

# A workspace is isolated per project. If a reused project name now points to
# another applicationId, discard only that workspace's stale Gradle outputs.
if [ -n "$APP_ID" ] && [ -s "$W/.apkstudio-workspace-id" ]; then
  WORKSPACE_ID=$(cat "$W/.apkstudio-workspace-id")
  if [ "$WORKSPACE_ID" != "$APP_ID" ]; then
    echo "applicationId изменился в workspace: очищаю только кеш этого проекта"
    rm -rf "$W"
  fi
fi
mkdir -p "$W"
[ -n "$APP_ID" ] && printf '%s\n' "$APP_ID" > "$W/.apkstudio-workspace-id"

# Keep the fast, private Linux workspace and only sync changed source files.
# Build outputs and Gradle caches remain in place for incremental builds.
mkdir -p "$W"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --checksum --delete --exclude='build/' --exclude='.gradle/' --exclude='.git/' \
    --exclude='.apkstudio-*' "$SRC/" "$W/"
else
  echo "WARN: rsync отсутствует; синхронизация без удаления устаревших исходников"
  tar --no-wildcards-match-slash --exclude='./build' --exclude='./.gradle' \
    --exclude='./.git' --exclude='./*/build' --exclude='./*/.gradle' \
    -cf - -C "$SRC" . | tar -C "$W" -xf -
fi
cd "$W"

# Apply a memory-aware heap while retaining the project's other settings.
if [ -f gradle.properties ]; then
  if grep -q '^org.gradle.jvmargs=' gradle.properties; then
    sed -i -E "s/^org\.gradle\.jvmargs=.*/org.gradle.jvmargs=-Xmx${XMX}m -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m/" gradle.properties
  else
    printf '\norg.gradle.jvmargs=-Xmx%sm -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m\n' "$XMX" >> gradle.properties
  fi
else
  printf 'org.gradle.jvmargs=-Xmx%sm -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m\n' "$XMX" > gradle.properties
fi
sed -i -E '/^(org.gradle.caching|org.gradle.parallel|org.gradle.workers.max|org.gradle.daemon|org.gradle.vfs.watch)=/d' gradle.properties
cat >> gradle.properties <<'PROPS'
org.gradle.caching=true
org.gradle.parallel=false
org.gradle.workers.max=3
org.gradle.daemon=true
org.gradle.vfs.watch=false
PROPS

if [ -f gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  G=(sh ./gradlew)
else
  G=(/opt/gradle/bin/gradle)
fi
ARGS=("$@")
if [ ${#ARGS[@]} -eq 0 ]; then ARGS=(assembleDebug); fi

cat > /tmp/apkstudio-progress.init.gradle <<'INIT'
gradle.taskGraph.whenReady { graph ->
    def tasks = graph.allTasks
    def total = Math.max(1, tasks.size())
    def done = 0
    gradle.taskGraph.afterTask { task, state ->
        done++
        def pct = 15 + (70.0 * done / total).intValue()
        println "APKSTUDIO_PROGRESS:${pct}:Задача ${done}/${total}: ${task.path}"
    }
}
INIT

cat > /tmp/apkstudio-channel.init.gradle <<'CHANNEL_INIT'
gradle.beforeProject { p ->
    p.plugins.withId('com.android.application') {
        def components = p.extensions.findByName('androidComponents')
        if (components == null) throw new GradleException('ApkStudio requires Android Gradle Plugin with androidComponents.finalizeDsl support')
        components.finalizeDsl { dsl ->
                def suffix = gradle.startParameter.projectProperties['apkstudioChannelSuffix']
                def baseId = dsl.defaultConfig.applicationId ?: dsl.namespace
                if (baseId == null || baseId.toString().trim().isEmpty()) {
                    throw new GradleException('ApkStudio could not determine applicationId/namespace for channel suffix')
                }
                if (suffix == null) throw new GradleException('ApkStudio channel suffix is missing')
                if (!baseId.endsWith(suffix)) dsl.defaultConfig.applicationId = baseId + suffix
                def channel = gradle.startParameter.projectProperties['apkstudioChannel'] ?: 'stable'
                def cfg = dsl.signingConfigs.findByName('apkstudioChannel')
                if (cfg == null) cfg = dsl.signingConfigs.create('apkstudioChannel')
                cfg.storeFile = new File('/root/.android/' + channel + '.keystore')
                def legacyStable = channel == 'stable' && new File('/root/.android/stable.legacy-key').isFile()
                cfg.storePassword = channel == 'beta' ? 'betapass' : (legacyStable ? 'android' : 'stablepass')
                cfg.keyAlias = channel == 'beta' ? 'apkstudio-beta' : (legacyStable ? 'androiddebugkey' : 'apkstudio-stable')
                cfg.keyPassword = cfg.storePassword
                dsl.buildTypes.each { bt -> bt.signingConfig = cfg }
        }
    }
}
CHANNEL_INIT

echo "APKSTUDIO_PROGRESS:8:Запуск Gradle, повторное использование кеша"
echo "=== ${G[*]} ${ARGS[*]} (канал=$CHANNEL, Xmx${XMX}m, workers=${WORKERS})"
"${G[@]}" --console=plain --stacktrace --max-workers="$WORKERS" --build-cache \
  -PapkstudioChannel="$CHANNEL" -PapkstudioChannelSuffix="$APP_SUFFIX" \
  -I /tmp/apkstudio-progress.init.gradle -I /tmp/apkstudio-channel.init.gradle \
  -Dorg.gradle.parallel=false -Dorg.gradle.vfs.watch=false "${ARGS[@]}"

echo "APKSTUDIO_PROGRESS:90:Подготовка APK и проверка подписи"
OUT="$SRC/build/apk"
mkdir -p "$OUT"
find "$OUT" -maxdepth 1 -type f -name '*.apk' -delete
find "$W" -path '*/build/outputs/apk/*' -type f -name '*.apk' -exec cp -f {} "$OUT/" \;
if ! find "$OUT" -maxdepth 1 -type f -name '*.apk' | grep -q .; then
  echo "APK не найден в build/outputs/apk"
  exit 2
fi
ls -lh "$OUT"/*.apk
if [ -x /opt/android-sdk/build-tools/34.0.0/apksigner ]; then
  for apk in "$OUT"/*.apk; do
    echo "=== Подпись: $(basename "$apk")"
    /opt/android-sdk/build-tools/34.0.0/apksigner verify --print-certs "$apk" 2>&1 | grep -E 'Signer #1 certificate SHA-256 digest|Verified' || true
  done
fi
echo "APKSTUDIO_PROGRESS:98:APK готов, ключ подписи сохранён"
