# ApkStudio

Сборка Android-проектов на смартфоне настоящим Gradle, как в GitHub Actions.

Внутри приложения: Debian arm64 (rootfs) запускается через proot; в нём JDK 17, Android SDK (platforms;android-34, build-tools;34.0.0) и Gradle 8.9. aapt2 для AGP подменяется на aarch64-версию (`android.aapt2FromMavenOverride`). Проекты с Kotlin, AAR, Maven-зависимостями, плагинами и flavors собираются тем же `gradle assembleDebug`.

## Сборка самого ApkStudio на GitHub

1. Загрузите содержимое архива в репозиторий.
2. Actions → Build APK → артефакт `ApkStudio-debug`.

Шаг `tools/fetch-deps.sh` кладёт в APK: proot + loader + libtalloc (из репозитория Termux), aarch64 aapt2 (lzhiyong/android-sdk-tools 35.0.2) и Debian bookworm arm64 rootfs. Любая недоступная ссылка валит сборку с понятным сообщением.

## Использование

1. Меню «Среда» → «Установить»: распаковка rootfs, затем apt (JDK), SDK и Gradle из интернета. Один раз, около 1–1.5 ГБ, нужен Wi-Fi.
2. Создайте шаблонный проект или импортируйте ZIP (подходит ZIP репозитория с GitHub).
3. Build: выполняется `gradle <аргументы>` (по умолчанию `assembleDebug`; если в проекте есть `gradlew` и wrapper jar, используется он).
4. Готовые APK: `<проект>/build/apk/`. Install устанавливает последний debug APK.

Проекты лежат в `Android/data/app.apkstudio/files/projects/`. Перед сборкой исходники копируются во внутреннюю память (быстрее), кеши Gradle сохраняются между сборками.

Кнопка «Среда» также даёт shell внутри Linux для отладки.

## Ограничения

- Только arm64-v8a устройства, Android 8.0+. Нужно свободное место 3+ ГБ и 4+ ГБ RAM для комфортной работы.
- `targetSdk` самого ApkStudio = 28: иначе Android 10+ запрещает запуск бинарников из хранилища приложения.
- proot медленнее нативного Linux; сборка небольшого проекта занимает минуты. Heap Gradle выставляется автоматически (1–3 ГБ).
- Android 12+ может убивать дочерние процессы (phantom process killer). Если сборка обрывается без ошибки: отладка по USB → `adb shell settings put global settings_enable_monitor_phantom_procs false`.
- Проекты с NDK/CMake не соберутся (инструменты NDK под x86).
- Подпись release-сборок нужно настраивать в проекте самостоятельно; debug подписывается автоматически.
