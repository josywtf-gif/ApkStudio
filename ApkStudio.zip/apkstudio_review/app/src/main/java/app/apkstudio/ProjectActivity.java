package app.apkstudio;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import java.security.MessageDigest;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProjectActivity extends LogActivity {
    private File project;
    private Linux linux;
    private final List<String> files = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private EditText tasks;
    private Button bBuild, bCancel;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        project = new File(Util.projectsDir(this), getIntent().getStringExtra("name"));
        linux = new Linux(this);
        setTitle(project.getName());

        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        LinearLayout row = new LinearLayout(this);
        bBuild = new Button(this);
        bBuild.setText("Собрать"); Ui.button(bBuild, this, true);
        Button bInstall = new Button(this);
        bInstall.setText("Установить"); Ui.button(bInstall, this, false);
        bCancel = new Button(this);
        bCancel.setText("Стоп"); Ui.button(bCancel, this, false);
        Button bAdd = new Button(this);
        bAdd.setText("+ Файл"); Ui.button(bAdd, this, false);
        row.addView(bBuild, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bInstall, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bCancel, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bAdd, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        tasks = new EditText(this);
        tasks.setSingleLine(); Ui.input(tasks, this);
        tasks.setText("assembleDebug");
        tasks.setHint("Gradle-аргументы");
        root.addView(tasks);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, files);
        list.setAdapter(adapter);
        list.setDivider(new android.graphics.drawable.ColorDrawable(0x22394B65));
        list.setDividerHeight(dp(1));
        list.setSelector(android.R.color.transparent);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(makeProgressView());
        Ui.gap(root, this, 8);
        root.addView(makeLogCard());
        setContentView(root);

        bBuild.setOnClickListener(v -> build());
        bInstall.setOnClickListener(v -> install());
        bCancel.setOnClickListener(v -> Runner.get().cancel());
        bAdd.setOnClickListener(v -> addFileDialog());
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, EditorActivity.class);
            i.putExtra("project", project.getPath());
            i.putExtra("path", files.get(pos));
            startActivity(i);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String rel = files.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Удалить " + rel + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        new File(project, rel).delete();
                        refresh();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    void stateChanged(boolean running) {
        bBuild.setEnabled(!running);
        bCancel.setEnabled(running);
        if (!running) refresh();
    }

    private void refresh() {
        files.clear();
        Util.listFiles(project, project, files);
        adapter.notifyDataSetChanged();
    }

    private void build() {
        if (!linux.installed()) {
            Toast.makeText(this, "Сначала установите среду сборки", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, EnvActivity.class));
            return;
        }
        String t = tasks.getText().toString().trim();
        List<String> args = t.isEmpty() ? new ArrayList<>() : new ArrayList<>(Arrays.asList(t.split("\\s+")));
        Runner.get().clear();
        logView.setText("");
        Runner.get().start(this, "Сборка " + project.getName(), log -> linux.build(log, project, args));
    }

    private File latestApk() {
        File[] apks = new File(project, "build/apk").listFiles((d, n) -> n.endsWith(".apk"));
        if (apks == null || apks.length == 0) return null;
        File best = apks[0];
        for (File f : apks) {
            boolean fd = f.getName().contains("debug");
            boolean bd = best.getName().contains("debug");
            if ((fd && !bd) || (fd == bd && f.lastModified() > best.lastModified())) best = f;
        }
        return best;
    }

    private void install() {
        File apk = latestApk();
        if (apk == null) {
            Toast.makeText(this, "Сначала соберите APK", Toast.LENGTH_LONG).show();
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Разрешите установку из этого источника", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        try {
            int flags = Build.VERSION.SDK_INT >= 28
                    ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            PackageInfo candidate = getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            if (candidate == null) throw new Exception("Не удалось прочитать APK");
            String pkg = candidate.packageName;
            long version = Build.VERSION.SDK_INT >= 28 ? candidate.getLongVersionCode() : candidate.versionCode;
            String cert = certificateFingerprint(candidate);
            StringBuilder report = new StringBuilder("Пакет: ").append(pkg)
                    .append("\nВерсия: ").append(version)
                    .append("\nПодпись SHA-256: ").append(cert);
            try {
                PackageInfo installed = getPackageManager().getPackageInfo(pkg, flags);
                long installedVersion = Build.VERSION.SDK_INT >= 28 ? installed.getLongVersionCode() : installed.versionCode;
                String installedCert = certificateFingerprint(installed);
                report.append("\nУстановлена версия: ").append(installedVersion);
                if (!cert.equals(installedCert)) {
                    new AlertDialog.Builder(this).setTitle("Подпись не совпадает")
                            .setMessage(report + "\n\nAndroid не разрешит обновление поверх установленной версии: сертификаты разные. Для обновления без удаления восстановите прежний ключ. Если он потерян, Android потребует удалить старую версию; данные приложения могут быть потеряны.")
                            .setPositiveButton("Понятно", null).show();
                    return;
                }
                if (version < installedVersion) {
                    new AlertDialog.Builder(this).setTitle("Версия ниже установленной")
                            .setMessage(report + "\n\nСборка получила меньший versionCode. Пересоберите проект — ApkStudio автоматически увеличивает versionCode при каждой сборке.")
                            .setPositiveButton("Понятно", null).show();
                    return;
                }
                report.append("\n\nПодпись совпадает — можно обновить приложение.");
            } catch (PackageManager.NameNotFoundException notInstalled) {
                report.append("\n\nПриложение ещё не установлено — будет выполнена первая установка.");
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка проверки APK: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String certificateFingerprint(PackageInfo info) throws Exception {
        Signature[] signatures;
        if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
            signatures = info.signingInfo.getApkContentsSigners();
        } else {
            signatures = info.signatures;
        }
        if (signatures == null || signatures.length == 0) return "неизвестно";
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray());
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format(java.util.Locale.US, "%02X", b & 0xff));
        return out.toString();
    }

    private void addFileDialog() {
        EditText et = new EditText(this);
        et.setHint("например app/src/main/res/layout/main.xml");
        et.setSingleLine(); Ui.input(et, this);
        new AlertDialog.Builder(this)
                .setTitle("Новый файл")
                .setView(et)
                .setPositiveButton("Создать", (d, w) -> {
                    String rel = et.getText().toString().trim();
                    if (rel.isEmpty()) return;
                    try {
                        File f = new File(project, rel);
                        if (!f.getCanonicalPath().startsWith(project.getCanonicalPath() + File.separator)) {
                            throw new Exception("Недопустимый путь");
                        }
                        if (!f.exists()) Util.write(f, "");
                        refresh();
                    } catch (Exception e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}
