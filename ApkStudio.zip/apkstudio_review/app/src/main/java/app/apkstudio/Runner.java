package app.apkstudio;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;

import java.util.concurrent.CopyOnWriteArrayList;

/** Single background job with a shared log that survives Activity recreation. */
final class Runner {
    interface Log { void log(String line); }
    interface Task { void run(Log log) throws Exception; }
    interface Listener {
        void onLog(String line);
        void onState(boolean running);
        void onProgress(int percent, String message);
    }

    private static final Runner I = new Runner();
    private static final int MAX_LOG = 300_000;

    static Runner get() { return I; }

    private final StringBuilder buf = new StringBuilder();
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private boolean running;
    private int progress;
    private String progressMessage = "Ожидание";

    private Runner() {}

    synchronized boolean isRunning() { return running; }
    synchronized int getProgress() { return progress; }
    synchronized String getProgressMessage() { return progressMessage; }

    synchronized String attach(Listener l) {
        listeners.add(l);
        return buf.toString();
    }

    void detach(Listener l) { listeners.remove(l); }

    synchronized void clear() { buf.setLength(0); }

    void log(String line) {
        if (line != null && line.startsWith("APKSTUDIO_PROGRESS:")) {
            try {
                String[] a = line.split(":", 3);
                int pct = Math.max(0, Math.min(100, Integer.parseInt(a[1])));
                String msg = a.length > 2 ? a[2] : "Выполнение";
                synchronized (this) { progress = pct; progressMessage = msg; }
                for (Listener l : listeners) l.onProgress(pct, msg);
            } catch (Exception ignored) {}
        }
        synchronized (this) {
            buf.append(line).append('\n');
            if (buf.length() > MAX_LOG) buf.delete(0, buf.length() - MAX_LOG / 2);
        }
        for (Listener l : listeners) l.onLog(line);
    }

    void cancel() {
        Process p = Linux.current;
        if (p != null) p.destroyForcibly();
    }

    boolean start(Context ctx, String title, Task task) {
        final Context app = ctx.getApplicationContext();
        synchronized (this) {
            if (running) return false;
            running = true;
            progress = 0;
            progressMessage = "Запуск";
        }
        for (Listener l : listeners) { l.onProgress(0, "Запуск"); l.onState(true); }

        final Intent svc = new Intent(app, KeepAliveService.class).putExtra("title", title);
        try {
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(svc);
            else app.startService(svc);
        } catch (Exception e) {
            log("WARN: foreground service: " + e);
        }
        PowerManager.WakeLock wl = null;
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apkstudio:job");
            wl.acquire(3L * 60 * 60 * 1000);
        } catch (Exception ignored) {
            // wake lock is best-effort
        }
        final PowerManager.WakeLock lock = wl;

        new Thread(null, () -> {
            try {
                log("=== " + title);
                task.run(this::log);
                log("APKSTUDIO_PROGRESS:100:Готово");
                log("=== OK");
            } catch (Throwable t) {
                log("=== FAILED: " + t);
                for (StackTraceElement frame : t.getStackTrace()) log("  at " + frame);
            } finally {
                Linux.current = null;
                synchronized (this) { running = false; if (progress < 100) progressMessage = "Остановлено или завершено с ошибкой"; }
                try {
                    if (lock != null && lock.isHeld()) lock.release();
                } catch (Exception ignored) {
                    // already released
                }
                try {
                    Intent stop = new Intent(app, KeepAliveService.class).putExtra("stop", true);
                    if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(stop);
                    else app.startService(stop);
                } catch (Exception e) {
                    app.stopService(svc);
                }
                for (Listener l : listeners) l.onState(false);
            }
        }, "job", 16L * 1024 * 1024).start();
        return true;
    }
}
