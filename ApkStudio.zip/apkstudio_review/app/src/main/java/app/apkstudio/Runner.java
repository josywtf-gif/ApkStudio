package app.apkstudio;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;

import java.util.concurrent.CopyOnWriteArrayList;

/** Single background job with a shared log that survives Activity recreation. */
final class Runner {
    interface Log { void log(String line); }
    interface Task { void run(Log log) throws Exception; }
    interface Listener {
        void onLog(String line);
        void onState(boolean running);
        void onProgress(int percent, String message);
    }

    private static final Runner I = new Runner();
    private static final int MAX_LOG = 300_000;

    static Runner get() { return I; }

    private final StringBuilder buf = new StringBuilder();
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private boolean running;
    private boolean hasResult;
    private int progress;
    private String progressMessage = "Ожидание";

    private Runner() {}

    synchronized boolean isRunning() { return running; }
    synchronized boolean hasResult() { return hasResult; }
    synchronized int getProgress() { return progress; }
    synchronized String getProgressMessage() { return progressMessage; }

    synchronized String attach(Listener l) {
        listeners.add(l);
        return buf.toString();
    }

    void detach(Listener l) { listeners.remove(l); }

    synchronized void clear() { buf.setLength(0); hasResult = false; }

    void log(String line) {
        if (line != null && line.startsWith("APKSTUDIO_PROGRESS:")) {
            try {
                String[] a = line.split(":", 3);
                int pct = Math.max(0, Math.min(100, Integer.parseInt(a[1])));
                String msg = a.length > 2 ? a[2] : "Выполнение";
                synchronized (this) { progress = pct; progressMessage = msg; }
                for (Listener l : listeners) l.onProgress(pct, msg);
            } catch (Exception ignored) {}
        }
        synchronized (this) {
            buf.append(line).append('\n');
            if (buf.length() > MAX_LOG) buf.delete(0, buf.length() - MAX_LOG / 2);
        }
        for (Listener l : listeners) l.onLog(line);
    }

    void cancel() {
        Process p = Linux.current;
        if (p != null) p.destroyForcibly();
    }

    boolean start(Context ctx, String title, Task task) {
        final Context app = ctx.getApplicationContext();
        synchronized (this) {
            if (running) return false;
            running = true;
            hasResult = false;
            progress = 0;
            progressMessage = "Запуск";
        }
        for (Listener l : listeners) { l.onProgress(0, "Запуск"); l.onState(true); }

        final Intent svc = new Intent(app, KeepAliveService.class).putExtra("title", title);
        try {
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(svc);
            else app.startService(svc);
        } catch (Exception e) {
            log("WARN: foreground service: " + e);
        }
        PowerManager.WakeLock wl = null;
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apkstudio:job");
            wl.acquire(3L * 60 * 60 * 1000);
        } catch (Exception ignored) {
            // wake lock is best-effort
        }
        final PowerManager.WakeLock lock = wl;

        new Thread(null, () -> {
            try {
                log("=== " + title);
                task.run(this::log);
                log("APKSTUDIO_PROGRESS:100:Готово");
                log("=== OK");
                log("✔ ГОТОВО: " + title + " — без ошибок");
                synchronized (this) { hasResult = true; }
            } catch (Throwable t) {
                log("=== FAILED: " + t);
                for (StackTraceElement frame : t.getStackTrace()) log("  at " + frame);
                log("✖ ОШИБКА: " + title + " не выполнено");
                for (String reason : reasons(t)) log("✖ " + reason);
                synchronized (this) { hasResult = true; }
            } finally {
                Linux.current = null;
                synchronized (this) { running = false; if (progress < 100) progressMessage = "Остановлено или завершено с ошибкой"; }
                try {
                    if (lock != null && lock.isHeld()) lock.release();
                } catch (Exception ignored) {
                    // already released
                }
                try {
                    Intent stop = new Intent(app, KeepAliveService.class).putExtra("stop", true);
                    if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(stop);
                    else app.startService(stop);
                } catch (Exception e) {
                    app.stopService(svc);
                }
                for (Listener l : listeners) l.onState(false);
            }
        }, "job", 16L * 1024 * 1024).start();
        return true;
    }

    /** Short human-readable cause: compiler errors / Gradle "What went wrong" / exception text. */
    private java.util.List<String> reasons(Throwable t) {
        java.util.List<String> out = new java.util.ArrayList<>();
        String[] lines;
        synchronized (this) { lines = buf.toString().split("\n"); }
        for (int i = 0; i < lines.length && out.size() < 8; i++) {
            String l = lines[i];
            if (l.matches(".*\\.(java|kt):\\d+: (error|warning: \\[).*") && l.contains(": error:")) {
                out.add(l.replaceAll("^.*/(?=[^/]+\\.(java|kt):)", "").trim());
                for (int j = i + 1; j < Math.min(lines.length, i + 6); j++) {
                    String n = lines[j].trim();
                    if (n.startsWith("symbol:") || n.startsWith("location:")) out.add("   " + n);
                }
            } else if (l.startsWith("* What went wrong:")) {
                for (int j = i + 1; j < Math.min(lines.length, i + 4); j++) {
                    String n = lines[j].trim();
                    if (n.isEmpty() || n.startsWith("* Try")) break;
                    out.add(n);
                }
            } else if (l.startsWith("Процесс завершился с кодом") || l.startsWith("APK не найден")) {
                out.add(l.trim());
            }
        }
        if (out.isEmpty()) {
            String m = t.getMessage();
            out.add(m != null && !m.isEmpty() ? m : t.toString());
        }
        return out;
    }
}
