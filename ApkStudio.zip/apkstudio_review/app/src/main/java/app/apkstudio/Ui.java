package app.apkstudio;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small native-only design system; no extra runtime dependencies. */
final class Ui {
    static final int BG = Color.rgb(10, 15, 26);
    static final int SURFACE = Color.rgb(18, 27, 43);
    static final int SURFACE_2 = Color.rgb(25, 37, 57);
    static final int TEXT = Color.rgb(235, 241, 250);
    static final int MUTED = Color.rgb(151, 166, 188);
    static final int ACCENT = Color.rgb(104, 220, 190);
    static final int BLUE = Color.rgb(112, 145, 255);
    static final int DANGER = Color.rgb(255, 112, 130);

    private Ui() {}

    static void apply(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        a.getWindow().getDecorView().setSystemUiVisibility(0);
    }

    static GradientDrawable shape(int color, int stroke, int radiusDp, float density) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        if (stroke != 0) d.setStroke(Math.max(1, (int) density), stroke);
        return d;
    }

    static void page(LinearLayout root, Activity a) {
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 16));
        root.setBackgroundColor(BG);
    }

    static LinearLayout card(Activity a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12));
        box.setBackground(shape(SURFACE, Color.rgb(39, 53, 75), 18, a.getResources().getDisplayMetrics().density));
        return box;
    }

    static void title(TextView v, float size) {
        v.setTextColor(TEXT);
        v.setTextSize(size);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
    }

    static void body(TextView v) {
        v.setTextColor(TEXT);
        v.setTextSize(14);
    }

    static void muted(TextView v) {
        v.setTextColor(MUTED);
        v.setTextSize(12);
    }

    static void button(Button b, Activity a, boolean primary) {
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setStateListAnimator(null);
        b.setSingleLine(true);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(8, 25, 29) : TEXT);
        b.setMinHeight(dp(a, 46));
        b.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
        b.setBackground(shape(primary ? ACCENT : SURFACE_2,
                primary ? ACCENT : Color.rgb(51, 68, 94), 14,
                a.getResources().getDisplayMetrics().density));
    }

    static void input(EditText e, Activity a) {
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(14);
        e.setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10));
        e.setBackground(shape(SURFACE_2, Color.rgb(51, 68, 94), 12,
                a.getResources().getDisplayMetrics().density));
    }

    static int dp(Activity a, int n) {
        return (int) (n * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    static void gap(LinearLayout parent, Activity a, int height) {
        View v = new View(a);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(a, height)));
    }

    /** Top app bar in the same colour as the status bar: [←] title / subtitle [action]. */
    static LinearLayout header(Activity a, String title, String subtitle, boolean back, Button right) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, 0, dp(a, 12));
        if (back) {
            TextView b = new TextView(a);
            b.setText("←");
            b.setTextColor(TEXT);
            b.setTextSize(20);
            b.setGravity(android.view.Gravity.CENTER);
            b.setBackground(shape(SURFACE_2, Color.rgb(51, 68, 94), 12, a.getResources().getDisplayMetrics().density));
            b.setOnClickListener(v -> a.finish());
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(a, 40), dp(a, 40));
            bp.rightMargin = dp(a, 12);
            bar.addView(b, bp);
        }
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(a);
        t.setText(title);
        title(t, 19);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t);
        if (subtitle != null) {
            TextView s = new TextView(a);
            s.setText(subtitle);
            s.setTextColor(ACCENT);
            s.setTextSize(10);
            s.setLetterSpacing(0.1f);
            s.setSingleLine(true);
            col.addView(s);
        }
        bar.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, dp(a, 40));
            rp.leftMargin = dp(a, 10);
            bar.addView(right, rp);
        }
        box.addView(bar);
        View line = new View(a);
        line.setBackgroundColor(Color.rgb(32, 45, 66));
        box.addView(line, new LinearLayout.LayoutParams(-1, Math.max(1, dp(a, 1))));
        gap(box, a, 14);
        return box;
    }

    /** Equal-width buttons in one row with 8dp gaps. */
    static LinearLayout row(Activity a, View... views) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < views.length; i++) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(a, 48), 1);
            if (i > 0) p.leftMargin = dp(a, 4);
            if (i < views.length - 1) p.rightMargin = dp(a, 4);
            r.addView(views[i], p);
        }
        return r;
    }

    static void add(LinearLayout root, View v, Activity a, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(a, topDp);
        root.addView(v, p);
    }

    static void styleList(android.widget.ListView l, Activity a) {
        l.setDivider(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        l.setDividerHeight(dp(a, 8));
        l.setSelector(android.R.color.transparent);
        l.setVerticalScrollBarEnabled(false);
        l.setClipToPadding(false);
    }

    static android.widget.ArrayAdapter<String> cardAdapter(Activity a, java.util.List<String> items) {
        return new android.widget.ArrayAdapter<String>(a, android.R.layout.simple_list_item_1, items) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(TEXT);
                v.setTextSize(14);
                v.setSingleLine(true);
                v.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                v.setPadding(dp(a, 14), dp(a, 14), dp(a, 14), dp(a, 14));
                v.setBackground(shape(SURFACE, Color.rgb(32, 45, 66), 12, a.getResources().getDisplayMetrics().density));
                return v;
            }
        };
    }
}
