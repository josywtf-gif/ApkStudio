package app.apkstudio;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small native-only design system; no extra runtime dependencies. */
final class Ui {
    static final int BG = Color.rgb(10, 15, 26);
    static final int SURFACE = Color.rgb(18, 27, 43);
    static final int SURFACE_2 = Color.rgb(25, 37, 57);
    static final int TEXT = Color.rgb(235, 241, 250);
    static final int MUTED = Color.rgb(151, 166, 188);
    static final int ACCENT = Color.rgb(104, 220, 190);
    static final int BLUE = Color.rgb(112, 145, 255);
    static final int DANGER = Color.rgb(255, 112, 130);

    private Ui() {}

    static void apply(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        a.getWindow().getDecorView().setSystemUiVisibility(0);
    }

    static GradientDrawable shape(int color, int stroke, int radiusDp, float density) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        if (stroke != 0) d.setStroke(Math.max(1, (int) density), stroke);
        return d;
    }

    static void page(LinearLayout root, Activity a) {
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 16));
        root.setBackgroundColor(BG);
    }

    static LinearLayout card(Activity a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12));
        box.setBackground(shape(SURFACE, Color.rgb(39, 53, 75), 18, a.getResources().getDisplayMetrics().density));
        return box;
    }

    static void title(TextView v, float size) {
        v.setTextColor(TEXT);
        v.setTextSize(size);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
    }

    static void body(TextView v) {
        v.setTextColor(TEXT);
        v.setTextSize(14);
    }

    static void muted(TextView v) {
        v.setTextColor(MUTED);
        v.setTextSize(12);
    }

    static void button(Button b, Activity a, boolean primary) {
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(8, 25, 29) : TEXT);
        b.setMinHeight(dp(a, 46));
        b.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
        b.setBackground(shape(primary ? ACCENT : SURFACE_2,
                primary ? ACCENT : Color.rgb(51, 68, 94), 14,
                a.getResources().getDisplayMetrics().density));
    }

    static void input(EditText e, Activity a) {
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(14);
        e.setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10));
        e.setBackground(shape(SURFACE_2, Color.rgb(51, 68, 94), 12,
                a.getResources().getDisplayMetrics().density));
    }

    static int dp(Activity a, int n) {
        return (int) (n * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    static void gap(LinearLayout parent, Activity a, int height) {
        View v = new View(a);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(a, height)));
    }
}
