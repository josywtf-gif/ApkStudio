package app.apkstudio;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

import java.io.File;

public class EnvActivity extends LogActivity {
    private Linux linux;
    private TextView status;
    private Button bSetup, bRemove, bCancel, bRun, bComponents;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        setTitle("Среда сборки");
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        status = new TextView(this);
        Ui.body(status);
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        bSetup = new Button(this);
        bSetup.setText("Установить"); Ui.button(bSetup, this, true);
        bRemove = new Button(this);
        bRemove.setText("Удалить"); Ui.button(bRemove, this, false);
        bCancel = new Button(this);
        bCancel.setText("Стоп"); Ui.button(bCancel, this, false);
        row.addView(bSetup, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bRemove, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bCancel, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        bComponents = new Button(this);
        bComponents.setText("Архивы компонентов"); Ui.button(bComponents, this, false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(8);
        root.addView(bComponents, cp);

        LinearLayout sh = new LinearLayout(this);
        EditText cmd = new EditText(this);
        cmd.setHint("shell-команда в Linux"); Ui.input(cmd, this);
        cmd.setSingleLine();
        bRun = new Button(this);
        bRun.setText("Выполнить"); Ui.button(bRun, this, false);
        sh.addView(cmd, new LinearLayout.LayoutParams(0, -2, 1));
        sh.addView(bRun, new LinearLayout.LayoutParams(-2, -2));
        root.addView(sh);

        root.addView(makeProgressView());
        Ui.gap(root, this, 8);
        root.addView(makeLogCard());
        setContentView(root);

        File crash = new File(getFilesDir(), "crash.txt");
        if (crash.isFile()) {
            try {
                Runner.get().log("=== Последний сбой приложения:\n" + Util.read(crash));
            } catch (Exception ignored) {
                // unreadable crash file
            }
            crash.delete();
        }

        bSetup.setOnClickListener(v -> {
            Runner.get().clear();
            logView.setText("");
            Runner.get().start(this, "Установка среды", log -> linux.setup(log));
        });
        bRemove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Удалить Linux-среду (~1.5 ГБ)?")
                .setPositiveButton("Удалить", (d, w) -> {
                    Runner.get().start(this, "Удаление среды", log -> {
                        linux.remove();
                        log.log("Удалено");
                    });
                })
                .setNegativeButton("Отмена", null)
                .show());
        bCancel.setOnClickListener(v -> Runner.get().cancel());
        bComponents.setOnClickListener(v -> showComponents());
        bRun.setOnClickListener(v -> {
            String c = cmd.getText().toString().trim();
            if (c.isEmpty()) return;
            if (!linux.unpacked()) {
                Toast.makeText(this, "Сначала установите среду", Toast.LENGTH_LONG).show();
                return;
            }
            Runner.get().start(this, "shell", log -> {
                log.log("$ " + c);
                linux.shell(log, null, c);
            });
        });
    }


    private void showComponents() {
        File dir = Util.componentDir(this);
        File[] files = dir.listFiles((d, name) -> name.toLowerCase(java.util.Locale.ROOT).endsWith(".zip"));
        java.util.Arrays.sort(files == null ? new File[0] : files);
        java.util.List<String> rows = new ArrayList<>();
        if (files != null) for (File f : files) {
            rows.add(f.getName() + "  ·  " + android.text.format.Formatter.formatFileSize(this, f.length()));
        }
        String message = rows.isEmpty()
                ? "Архивы появятся здесь после установки среды. При следующей установке ApkStudio будет восстанавливать инструменты из этих ZIP, если версия совпадает."
                : "Папка: " + dir.getAbsolutePath() + "\n\n" + android.text.TextUtils.join("\n", rows);
        new AlertDialog.Builder(this).setTitle("Component · кеш инструментов")
                .setMessage(message).setPositiveButton("Понятно", null).show();
    }

    @Override
    void stateChanged(boolean running) {
        String s = linux.installed() ? "Среда установлена"
                : linux.unpacked() ? "rootfs распакован, SDK/JDK/Gradle не установлены"
                : "Среда не установлена";
        status.setText(s + (running ? " (выполняется задача)" : ""));
        bSetup.setEnabled(!running);
        bRemove.setEnabled(!running);
        bRun.setEnabled(!running);
        bCancel.setEnabled(running);
        bSetup.setText(linux.installed() ? "Обновить" : "Установить");
    }
}
