package app.apkstudio;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

import java.io.File;

public class EnvActivity extends LogActivity {
    private Linux linux;
    private TextView status, componentsView;
    private Button bSetup, bRemove, bCancel, bRun, bComponents;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        root.addView(Ui.header(this, "Среда сборки", "BUILD ENVIRONMENT", true, null));
        status = new TextView(this);
        Ui.body(status);
        LinearLayout statusCard = Ui.card(this);
        statusCard.addView(status);
        root.addView(statusCard);

        TextView compTitle = new TextView(this);
        compTitle.setText("Установленные компоненты"); Ui.title(compTitle, 15);
        componentsView = new TextView(this);
        Ui.body(componentsView);
        componentsView.setTypeface(android.graphics.Typeface.MONOSPACE);
        componentsView.setTextSize(12);
        LinearLayout compCard = Ui.card(this);
        compCard.addView(compTitle);
        compCard.addView(componentsView);
        Ui.add(root, compCard, this, 8);

        bSetup = new Button(this);
        bSetup.setText("Установить"); Ui.button(bSetup, this, true);
        bRemove = new Button(this);
        bRemove.setText("Удалить"); Ui.button(bRemove, this, false);
        bCancel = new Button(this);
        bCancel.setText("Стоп"); Ui.button(bCancel, this, false);
        Ui.add(root, Ui.row(this, bSetup, bRemove, bCancel), this, 12);

        bComponents = new Button(this);
        bComponents.setText("Архивы компонентов"); Ui.button(bComponents, this, false);
        Ui.add(root, bComponents, this, 8);

        LinearLayout sh = new LinearLayout(this);
        EditText cmd = new EditText(this);
        cmd.setHint("shell-команда в Linux"); Ui.input(cmd, this);
        cmd.setSingleLine();
        bRun = new Button(this);
        bRun.setText("Выполнить"); Ui.button(bRun, this, false);
        sh.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sh.addView(cmd, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, dp(48));
        rp.leftMargin = dp(8);
        sh.addView(bRun, rp);
        Ui.add(root, sh, this, 8);

        Ui.add(root, makeProgressView(), this, 12);
        Ui.add(root, makeLogCard(), this, 8);
        setContentView(root);

        File crash = new File(getFilesDir(), "crash.txt");
        if (crash.isFile()) {
            try {
                Runner.get().claim(owner());
                Runner.get().log("=== Последний сбой приложения:\n" + Util.read(crash));
            } catch (Exception ignored) {
                // unreadable crash file
            }
            crash.delete();
        }

        bSetup.setOnClickListener(v -> {
            Runner.get().clear();
            logView.setText("");
            Runner.get().start(this, owner(), "Установка среды", log -> linux.setup(log));
        });
        bRemove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Удалить Linux-среду (~1.5 ГБ)?")
                .setPositiveButton("Удалить", (d, w) -> {
                    Runner.get().start(this, owner(), "Удаление среды", log -> {
                        linux.remove();
                        log.log("Удалено");
                    });
                })
                .setNegativeButton("Отмена", null)
                .show());
        bCancel.setOnClickListener(v -> Runner.get().cancel());
        bComponents.setOnClickListener(v -> showComponents());
        bRun.setOnClickListener(v -> {
            String c = cmd.getText().toString().trim();
            if (c.isEmpty()) return;
            if (!linux.unpacked()) {
                Toast.makeText(this, "Сначала установите среду", Toast.LENGTH_LONG).show();
                return;
            }
            Runner.get().start(this, owner(), "shell", log -> {
                log.log("$ " + c);
                linux.shell(log, null, c);
            });
        });
    }


    private void showComponents() {
        File dir = Util.componentDir(this);
        File[] files = dir.listFiles();
        java.util.Arrays.sort(files == null ? new File[0] : files);
        java.util.List<String> rows = new ArrayList<>();
        if (files != null) for (File f : files) {
            if (f.isFile()) rows.add(f.getName() + "  ·  " + android.text.format.Formatter.formatFileSize(this, f.length()));
        }
        String message = rows.isEmpty()
                ? "Загруженные компоненты появятся здесь после установки среды. Они будут повторно использоваться при следующих сборках."
                : "Папка: " + dir.getAbsolutePath() + "\n\n" + android.text.TextUtils.join("\n", rows);
        new AlertDialog.Builder(this).setTitle("components · кеш инструментов")
                .setMessage(message).setPositiveButton("Понятно", null).show();
    }

    @Override
    String owner() { return "env"; }

    @Override
    void stateChanged(boolean running) {
        String s = linux.installed() ? "Среда установлена"
                : linux.unpacked() ? "rootfs распакован, SDK/JDK/Gradle не установлены"
                : "Среда не установлена";
        status.setText(s + (running ? " (выполняется задача)" : ""));
        bSetup.setEnabled(!running);
        bRemove.setEnabled(!running);
        bRun.setEnabled(!running);
        bCancel.setEnabled(running);
        bSetup.setText(linux.installed() ? "Обновить" : "Установить");
        if (!running) loadComponents();
    }

    private void loadComponents() {
        new Thread(() -> {
            java.util.List<String[]> list = linux.components();
            StringBuilder sb = new StringBuilder();
            for (String[] c : list) sb.append(c[0]).append(": ").append(c[1]).append('\n');
            String text = list.isEmpty() ? "Среда не установлена" : sb.toString().trim();
            runOnUiThread(() -> componentsView.setText(text));
        }).start();
    }
}
