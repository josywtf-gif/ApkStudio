package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact, collapsible job panel shared by setup and build screens. */
abstract class LogActivity extends Activity implements Runner.Listener {
    protected TextView logView;
    protected ScrollView logScroll;
    private ProgressBar progressBar;
    private TextView progressText;
    private LinearLayout jobPanel;
    private LinearLayout logCard;
    private Button toggleLog;
    private boolean logExpanded = true;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder pendingLog = new StringBuilder();
    private boolean flushPosted;

    protected int dp(int v) { return Ui.dp(this, v); }

    protected LinearLayout makeProgressView() {
        jobPanel = Ui.card(this);
        jobPanel.setVisibility(android.view.View.GONE);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        progressText = new TextView(this);
        progressText.setText("Ожидание");
        progressText.setTextColor(Ui.TEXT);
        progressText.setTextSize(12);
        head.addView(progressText, new LinearLayout.LayoutParams(0, -2, 1));
        toggleLog = new Button(this);
        toggleLog.setText("Лог ↓");
        Ui.button(toggleLog, this, false);
        toggleLog.setOnClickListener(v -> setLogExpanded(!logExpanded));
        head.addView(toggleLog, new LinearLayout.LayoutParams(-2, dp(38)));
        jobPanel.addView(head);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(7));
        pp.topMargin = dp(10);
        jobPanel.addView(progressBar, pp);
        return jobPanel;
    }

    protected ScrollView makeLogView() {
        logCard = Ui.card(this);
        logCard.setVisibility(android.view.View.GONE);
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10.5f);
        logView.setTextColor(android.graphics.Color.rgb(185, 204, 222));
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.setFillViewport(false);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.addView(logView);
        logCard.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(132)));
        return logScroll;
    }

    protected LinearLayout makeLogCard() {
        makeLogView();
        return logCard;
    }

    private void setLogExpanded(boolean expanded) {
        logExpanded = expanded;
        if (toggleLog != null) toggleLog.setText(expanded ? "Свернуть ↑" : "Лог ↓");
        if (logCard == null) return;
        logCard.animate().cancel();
        if (expanded) {
            logCard.setAlpha(0f);
            logCard.setVisibility(android.view.View.VISIBLE);
            logCard.animate().alpha(1f).setDuration(160).start();
        } else {
            logCard.animate().alpha(0f).setDuration(130).withEndAction(() -> {
                if (!logExpanded) logCard.setVisibility(android.view.View.GONE);
            }).start();
        }
    }

    abstract void stateChanged(boolean running);

    @Override
    protected void onResume() {
        super.onResume();
        String s = Runner.get().attach(this);
        logView.setText(s.replaceAll("(?m)^APKSTUDIO_PROGRESS:.*\\n?", ""));
        scrollDown();
        onProgress(Runner.get().getProgress(), Runner.get().getProgressMessage());
        boolean running = Runner.get().isRunning();
        if (jobPanel != null) jobPanel.setVisibility(running ? android.view.View.VISIBLE : android.view.View.GONE);
        if (logCard != null) {
            logCard.setVisibility(running && logExpanded ? android.view.View.VISIBLE : android.view.View.GONE);
            if (running && logExpanded) logCard.setAlpha(1f);
        }
        stateChanged(running);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Runner.get().detach(this);
        handler.removeCallbacksAndMessages(null);
        flushPending();
    }

    private void scrollDown() {
        if (logScroll != null) logScroll.post(() -> logScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    public void onLog(String line) {
        if (line != null && line.startsWith("APKSTUDIO_PROGRESS:")) return;
        synchronized (pendingLog) {
            pendingLog.append(line).append('\n');
            if (pendingLog.length() > 300_000) pendingLog.delete(0, pendingLog.length() - 150_000);
        }
        if (!flushPosted) {
            flushPosted = true;
            handler.postDelayed(() -> {
                flushPosted = false;
                flushPending();
            }, 100);
        }
    }

    private void flushPending() {
        final String chunk;
        synchronized (pendingLog) {
            if (pendingLog.length() == 0) return;
            chunk = pendingLog.toString();
            pendingLog.setLength(0);
        }
        if (logView == null) return;
        logView.append(chunk);
        int extra = logView.length() - 300_000;
        if (extra > 0) logView.setText(logView.getText().subSequence(extra, logView.length()));
        scrollDown();
    }

    @Override
    public void onProgress(int percent, String message) {
        runOnUiThread(() -> {
            if (progressBar != null) progressBar.setProgress(percent, true);
            if (progressText != null) progressText.setText(percent + "%  ·  " + message);
        });
    }

    @Override
    public void onState(boolean running) {
        runOnUiThread(() -> {
            flushPending();
            if (jobPanel != null) jobPanel.setVisibility(running ? android.view.View.VISIBLE : android.view.View.GONE);
            if (logCard != null) {
                logCard.setVisibility(running && logExpanded ? android.view.View.VISIBLE : android.view.View.GONE);
                if (running && logExpanded) logCard.setAlpha(1f);
            }
            stateChanged(running);
        });
    }
}
