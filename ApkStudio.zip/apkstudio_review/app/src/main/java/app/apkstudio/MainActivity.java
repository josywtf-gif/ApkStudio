package app.apkstudio;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    private static final int REQ_STORAGE = 2;
    private static final int REQ_ADD_VERSION = 3;
    private String pendingContainer;
    private final List<String> labels = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        root.addView(Ui.header(this, "ApkStudio", "ANDROID BUILD WORKSPACE", false, null));
        TextView sub = new TextView(this);
        sub.setText("Создавайте и собирайте Android-приложения прямо на устройстве");
        Ui.muted(sub);
        root.addView(sub);
        Ui.gap(root, this, 16);

        Button bNew = new Button(this); bNew.setText("＋  Новый проект"); Ui.button(bNew, this, true);
        Button bImport = new Button(this); bImport.setText("Импорт ZIP"); Ui.button(bImport, this, false);
        Ui.add(root, Ui.row(this, bNew, bImport), this, 0);

        Button bEnv = new Button(this); bEnv.setText("⚙  Среда сборки и инструменты"); Ui.button(bEnv, this, false);
        Ui.add(root, bEnv, this, 8);
        Ui.gap(root, this, 18);

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        TextView projects = new TextView(this); projects.setText("Мои проекты"); Ui.title(projects, 18);
        section.addView(projects, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = new TextView(this); count.setText("ЛОКАЛЬНО"); Ui.muted(count);
        section.addView(count);
        root.addView(section);
        Ui.gap(root, this, 8);

        ListView list = new ListView(this);
        Ui.styleList(list, this);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(Ui.TEXT);
                v.setTextSize(15);
                v.setPadding(dp(14), dp(15), dp(14), dp(15));
                v.setBackground(Ui.shape(Ui.SURFACE, 0, 12, getResources().getDisplayMetrics().density));
                return v;
            }
        };
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        ensureStorageAccess();

        bNew.setOnClickListener(v -> newProjectDialog());
        bEnv.setOnClickListener(v -> startActivity(new Intent(this, EnvActivity.class)));
        bImport.setOnClickListener(v -> pickZip(REQ_IMPORT));
        list.setOnItemClickListener((p, v, pos, id) -> openProject(names.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String n = names.get(pos);
            new AlertDialog.Builder(this).setTitle("Удалить " + n + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        Util.deleteRecursive(new File(Util.projectsDir(this), n)); refresh();
                    }).setNegativeButton("Отмена", null).show();
            return true;
        });
    }

    private int dp(int n) { return Ui.dp(this, n); }

    private void ensureStorageAccess() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        Util.ensureSharedStorage(this);
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE) {
            boolean granted = grantResults.length > 0 && grantResults[grantResults.length - 1] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                Util.ensureSharedStorage(this);
                Toast.makeText(this, "Папка ApkStudio создана во внутренней памяти", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Для постоянного хранения компонентов нужен доступ к файлам. Разрешите его, чтобы ApkStudio использовал /ApkStudio/components и сохранял компоненты после переустановки.", Toast.LENGTH_LONG).show();
            }
            refresh();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        Util.ensureSharedStorage(this);
        refresh();
    }

    private void refresh() {
        names.clear();
        labels.clear();
        File[] dirs = Util.projectsDir(this).listFiles(File::isDirectory);
        if (dirs != null) {
            Arrays.sort(dirs);
            for (File d : dirs) {
                if (!d.getName().equalsIgnoreCase("components") && !d.getName().equalsIgnoreCase("Component") && !d.getName().startsWith(".")) {
                    names.add(d.getName());
                    int n = Versions.list(d).size();
                    labels.add(d.getName() + (Util.isProject(d) ? "  ·  без версий" : "  ·  версий: " + n));
                }
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void newProjectDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        EditText name = new EditText(this); name.setHint("Имя проекта"); name.setSingleLine(); Ui.input(name, this);
        EditText pkg = new EditText(this); pkg.setHint("com.example.app"); pkg.setText("com.example.app"); pkg.setSingleLine(); Ui.input(pkg, this);
        box.addView(name); Ui.gap(box, this, 10); box.addView(pkg);
        new AlertDialog.Builder(this).setTitle("Новый проект").setView(box)
                .setPositiveButton("Создать", (d, w) -> {
                    String n = Util.safeName(name.getText().toString().trim());
                    String p = pkg.getText().toString().trim();
                    if (!p.matches("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+")) {
                        Toast.makeText(this, "Некорректный пакет", Toast.LENGTH_LONG).show(); return;
                    }
                    try { Versions.createProject(this, n, p); refresh(); }
                    catch (Exception e) { Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show(); }
                }).setNegativeButton("Отмена", null).show();
    }

    /** Выбор версии проекта или добавление ZIP с новой версией. */
    private void openProject(String name) {
        File dir = new File(Util.projectsDir(this), name);
        List<String> items = new ArrayList<>();
        List<String> targets = new ArrayList<>();
        if (Util.isProject(dir)) {
            Versions.Info in = Versions.read(dir);
            items.add("Текущая" + (in.versionName.isEmpty() ? "" : "  ·  " + in.versionName));
            targets.add(null);
        } else {
            for (File v : Versions.list(dir)) {
                Versions.Info in = Versions.read(v);
                items.add(v.getName() + (in.versionCode > 0 ? "  ·  code " + in.versionCode : ""));
                targets.add(v.getName());
            }
        }
        items.add("＋  Добавить ZIP с новой версией");
        new AlertDialog.Builder(this).setTitle(name)
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    if (which == items.size() - 1) {
                        pendingContainer = name;
                        pickZip(REQ_ADD_VERSION);
                        return;
                    }
                    Intent i = new Intent(this, ProjectActivity.class);
                    i.putExtra("name", name);
                    if (targets.get(which) != null) i.putExtra("version", targets.get(which));
                    startActivity(i);
                }).setNegativeButton("Отмена", null).show();
    }

    private void pickZip(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if ((req != REQ_IMPORT && req != REQ_ADD_VERSION) || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); String n = "project";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i); }
        } catch (Exception ignored) {}
        final String zipName = n;
        final String force = req == REQ_ADD_VERSION ? pendingContainer : null;
        new Thread(() -> {
            String title, msg;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                Versions.Result r = Versions.importZip(this, in, zipName, force);
                if (r.notProject) {
                    title = "Импортировано";
                    msg = "AndroidManifest.xml / build.gradle в корне не найдены — папка: " + r.container.getName();
                } else if (r.previous == null) {
                    title = r.newProject ? "Новый проект" : "Версия добавлена";
                    msg = r.container.getName() + " / " + r.version.getName();
                } else {
                    title = "Новая версия: " + r.version.getName();
                    msg = r.report;
                }
            } catch (Exception e) { title = "Ошибка импорта"; msg = String.valueOf(e.getMessage()); }
            final String t = title, m = msg;
            runOnUiThread(() -> {
                refresh();
                new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("Понятно", null).show();
            });
        }).start();
    }
}
