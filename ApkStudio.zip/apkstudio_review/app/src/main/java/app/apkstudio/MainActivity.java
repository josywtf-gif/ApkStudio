package app.apkstudio;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    private static final int REQ_STORAGE = 2;
    private final List<String> names = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        LinearLayout root = new LinearLayout(this);
        Ui.page(root, this);

        TextView eyebrow = new TextView(this);
        eyebrow.setText("ANDROID BUILD WORKSPACE");
        eyebrow.setTextColor(Ui.ACCENT);
        eyebrow.setTextSize(10);
        eyebrow.setLetterSpacing(0.12f);
        root.addView(eyebrow);
        TextView title = new TextView(this);
        title.setText("ApkStudio");
        Ui.title(title, 30);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(3);
        root.addView(title, tp);
        TextView sub = new TextView(this);
        sub.setText("Создавайте и собирайте Android-приложения прямо на устройстве");
        Ui.muted(sub);
        root.addView(sub);
        Ui.gap(root, this, 16);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button bNew = new Button(this); bNew.setText("＋  Новый проект"); Ui.button(bNew, this, true);
        Button bImport = new Button(this); bImport.setText("Импорт ZIP"); Ui.button(bImport, this, false);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -2, 1);
        half.rightMargin = dp(6);
        actions.addView(bNew, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -2, 1);
        half2.leftMargin = dp(6);
        actions.addView(bImport, half2);
        root.addView(actions);

        Button bEnv = new Button(this); bEnv.setText("⚙  Среда сборки и инструменты"); Ui.button(bEnv, this, false);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(8);
        root.addView(bEnv, ep);
        Ui.gap(root, this, 18);

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        TextView projects = new TextView(this); projects.setText("Мои проекты"); Ui.title(projects, 18);
        section.addView(projects, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = new TextView(this); count.setText("ЛОКАЛЬНО"); Ui.muted(count);
        section.addView(count);
        root.addView(section);
        Ui.gap(root, this, 8);

        ListView list = new ListView(this);
        list.setDivider(new android.graphics.drawable.ColorDrawable(0x22394B65));
        list.setDividerHeight(dp(1));
        list.setSelector(android.R.color.transparent);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(Ui.TEXT);
                v.setTextSize(15);
                v.setPadding(dp(14), dp(15), dp(14), dp(15));
                v.setBackground(Ui.shape(Ui.SURFACE, 0, 12, getResources().getDisplayMetrics().density));
                return v;
            }
        };
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        ensureStorageAccess();

        bNew.setOnClickListener(v -> newProjectDialog());
        bEnv.setOnClickListener(v -> startActivity(new Intent(this, EnvActivity.class)));
        bImport.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IMPORT);
        });
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, ProjectActivity.class);
            i.putExtra("name", names.get(pos));
            startActivity(i);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String n = names.get(pos);
            new AlertDialog.Builder(this).setTitle("Удалить " + n + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        Util.deleteRecursive(new File(Util.projectsDir(this), n)); refresh();
                    }).setNegativeButton("Отмена", null).show();
            return true;
        });
    }

    private int dp(int n) { return Ui.dp(this, n); }

    private void ensureStorageAccess() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        Util.ensureSharedStorage(this);
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE) {
            boolean granted = grantResults.length > 0 && grantResults[grantResults.length - 1] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                Util.ensureSharedStorage(this);
                Toast.makeText(this, "Папка ApkStudio создана во внутренней памяти", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Без разрешения проекты останутся в папке приложения. Разрешите доступ к файлам, чтобы хранить их в /ApkStudio.", Toast.LENGTH_LONG).show();
            }
            refresh();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        Util.ensureSharedStorage(this);
        refresh();
    }

    private void refresh() {
        names.clear();
        File[] dirs = Util.projectsDir(this).listFiles(File::isDirectory);
        if (dirs != null) {
            Arrays.sort(dirs);
            for (File d : dirs) {
                if (!d.getName().equalsIgnoreCase("Component") && !d.getName().startsWith("."))
                    names.add(d.getName());
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void newProjectDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        EditText name = new EditText(this); name.setHint("Имя проекта"); name.setSingleLine(); Ui.input(name, this);
        EditText pkg = new EditText(this); pkg.setHint("com.example.app"); pkg.setText("com.example.app"); pkg.setSingleLine(); Ui.input(pkg, this);
        box.addView(name); Ui.gap(box, this, 10); box.addView(pkg);
        new AlertDialog.Builder(this).setTitle("Новый проект").setView(box)
                .setPositiveButton("Создать", (d, w) -> {
                    String n = Util.safeName(name.getText().toString().trim());
                    String p = pkg.getText().toString().trim();
                    if (!p.matches("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+")) {
                        Toast.makeText(this, "Некорректный пакет", Toast.LENGTH_LONG).show(); return;
                    }
                    File dir = new File(Util.projectsDir(this), n);
                    if (dir.exists()) { Toast.makeText(this, "Проект уже существует", Toast.LENGTH_LONG).show(); return; }
                    try { Templates.create(dir, p); refresh(); }
                    catch (Exception e) { Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show(); }
                }).setNegativeButton("Отмена", null).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); String n = "project";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i); }
        } catch (Exception ignored) {}
        if (n.toLowerCase().endsWith(".zip")) n = n.substring(0, n.length() - 4);
        final String base = Util.safeName(n);
        new Thread(() -> {
            String msg;
            try {
                File dir = new File(Util.projectsDir(this), base);
                if (dir.exists()) dir = new File(Util.projectsDir(this), base + "_" + System.currentTimeMillis());
                dir.mkdirs();
                try (InputStream in = getContentResolver().openInputStream(uri)) { Util.unzip(in, dir); }
                Util.flatten(dir);
                msg = Util.isProject(dir) ? "Импортировано: " + dir.getName()
                        : "Импортировано, но AndroidManifest.xml / build.gradle в корне не найдены";
            } catch (Exception e) { msg = "Ошибка импорта: " + e; }
            final String m = msg;
            runOnUiThread(() -> { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); refresh(); });
        }).start();
    }
}
