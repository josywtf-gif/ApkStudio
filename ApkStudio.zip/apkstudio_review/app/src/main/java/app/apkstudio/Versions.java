package app.apkstudio;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/** Версии проекта: ApkStudio/<Проект>/<Проект>_v<версия>/ с файлами проекта. */
final class Versions {
    static final String MARKER = ".apkstudio-version";
    static final String CHANGES = ".apkstudio-changes.txt";

    private Versions() {}

    static final class Info {
        String appId = "", name = "", versionName = "";
        long versionCode;
    }

    static final class Result {
        File container, version, previous;
        boolean newProject, notProject;
        String report = "";
    }

    private static String find(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : "";
    }

    private static String readQuiet(File f) {
        try { return f.isFile() ? Util.read(f) : ""; } catch (IOException e) { return ""; }
    }

    static Info read(File dir) {
        Info i = new Info();
        String gradle = readQuiet(new File(dir, "app/build.gradle"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "app/build.gradle.kts"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "build.gradle"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "build.gradle.kts"));
        String manifest = readQuiet(new File(dir, "app/src/main/AndroidManifest.xml"));
        if (manifest.isEmpty()) manifest = readQuiet(new File(dir, "AndroidManifest.xml"));
        i.appId = find(gradle, "applicationId\\s*=?\\s*[\"']([^\"']+)[\"']");
        if (i.appId.isEmpty()) i.appId = find(manifest, "package\\s*=\\s*\"([^\"]+)\"");
        if (i.appId.isEmpty()) i.appId = find(gradle, "namespace\\s*=?\\s*[\"']([^\"']+)[\"']");
        i.versionName = find(gradle, "versionName\\s*=?\\s*[\"']([^\"']+)[\"']");
        String code = find(gradle, "versionCode\\s*=?\\s*(\\d+)");
        try { i.versionCode = code.isEmpty() ? 0 : Long.parseLong(code); } catch (NumberFormatException ignored) {}
        String label = find(manifest, "android:label\\s*=\\s*\"([^\"@]+)\"");
        if (label.isEmpty()) {
            String res = readQuiet(new File(dir, "app/src/main/res/values/strings.xml"));
            label = find(res, "<string\\s+name=\"app_name\"[^>]*>([^<]+)</string>");
        }
        if (label.isEmpty()) {
            label = find(readQuiet(new File(dir, "settings.gradle")), "rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']");
        }
        i.name = label.trim();
        return i;
    }

    /** Сведения о приложении: сама папка (старый формат) или последняя версия. */
    static Info infoOf(File dir) {
        if (Util.isProject(dir)) return read(dir);
        List<File> v = list(dir);
        return v.isEmpty() ? new Info() : read(v.get(0));
    }

    /** Версии проекта, новые первыми. */
    static List<File> list(File container) {
        List<File> r = new ArrayList<>();
        File[] kids = container.listFiles(f -> f.isDirectory() && !f.getName().startsWith(".") && Util.isProject(f));
        if (kids != null) r.addAll(Arrays.asList(kids));
        Collections.sort(r, (a, b) -> Long.compare(added(b), added(a)));
        return r;
    }

    static long added(File v) {
        String s = find(readQuiet(new File(v, MARKER)), "added=(\\d+)");
        try { if (!s.isEmpty()) return Long.parseLong(s); } catch (NumberFormatException ignored) {}
        return v.lastModified();
    }

    static void writeMarker(File v, Info info, long added) throws IOException {
        Util.write(new File(v, MARKER), "versionName=" + info.versionName + "\nversionCode=" + info.versionCode
                + "\nappId=" + info.appId + "\nadded=" + added + "\n");
    }

    private static File uniqueDir(File parent, String name) {
        File f = new File(parent, name);
        for (int i = 2; f.exists(); i++) f = new File(parent, name + "_" + i);
        return f;
    }

    /** Старый проект (файлы прямо в папке) переносится в папку версии; ничего не удаляется. */
    static File migrateLegacy(File container) throws IOException {
        Info info = read(container);
        String vn = info.versionName.isEmpty() ? "1.0" : info.versionName;
        File target = uniqueDir(container, Util.safeName(container.getName() + "_v" + vn));
        target.mkdirs();
        List<File> moved = new ArrayList<>();
        File[] kids = container.listFiles();
        if (kids != null) for (File k : kids) {
            if (k.equals(target)) continue;
            File dest = new File(target, k.getName());
            if (!k.renameTo(dest)) {
                for (File m : moved) m.renameTo(new File(container, m.getName()));
                target.delete();
                throw new IOException("Не удалось перенести " + k.getName() + " в папку версии");
            }
            moved.add(dest);
        }
        writeMarker(target, info, 1L);
        return target;
    }

    /** Новый проект сразу создаётся в папке версии 1.0. */
    static File createProject(Context c, String name, String pkg) throws IOException {
        File container = new File(Util.projectsDir(c), name);
        if (container.exists()) throw new IOException("Проект уже существует");
        File v = new File(container, Util.safeName(name + "_v1.0"));
        Templates.create(v, pkg, name);
        writeMarker(v, read(v), System.currentTimeMillis());
        return v;
    }

    /**
     * Импорт ZIP. Если приложение (applicationId) уже есть среди проектов — добавляется новая версия
     * и сравнение с предыдущей. forceContainer — добавить именно в этот проект.
     */
    static Result importZip(Context c, InputStream zip, String zipName, String forceContainer) throws Exception {
        File root = Util.projectsDir(c);
        File tmp = new File(root, ".import-" + System.currentTimeMillis());
        tmp.mkdirs();
        Result r = new Result();
        try {
            Util.unzip(zip, tmp);
            Util.flatten(tmp);
            String zb = zipName.toLowerCase(Locale.ROOT).endsWith(".zip")
                    ? zipName.substring(0, zipName.length() - 4) : zipName;
            String zipBase = Util.safeName(zb);
            if (!Util.isProject(tmp)) {
                File dest = uniqueDir(root, zipBase);
                if (!tmp.renameTo(dest)) throw new IOException("Не удалось сохранить импорт");
                r.container = dest; r.version = dest; r.notProject = true;
                return r;
            }
            Info info = read(tmp);
            File container = null;
            if (forceContainer != null) {
                container = new File(root, forceContainer);
                Info ex = infoOf(container);
                if (!ex.appId.isEmpty() && !info.appId.isEmpty() && !ex.appId.equals(info.appId)) {
                    throw new IOException("ZIP — другое приложение (" + info.appId + "), а проект — "
                            + ex.appId + ". Используйте «Импорт ZIP» на главном экране.");
                }
            } else if (!info.appId.isEmpty()) {
                File[] dirs = root.listFiles(f -> f.isDirectory() && !f.getName().startsWith(".")
                        && !f.getName().equalsIgnoreCase("components") && !f.getName().equalsIgnoreCase("Component"));
                if (dirs != null) {
                    Arrays.sort(dirs);
                    for (File d : dirs) if (info.appId.equals(infoOf(d).appId)) { container = d; break; }
                }
            }
            if (container == null) {
                String n = Util.safeName(info.name.isEmpty() ? zipBase : info.name);
                if (n.replace("_", "").isEmpty()) {
                    String id = info.appId.isEmpty() ? zipBase : info.appId.substring(info.appId.lastIndexOf('.') + 1);
                    n = Util.safeName(id);
                }
                container = uniqueDir(root, n);
                container.mkdirs();
                r.newProject = true;
            } else if (Util.isProject(container)) {
                migrateLegacy(container);
            }
            List<File> existing = list(container);
            File prev = existing.isEmpty() ? null : existing.get(0);
            String vn = !info.versionName.isEmpty() ? info.versionName
                    : info.versionCode > 0 ? "code" + info.versionCode
                    : new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
            File target = uniqueDir(container, Util.safeName(container.getName() + "_v" + vn));
            if (!tmp.renameTo(target)) throw new IOException("Не удалось создать папку версии");
            writeMarker(target, info, System.currentTimeMillis());
            if (prev != null) {
                // versionCode продолжает расти между версиями, чтобы обновление ставилось поверх.
                File pc = new File(prev, ".apkstudio-version-code");
                File nc = new File(target, ".apkstudio-version-code");
                if (pc.isFile() && !nc.exists()) {
                    try (InputStream in = new FileInputStream(pc)) { Util.copy(in, nc); }
                }
                r.report = compare(prev, target);
                Util.write(new File(target, CHANGES), r.report);
            }
            r.container = container; r.version = target; r.previous = prev;
            return r;
        } finally {
            if (tmp.exists()) Util.deleteRecursive(tmp);
        }
    }

    private static Map<String, Long> crcMap(File dir) {
        Map<String, Long> m = new TreeMap<>();
        List<String> rel = new ArrayList<>();
        Util.listFiles(dir, dir, rel);
        byte[] buf = new byte[65536];
        for (String p : rel) {
            CRC32 crc = new CRC32();
            try (InputStream in = new FileInputStream(new File(dir, p))) {
                int n;
                while ((n = in.read(buf)) > 0) crc.update(buf, 0, n);
                m.put(p, crc.getValue());
            } catch (IOException ignored) { /* нечитаемый файл пропускаем */ }
        }
        return m;
    }

    /** Текстовый отчёт: что добавлено, удалено и изменено относительно предыдущей версии. */
    static String compare(File a, File b) {
        Map<String, Long> ma = crcMap(a), mb = crcMap(b);
        List<String> add = new ArrayList<>(), del = new ArrayList<>(), chg = new ArrayList<>();
        for (Map.Entry<String, Long> e : mb.entrySet()) {
            Long o = ma.get(e.getKey());
            if (o == null) add.add(e.getKey());
            else if (!o.equals(e.getValue())) chg.add(e.getKey());
        }
        for (String k : ma.keySet()) if (!mb.containsKey(k)) del.add(k);
        Info ia = read(a), ib = read(b);
        StringBuilder s = new StringBuilder("Сравнение с " + a.getName() + "\n");
        if (!ia.versionName.equals(ib.versionName))
            s.append("versionName: ").append(ia.versionName.isEmpty() ? "—" : ia.versionName)
                    .append(" → ").append(ib.versionName.isEmpty() ? "—" : ib.versionName).append('\n');
        if (ia.versionCode != ib.versionCode)
            s.append("versionCode: ").append(ia.versionCode).append(" → ").append(ib.versionCode).append('\n');
        section(s, "Добавлено", add);
        section(s, "Удалено", del);
        section(s, "Изменено", chg);
        if (add.isEmpty() && del.isEmpty() && chg.isEmpty()) s.append("Файлы идентичны\n");
        return s.toString();
    }

    private static void section(StringBuilder s, String title, List<String> items) {
        if (items.isEmpty()) return;
        s.append('\n').append(title).append(": ").append(items.size()).append('\n');
        for (int i = 0; i < items.size() && i < 15; i++) s.append("  ").append(items.get(i)).append('\n');
        if (items.size() > 15) s.append("  …и ещё ").append(items.size() - 15).append('\n');
    }
}
