#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
SDK=/opt/android-sdk
GRADLE_VER=8.9
COMP=/opt/apkstudio-components
mkdir -p "$COMP/deb-cache"

# Keep downloaded Debian packages in shared Component storage so a rebuilt
# Linux rootfs can reuse them instead of downloading the same .deb files.
echo "Dir::Cache::archives \"$COMP/deb-cache/\";" > /etc/apt/apt.conf.d/99apkstudio-cache
if [ -s "$COMP/system-packages-debian-bookworm-arm64.zip" ] \
   && ! find "$COMP/deb-cache" -name '*.deb' -print -quit | grep -q .; then
  echo "=== Восстановление кеша системных пакетов из Component"
  unzip -oq "$COMP/system-packages-debian-bookworm-arm64.zip" -d "$COMP"
fi

# Restore the Java tree when it was archived previously. apt still supplies
# system libraries and repairs an incomplete restore when necessary.
if [ ! -x /usr/lib/jvm/java-17-openjdk-arm64/bin/javac ] \
   && [ -s "$COMP/jdk-17-openjdk-arm64.zip" ]; then
  mkdir -p /usr/lib/jvm
  unzip -oq "$COMP/jdk-17-openjdk-arm64.zip" -d /usr/lib/jvm
fi

echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/99apkstudio
echo 'force-unsafe-io' > /etc/dpkg/dpkg.cfg.d/99apkstudio

if ! command -v javac >/dev/null || ! command -v curl >/dev/null || ! command -v unzip >/dev/null || ! command -v rsync >/dev/null || ! command -v zip >/dev/null; then
  echo "APKSTUDIO_PROGRESS:10:Обновление списка пакетов"
  echo "=== apt: JDK 17 + utils"
  apt-get update
  echo "APKSTUDIO_PROGRESS:22:Установка JDK 17 и системных утилит"
  apt-get install -y --no-install-recommends ca-certificates curl unzip zip git rsync openjdk-17-jdk-headless
fi

# Persist Debian package archives (including the JDK and required utilities).
if find "$COMP/deb-cache" -name '*.deb' -print -quit | grep -q .; then
  (cd "$COMP" && zip -q -FS -r system-packages-debian-bookworm-arm64.zip deb-cache)
fi
if [ -x /usr/lib/jvm/java-17-openjdk-arm64/bin/javac ] \
   && [ ! -s "$COMP/jdk-17-openjdk-arm64.zip" ]; then
  (cd /usr/lib/jvm && zip -q -r "$COMP/jdk-17-openjdk-arm64.zip" java-17-openjdk-arm64)
fi

# If this is an older installation whose rootfs was unpacked before the
# Component cache existed, seed the reusable rootfs ZIP once. Failure is
# non-fatal: the current installed environment remains usable.
if [ ! -s "$COMP/debian-bookworm-arm64-rootfs.zip" ]; then
  echo "=== Подготовка кеша базовой Debian rootfs (однократно)"
  if curl -fL --retry 2 --connect-timeout 20 -o /tmp/rootfs.tar.gz \
      https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/dist-arm64v8/bookworm/slim/oci/blobs/rootfs.tar.gz; then
    if (cd /tmp && zip -0 -q "$COMP/debian-bookworm-arm64-rootfs.zip" rootfs.tar.gz); then
      echo "Debian rootfs сохранена в Component"
    else
      echo "WARN: не удалось упаковать rootfs в Component"
    fi
    rm -f /tmp/rootfs.tar.gz
  else
    echo "WARN: rootfs не удалось кешировать сейчас; установленная среда сохранена"
  fi
fi

mkdir -p /opt/tools /root/.gradle
ln -sf /opt/native/libaapt2.so /opt/tools/aapt2

echo "APKSTUDIO_PROGRESS:38:Проверка Android SDK"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "=== Android cmdline-tools"
  mkdir -p "$SDK/cmdline-tools"
  if [ -s "$COMP/android-commandlinetools-11076708.zip" ]; then
    echo "APKSTUDIO_PROGRESS:42:Восстановление Android command-line tools из Component"
    unzip -q -o "$COMP/android-commandlinetools-11076708.zip" -d "$SDK/cmdline-tools"
  else
    echo "APKSTUDIO_PROGRESS:42:Загрузка Android command-line tools"
    curl -fL --retry 3 -o /tmp/cmdline-tools.zip \
      https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    cp /tmp/cmdline-tools.zip "$COMP/android-commandlinetools-11076708.zip"
    unzip -q -o /tmp/cmdline-tools.zip -d "$SDK/cmdline-tools"
    rm -f /tmp/cmdline-tools.zip
  fi
  if [ -d "$SDK/cmdline-tools/cmdline-tools" ]; then
    rm -rf "$SDK/cmdline-tools/latest"
    mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  fi
fi
if [ -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ] \
   && [ ! -s "$COMP/android-commandlinetools-11076708.zip" ]; then
  (cd "$SDK/cmdline-tools" && zip -q -r "$COMP/android-commandlinetools-11076708.zip" latest)
fi

export PATH="$SDK/cmdline-tools/latest/bin:$PATH"
echo "APKSTUDIO_PROGRESS:58:Установка Android SDK и Build Tools"
if [ -s "$COMP/android-sdk-platform-34-build-tools-34.0.0.zip" ] \
   && { [ ! -d "$SDK/platforms/android-34" ] || [ ! -d "$SDK/build-tools/34.0.0" ]; }; then
  echo "=== Восстановление Android SDK из Component"
  unzip -q -o "$COMP/android-sdk-platform-34-build-tools-34.0.0.zip" -d "$SDK"
fi
if [ ! -d "$SDK/platforms/android-34" ] || [ ! -d "$SDK/build-tools/34.0.0" ]; then
  echo "=== Android SDK licenses and packages"
  yes | sdkmanager --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true
  sdkmanager --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0"
fi
if [ -d "$SDK/platforms/android-34" ] && [ -d "$SDK/build-tools/34.0.0" ] \
   && [ ! -s "$COMP/android-sdk-platform-34-build-tools-34.0.0.zip" ]; then
  (cd "$SDK" && zip -q -r "$COMP/android-sdk-platform-34-build-tools-34.0.0.zip" \
    platforms/android-34 build-tools/34.0.0)
fi

echo "APKSTUDIO_PROGRESS:78:Проверка Gradle"
if [ ! -x /opt/gradle/bin/gradle ]; then
  echo "=== Gradle $GRADLE_VER"
  if [ -s "$COMP/gradle-$GRADLE_VER-bin.zip" ]; then
    echo "APKSTUDIO_PROGRESS:82:Восстановление Gradle из Component"
    unzip -q -o "$COMP/gradle-$GRADLE_VER-bin.zip" -d /opt
  else
    echo "APKSTUDIO_PROGRESS:82:Загрузка Gradle"
    curl -fL --retry 3 -o /tmp/gradle.zip \
      "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip"
    cp /tmp/gradle.zip "$COMP/gradle-$GRADLE_VER-bin.zip"
    unzip -q -o /tmp/gradle.zip -d /opt
    rm -f /tmp/gradle.zip
  fi
  if [ -d "/opt/gradle-$GRADLE_VER" ]; then
    rm -rf /opt/gradle
    mv "/opt/gradle-$GRADLE_VER" /opt/gradle
  fi
fi
if [ -x /opt/gradle/bin/gradle ] && [ ! -s "$COMP/gradle-$GRADLE_VER-bin.zip" ]; then
  (cd /opt && zip -q -r "$COMP/gradle-$GRADLE_VER-bin.zip" gradle)
fi

# One persistent debug certificate is used by every project and every build.
# Linux.prepare() bind-mounts ApkStudio's private signing directory here.
mkdir -p /root/.android
if [ ! -s /root/.android/debug.keystore ]; then
  echo "APKSTUDIO_PROGRESS:91:Создание постоянного ключа подписи APK"
  keytool -genkeypair -v -keystore /root/.android/debug.keystore \
    -storepass android -keypass android -alias androiddebugkey -noprompt \
    -dname "CN=Android Debug,O=Android,C=US" -validity 10000 \
    -keyalg RSA -keysize 2048
fi

cat > /root/.gradle/gradle.properties <<'EOF'
android.aapt2FromMavenOverride=/opt/tools/aapt2
org.gradle.daemon=true
org.gradle.caching=true
org.gradle.parallel=false
org.gradle.workers.max=3
org.gradle.vfs.watch=false
EOF

echo "APKSTUDIO_PROGRESS:94:Проверка инструментов"
echo "=== versions"
java -version 2>&1 | head -1
/opt/gradle/bin/gradle --version 2>&1 | grep -E '^Gradle' || true
/opt/tools/aapt2 version || echo "WARN: aapt2 did not start"

touch /opt/.setup-done
echo "APKSTUDIO_PROGRESS:100:Среда готова"
echo "=== Environment ready"
