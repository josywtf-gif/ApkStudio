#!/bin/bash
set -euo pipefail
XMX=${BUILD_XMX:-2048}
WORKERS=${BUILD_WORKERS:-3}
SRC=/project
W="/root/work/${BUILD_PROJECT_KEY:-project}"

cd "$SRC"
echo "APKSTUDIO_PROGRESS:2:Подготовка и синхронизация проекта"

# Preserve the application ID and advance versionCode for Android updates.
BUILD_FILE=""
[ -f app/build.gradle ] && BUILD_FILE=app/build.gradle
[ -z "$BUILD_FILE" ] && [ -f app/build.gradle.kts ] && BUILD_FILE=app/build.gradle.kts
if [ -n "$BUILD_FILE" ]; then
  CONFIG_CODE=$(sed -nE 's/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*([0-9]+).*$/\1/p' "$BUILD_FILE" | head -n1 || true)
  if [ -n "${CONFIG_CODE:-}" ]; then
    OLD_CODE=$(cat .apkstudio-version-code 2>/dev/null || echo 0)
    [[ "$OLD_CODE" =~ ^[0-9]+$ ]] || OLD_CODE=0
    NEXT_CODE=$(( CONFIG_CODE > OLD_CODE ? CONFIG_CODE + 1 : OLD_CODE + 1 ))
    if [[ "$BUILD_FILE" == *.kts ]]; then
      sed -i -E "0,/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*[0-9]+/s//        versionCode = ${NEXT_CODE}/" "$BUILD_FILE"
    else
      sed -i -E "0,/^[[:space:]]*versionCode[[:space:]]*=?[[:space:]]*[0-9]+/s//        versionCode ${NEXT_CODE}/" "$BUILD_FILE"
    fi
    printf '%s\n' "$NEXT_CODE" > .apkstudio-version-code
    echo "Автоматический versionCode: $NEXT_CODE"
  else
    echo "WARN: числовой versionCode не найден; автоувеличение пропущено"
  fi
fi

# A changed applicationId is a different Android app, not an update.
APP_ID=""
if [ -n "$BUILD_FILE" ]; then
  APP_ID=$(sed -nE "s/^[[:space:]]*applicationId[[:space:]]*=?[[:space:]]*['\"]([^'\"]+)['\"].*/\1/p" "$BUILD_FILE" | head -n1 || true)
fi
if [ -n "$APP_ID" ]; then
  PREV_ID=$(cat .apkstudio-application-id 2>/dev/null || true)
  if [ -n "$PREV_ID" ] && [ "$PREV_ID" != "$APP_ID" ]; then
    echo "WARN: applicationId изменился с $PREV_ID на $APP_ID — это будет отдельное приложение. Верните прежний ID для обновления поверх."
  fi
  printf '%s\n' "$APP_ID" > .apkstudio-application-id
fi

# A workspace is isolated per project. If a reused project name now points to
# another applicationId, discard only that workspace's stale Gradle outputs.
if [ -n "$APP_ID" ] && [ -s "$W/.apkstudio-workspace-id" ]; then
  WORKSPACE_ID=$(cat "$W/.apkstudio-workspace-id")
  if [ "$WORKSPACE_ID" != "$APP_ID" ]; then
    echo "applicationId изменился в workspace: очищаю только кеш этого проекта"
    rm -rf "$W"
  fi
fi
mkdir -p "$W"
[ -n "$APP_ID" ] && printf '%s\n' "$APP_ID" > "$W/.apkstudio-workspace-id"

# Keep the fast, private Linux workspace and only sync changed source files.
# Build outputs and Gradle caches remain in place for incremental builds.
mkdir -p "$W"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --checksum --delete --exclude='build/' --exclude='.gradle/' --exclude='.git/' \
    --exclude='.apkstudio-*' "$SRC/" "$W/"
else
  echo "WARN: rsync отсутствует; синхронизация без удаления устаревших исходников"
  tar --no-wildcards-match-slash --exclude='./build' --exclude='./.gradle' \
    --exclude='./.git' --exclude='./*/build' --exclude='./*/.gradle' \
    -cf - -C "$SRC" . | tar -C "$W" -xf -
fi
cd "$W"

# Apply a memory-aware heap while retaining the project's other settings.
if [ -f gradle.properties ]; then
  if grep -q '^org.gradle.jvmargs=' gradle.properties; then
    sed -i -E "s/^org\.gradle\.jvmargs=.*/org.gradle.jvmargs=-Xmx${XMX}m -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m/" gradle.properties
  else
    printf '\norg.gradle.jvmargs=-Xmx%sm -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m\n' "$XMX" >> gradle.properties
  fi
else
  printf 'org.gradle.jvmargs=-Xmx%sm -Dfile.encoding=UTF-8 -XX:MaxMetaspaceSize=768m\n' "$XMX" > gradle.properties
fi
sed -i -E '/^(org.gradle.caching|org.gradle.parallel|org.gradle.workers.max|org.gradle.daemon|org.gradle.vfs.watch)=/d' gradle.properties
cat >> gradle.properties <<'PROPS'
org.gradle.caching=true
org.gradle.parallel=false
org.gradle.workers.max=3
org.gradle.daemon=true
org.gradle.vfs.watch=false
PROPS

if [ -f gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  G=(sh ./gradlew)
else
  G=(/opt/gradle/bin/gradle)
fi
ARGS=("$@")
if [ ${#ARGS[@]} -eq 0 ]; then ARGS=(assembleDebug); fi

cat > /tmp/apkstudio-progress.init.gradle <<'INIT'
gradle.taskGraph.whenReady { graph ->
    def tasks = graph.allTasks
    def total = Math.max(1, tasks.size())
    def done = 0
    gradle.taskGraph.afterTask { task, state ->
        done++
        def pct = 15 + (70.0 * done / total).intValue()
        println "APKSTUDIO_PROGRESS:${pct}:Задача ${done}/${total}: ${task.path}"
    }
}
INIT

echo "APKSTUDIO_PROGRESS:8:Запуск Gradle, повторное использование кеша"
echo "=== ${G[*]} ${ARGS[*]} (Xmx${XMX}m, workers=${WORKERS})"
"${G[@]}" --console=plain --stacktrace --max-workers="$WORKERS" --build-cache \
  -I /tmp/apkstudio-progress.init.gradle \
  -Dorg.gradle.parallel=false -Dorg.gradle.vfs.watch=false "${ARGS[@]}"

echo "APKSTUDIO_PROGRESS:90:Подготовка APK и проверка подписи"
OUT="$SRC/build/apk"
mkdir -p "$OUT"
find "$OUT" -maxdepth 1 -type f -name '*.apk' -delete
find "$W" -path '*/build/outputs/apk/*' -type f -name '*.apk' -exec cp -f {} "$OUT/" \;
if ! find "$OUT" -maxdepth 1 -type f -name '*.apk' | grep -q .; then
  echo "APK не найден в build/outputs/apk"
  exit 2
fi
ls -lh "$OUT"/*.apk
if [ -x /opt/android-sdk/build-tools/34.0.0/apksigner ]; then
  for apk in "$OUT"/*.apk; do
    echo "=== Подпись: $(basename "$apk")"
    /opt/android-sdk/build-tools/34.0.0/apksigner verify --print-certs "$apk" 2>&1 | grep -E 'Signer #1 certificate SHA-256 digest|Verified' || true
  done
fi
echo "APKSTUDIO_PROGRESS:98:APK готов, ключ подписи сохранён"
