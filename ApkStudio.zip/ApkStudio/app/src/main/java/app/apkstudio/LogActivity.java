package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact, collapsible job panel shared by setup and build screens. */
abstract class LogActivity extends Activity implements Runner.Listener {
    protected TextView logView;
    protected ScrollView logScroll;
    private ProgressBar progressBar;
    private TextView progressText;
    private LinearLayout jobPanel;
    private LinearLayout logCard;
    private Button toggleLog;
    private boolean logExpanded = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder pendingLog = new StringBuilder();
    private boolean flushPosted;

    protected int dp(int v) { return Ui.dp(this, v); }

    protected LinearLayout makeProgressView() {
        jobPanel = Ui.card(this);
        jobPanel.setVisibility(android.view.View.GONE);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        progressText = new TextView(this);
        progressText.setText("Ожидание");
        progressText.setTextColor(Ui.TEXT);
        progressText.setTextSize(12);
        head.addView(progressText, new LinearLayout.LayoutParams(0, -2, 1));
        toggleLog = new Button(this);
        toggleLog.setText("▲");
        Ui.button(toggleLog, this, false);
        toggleLog.setOnClickListener(v -> setLogExpanded(!logExpanded));
        head.addView(toggleLog, new LinearLayout.LayoutParams(dp(46), dp(38)));
        jobPanel.addView(head);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(android.view.View.GONE);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(7));
        pp.topMargin = dp(10);
        jobPanel.addView(progressBar, pp);
        return jobPanel;
    }

    protected ScrollView makeLogView() {
        logCard = Ui.card(this);
        logCard.setVisibility(android.view.View.GONE);
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10.5f);
        logView.setTextColor(android.graphics.Color.rgb(185, 204, 222));
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.setFillViewport(false);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.addView(logView);
        logCard.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(132)));
        return logScroll;
    }

    protected LinearLayout makeLogCard() {
        makeLogView();
        return logCard;
    }

    private void setLogExpanded(boolean expanded) {
        logExpanded = expanded;
        if (toggleLog != null) toggleLog.animate().rotation(expanded ? 180f : 0f).setDuration(200).start();
        if (logCard == null) return;
        logCard.animate().cancel();
        final android.view.ViewGroup.LayoutParams lp = logCard.getLayoutParams();
        final int full = dp(156);
        final int from = expanded ? 0 : logCard.getHeight();
        final int to = expanded ? full : 0;
        if (expanded) {
            lp.height = 0;
            logCard.setAlpha(1f);
            logCard.setVisibility(android.view.View.VISIBLE);
            logCard.setLayoutParams(lp);
        }
        android.animation.ValueAnimator anim = android.animation.ValueAnimator.ofInt(from, to);
        anim.setDuration(240);
        anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            lp.height = (Integer) a.getAnimatedValue();
            logCard.setLayoutParams(lp);
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (logExpanded) { lp.height = -2; logCard.setLayoutParams(lp); scrollDown(); }
                else { logCard.setVisibility(android.view.View.GONE); lp.height = -2; logCard.setLayoutParams(lp); }
            }
        });
        anim.start();
    }

    private void applyVisibility(boolean running) {
        boolean show = Runner.get().owns(owner()) && (running || Runner.get().hasResult());
        if (jobPanel != null) jobPanel.setVisibility(show ? android.view.View.VISIBLE : android.view.View.GONE);
        if (progressBar != null) progressBar.setVisibility(show && running ? android.view.View.VISIBLE : android.view.View.GONE);
        if (logCard != null) {
            logCard.getLayoutParams().height = -2;
            logCard.setVisibility(show && logExpanded ? android.view.View.VISIBLE : android.view.View.GONE);
            logCard.setAlpha(1f);
        }
    }

    /** Log channel: a screen sees only logs of jobs it started. */
    abstract String owner();

    @Override
    public String logOwner() { return owner(); }

    abstract void stateChanged(boolean running);

    @Override
    protected void onResume() {
        super.onResume();
        String s = Runner.get().attach(this);
        logView.setText(colorize(s.replaceAll("(?m)^APKSTUDIO_PROGRESS:.*\\n?", "")));
        scrollDown();
        boolean mine = Runner.get().owns(owner());
        if (mine) onProgress(Runner.get().getProgress(), Runner.get().getProgressMessage());
        boolean running = Runner.get().isRunning();
        applyVisibility(running);
        stateChanged(running);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Runner.get().detach(this);
        handler.removeCallbacksAndMessages(null);
        flushPending();
    }

    private static final int RED = android.graphics.Color.rgb(255, 82, 82);
    private static final int GREEN = android.graphics.Color.rgb(76, 217, 100);

    /** Lines starting with ✖ are red, with ✔ are green. */
    private static CharSequence colorize(String text) {
        if (text.indexOf('✖') < 0 && text.indexOf('✔') < 0) return text;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int pos = 0;
        while (pos < text.length()) {
            int nl = text.indexOf('\n', pos);
            int end = nl < 0 ? text.length() : nl + 1;
            int start = sb.length();
            sb.append(text, pos, end);
            char c = text.charAt(pos);
            if (c == '✖' || c == '✔')
                sb.setSpan(new ForegroundColorSpan(c == '✖' ? RED : GREEN), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            pos = end;
        }
        return sb;
    }

    private void scrollDown() {
        if (logScroll != null) logScroll.post(() -> logScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    public void onLog(String line) {
        if (line != null && line.startsWith("APKSTUDIO_PROGRESS:")) return;
        synchronized (pendingLog) {
            pendingLog.append(line).append('\n');
            if (pendingLog.length() > 300_000) pendingLog.delete(0, pendingLog.length() - 150_000);
        }
        if (!flushPosted) {
            flushPosted = true;
            handler.postDelayed(() -> {
                flushPosted = false;
                flushPending();
            }, 100);
        }
    }

    private void flushPending() {
        final String chunk;
        synchronized (pendingLog) {
            if (pendingLog.length() == 0) return;
            chunk = pendingLog.toString();
            pendingLog.setLength(0);
        }
        if (logView == null) return;
        logView.append(colorize(chunk));
        int extra = logView.length() - 300_000;
        if (extra > 0) logView.setText(logView.getText().subSequence(extra, logView.length()));
        scrollDown();
    }

    @Override
    public void onProgress(int percent, String message) {
        runOnUiThread(() -> {
            if (progressBar != null) progressBar.setProgress(percent, true);
            if (progressText != null) progressText.setText(percent + "%  ·  " + message);
        });
    }

    @Override
    public void onState(boolean running) {
        runOnUiThread(() -> {
            flushPending();
            applyVisibility(running);
            stateChanged(running);
        });
    }
}
