package app.apkstudio;

import android.app.Application;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                Util.write(new File(getFilesDir(), "crash.txt"), "Thread: " + t.getName() + "\n" + sw);
            } catch (Throwable ignored) {
                // nothing else to do
            }
            if (old != null) old.uncaughtException(t, e);
        });
    }
}
