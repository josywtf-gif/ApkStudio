package app.apkstudio;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/** Версии проекта: ApkStudio/<Проект>/<Проект>_v<версия>/ с файлами проекта. */
final class Versions {
    static final String MARKER = ".apkstudio-version";
    static final String CHANGES = ".apkstudio-changes.txt";

    private Versions() {}

    static final class Info {
        String appId = "", name = "", versionName = "";
        long versionCode;
    }

    static final class Result {
        File container, version, previous;
        boolean newProject, notProject;
        String report = "";
    }

    private static String find(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : "";
    }

    private static String readQuiet(File f) {
        try { return f.isFile() ? Util.read(f) : ""; } catch (IOException e) { return ""; }
    }

    static Info read(File dir) {
        Info i = new Info();
        String gradle = readQuiet(new File(dir, "app/build.gradle"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "app/build.gradle.kts"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "build.gradle"));
        if (gradle.isEmpty()) gradle = readQuiet(new File(dir, "build.gradle.kts"));
        String manifest = readQuiet(new File(dir, "app/src/main/AndroidManifest.xml"));
        if (manifest.isEmpty()) manifest = readQuiet(new File(dir, "AndroidManifest.xml"));
        i.appId = find(gradle, "applicationId\\s*=?\\s*[\"']([^\"']+)[\"']");
        if (i.appId.isEmpty()) i.appId = find(manifest, "package\\s*=\\s*\"([^\"]+)\"");
        if (i.appId.isEmpty()) i.appId = find(gradle, "namespace\\s*=?\\s*[\"']([^\"']+)[\"']");
        i.versionName = find(gradle, "versionName\\s*=?\\s*[\"']([^\"']+)[\"']");
        String code = find(gradle, "versionCode\\s*=?\\s*(\\d+)");
        try { i.versionCode = code.isEmpty() ? 0 : Long.parseLong(code); } catch (NumberFormatException ignored) {}
        String label = find(manifest, "android:label\\s*=\\s*\"([^\"@]+)\"");
        if (label.isEmpty()) {
            String res = readQuiet(new File(dir, "app/src/main/res/values/strings.xml"));
            label = find(res, "<string\\s+name=\"app_name\"[^>]*>([^<]+)</string>");
        }
        if (label.isEmpty()) {
            label = find(readQuiet(new File(dir, "settings.gradle")), "rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']");
        }
        i.name = label.trim();
        return i;
    }

    private static String normId(String id) {
        String s = id.toLowerCase(Locale.ROOT).trim();
        return s.replaceAll("(\\.(s|b|stable|beta)\\.app|\\.(stable|beta|debug))$", "");
    }

    private static String normName(String name) {
        String s = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9а-яё]+", "");
        String prev;
        do {
            prev = s;
            s = s.replaceAll("(fixed|final|new|copy|beta|stable|release|v?\\d+)$", "");
        } while (!s.equals(prev) && !s.isEmpty());
        return s.isEmpty() ? name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9а-яё]+", "") : s;
    }

    /** Один и тот же проект: по applicationId из содержимого; без него — по названию из файлов. */
    private static boolean sameApp(Info a, String aName, Info b, String bName) {
        if (!a.appId.isEmpty() && !b.appId.isEmpty()) return normId(a.appId).equals(normId(b.appId));
        if (aName.isEmpty() || bName.isEmpty()) return false;
        return normName(aName).equals(normName(bName));
    }

    /** Сведения о приложении: сама папка (старый формат) или последняя версия. */
    static Info infoOf(File dir) {
        if (Util.isProject(dir)) return read(dir);
        List<File> v = list(dir);
        return v.isEmpty() ? new Info() : read(v.get(0));
    }

    /** Версии проекта, новые первыми. */
    static List<File> list(File container) {
        List<File> r = new ArrayList<>();
        File[] kids = container.listFiles(f -> f.isDirectory() && !f.getName().startsWith(".") && Util.isProject(f));
        if (kids != null) r.addAll(Arrays.asList(kids));
        Collections.sort(r, (a, b) -> {
            int[] pa = parseVersion(read(a).versionName), pb = parseVersion(read(b).versionName);
            if ((pa != null) != (pb != null)) return pa != null ? -1 : 1;
            if (pa != null) {
                int c = compareVersions(pb, pa);
                if (c != 0) return c;
            }
            return Long.compare(added(b), added(a));
        });
        return r;
    }

    /** "2.2.1" -> [2,2,1]; null, если версия не числовая. */
    static int[] parseVersion(String v) {
        if (v == null || !v.trim().matches("\\d+(\\.\\d+){0,3}")) return null;
        String[] s = v.trim().split("\\.");
        int[] r = new int[s.length];
        try { for (int i = 0; i < s.length; i++) r[i] = Integer.parseInt(s[i]); }
        catch (NumberFormatException e) { return null; }
        return r;
    }

    static int compareVersions(int[] a, int[] b) {
        for (int i = 0; i < Math.max(a.length, b.length); i++) {
            int x = i < a.length ? a[i] : 0, y = i < b.length ? b[i] : 0;
            if (x != y) return Integer.compare(x, y);
        }
        return 0;
    }

    /** 2.2 -> 2.2.1 ... 2.2.9 -> 2.3 -> 2.3.1 ... 2.9.9 -> 3.0; цифра не больше 9. */
    static String nextVersion(int[] v) {
        List<Integer> p = new ArrayList<>();
        for (int x : v) p.add(x);
        if (p.size() == 1) p.add(0);
        if (p.size() == 2) p.add(1);
        else p.set(p.size() - 1, p.get(p.size() - 1) + 1);
        while (p.size() > 2 && p.get(p.size() - 1) > 9) {
            p.remove(p.size() - 1);
            p.set(p.size() - 1, p.get(p.size() - 1) + 1);
        }
        if (p.size() == 2 && p.get(1) > 9) { p.remove(1); p.set(0, p.get(0) + 1); p.add(0); }
        if (p.size() > 2 && p.get(2) == 0) p.remove(2);
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < p.size(); i++) { if (i > 0) s.append('.'); s.append(p.get(i)); }
        return s.toString();
    }

    private static boolean setVersionName(File dir, String name) {
        for (String f : new String[]{"app/build.gradle", "app/build.gradle.kts", "build.gradle", "build.gradle.kts"}) {
            File g = new File(dir, f);
            String t = readQuiet(g);
            if (t.isEmpty()) continue;
            Matcher m = Pattern.compile("(versionName\\s*=?\\s*[\"'])([^\"']+)([\"'])").matcher(t);
            if (!m.find()) return false;
            String out = t.substring(0, m.start()) + m.group(1) + name + m.group(3) + t.substring(m.end());
            try { Util.write(g, out); return true; } catch (IOException e) { return false; }
        }
        return false;
    }

    static long added(File v) {
        String s = find(readQuiet(new File(v, MARKER)), "added=(\\d+)");
        try { if (!s.isEmpty()) return Long.parseLong(s); } catch (NumberFormatException ignored) {}
        return v.lastModified();
    }

    static void writeMarker(File v, Info info, long added) throws IOException {
        Util.write(new File(v, MARKER), "versionName=" + info.versionName + "\nversionCode=" + info.versionCode
                + "\nappId=" + info.appId + "\nadded=" + added + "\n");
    }

    private static File uniqueDir(File parent, String name) {
        File f = new File(parent, name);
        for (int i = 2; f.exists(); i++) f = new File(parent, name + "_" + i);
        return f;
    }

    /** Старый проект (файлы прямо в папке) переносится в папку версии; ничего не удаляется. */
    static File migrateLegacy(File container) throws IOException {
        Info info = read(container);
        String vn = info.versionName.isEmpty() ? "1.0" : info.versionName;
        File target = uniqueDir(container, Util.safeName(container.getName() + "_v" + vn));
        target.mkdirs();
        List<File> moved = new ArrayList<>();
        File[] kids = container.listFiles();
        if (kids != null) for (File k : kids) {
            if (k.equals(target)) continue;
            File dest = new File(target, k.getName());
            if (!k.renameTo(dest)) {
                for (File m : moved) m.renameTo(new File(container, m.getName()));
                target.delete();
                throw new IOException("Не удалось перенести " + k.getName() + " в папку версии");
            }
            moved.add(dest);
        }
        writeMarker(target, info, 1L);
        return target;
    }

    /** Новый проект сразу создаётся в папке версии 1.0. */
    static File createProject(Context c, String name, String pkg) throws IOException {
        File container = new File(Util.projectsDir(c), name);
        if (container.exists()) throw new IOException("Проект уже существует");
        File stable = new File(container, ReleaseChannels.STABLE);
        stable.mkdirs();
        File v = new File(stable, Util.safeName(name + "_stable_v1.0"));
        Templates.create(v, pkg, name);
        writeMarker(v, read(v), System.currentTimeMillis());
        return v;
    }

    /** Move pre-channel project/version folders into Stable without overwriting anything. */
    static void ensureChannelStructure(File container) throws IOException {
        File stable = new File(container, ReleaseChannels.STABLE);
        if (Util.isProject(container)) {
            File legacy = migrateLegacy(container);
            if (!stable.exists() && !stable.mkdirs()) throw new IOException("Не удалось создать Stable");
            File dest = uniqueDir(stable, legacy.getName());
            if (!legacy.renameTo(dest)) throw new IOException("Не удалось перенести старую версию в Stable");
            return;
        }
        File[] children = container.listFiles(f -> f.isDirectory() && !f.getName().startsWith(".")
                && Util.isProject(f) && !f.getName().equals(ReleaseChannels.STABLE)
                && !f.getName().equals(ReleaseChannels.BETA));
        if (children != null && children.length > 0) {
            if (!stable.exists() && !stable.mkdirs()) throw new IOException("Не удалось создать Stable");
            for (File old : children) {
                File dest = uniqueDir(stable, old.getName());
                if (!old.renameTo(dest)) throw new IOException("Не удалось перенести " + old.getName());
            }
        }
    }

    /**
     * Импорт ZIP. Если приложение (applicationId) уже есть среди проектов — добавляется новая версия
     * и сравнение с предыдущей. forceContainer — добавить именно в этот проект.
     */
    static Result importZip(Context c, InputStream zip, String zipName, String forceContainer, String channel) throws Exception {
        channel = ReleaseChannels.normalize(channel);
        File root = Util.projectsDir(c);
        File tmp = new File(root, ".import-" + System.currentTimeMillis());
        tmp.mkdirs();
        Result r = new Result();
        File zipCopy = new File(root, tmp.getName() + ".zip");
        try {
            Util.copy(zip, zipCopy);
            try (InputStream zin = new FileInputStream(zipCopy)) { Util.unzip(zin, tmp); }
            Util.flatten(tmp);
            String zb = zipName.toLowerCase(Locale.ROOT).endsWith(".zip")
                    ? zipName.substring(0, zipName.length() - 4) : zipName;
            String zipBase = Util.safeName(zb);
            if (!Util.isProject(tmp)) {
                File dest = uniqueDir(root, zipBase);
                if (!tmp.renameTo(dest)) throw new IOException("Не удалось сохранить импорт");
                r.container = dest; r.version = dest; r.notProject = true;
                return r;
            }
            Info info = read(tmp);
            File container = null;
            if (forceContainer != null) {
                container = new File(root, forceContainer);
                File channelDir = new File(container, channel);
                Info ex = infoOf(channelDir);
                if (ex.appId.isEmpty()) {
                    File otherChannel = new File(container, channel.equals(ReleaseChannels.STABLE) ? ReleaseChannels.BETA : ReleaseChannels.STABLE);
                    ex = infoOf(otherChannel);
                }
                if (ex.appId.isEmpty() && Util.isProject(container)) ex = read(container);
                if (!ex.appId.isEmpty() && !info.appId.isEmpty() && !normId(ex.appId).equals(normId(info.appId))) {
                    throw new IOException("ZIP — другое приложение (" + info.appId + "), а проект — "
                            + ex.appId + ". Используйте «Импорт ZIP» на главном экране.");
                }
            } else {
                String myName = !info.name.isEmpty() ? info.name : zipBase;
                File[] dirs = root.listFiles(f -> f.isDirectory() && !f.getName().startsWith(".")
                        && !f.getName().equalsIgnoreCase("components") && !f.getName().equalsIgnoreCase("Component"));
                if (dirs != null) {
                    Arrays.sort(dirs);
                    for (File d : dirs) {
                        try { ensureChannelStructure(d); } catch (IOException ignored) { /* report on explicit open/import */ }
                        File candidate = new File(d, channel);
                        Info candidateInfo = infoOf(candidate);
                        if (candidateInfo.appId.isEmpty() && Util.isProject(d)) candidateInfo = read(d);
                        if (candidateInfo.appId.isEmpty() && candidateInfo.name.isEmpty()) {
                            File other = new File(d, channel.equals(ReleaseChannels.STABLE) ? ReleaseChannels.BETA : ReleaseChannels.STABLE);
                            candidateInfo = infoOf(other);
                        }
                        String exName = !candidateInfo.name.isEmpty() ? candidateInfo.name : d.getName();
                        if (sameApp(info, myName, candidateInfo, exName)) { container = d; break; }
                    }
                }
            }
            if (container == null) {
                String n = Util.safeName(info.name.isEmpty() ? zipBase : info.name);
                if (n.replace("_", "").isEmpty()) {
                    String id = info.appId.isEmpty() ? zipBase : info.appId.substring(info.appId.lastIndexOf('.') + 1);
                    n = Util.safeName(id);
                }
                container = uniqueDir(root, n);
                container.mkdirs();
                r.newProject = true;
            }
            File channelDir = new File(container, channel);
            if (Util.isProject(container)) {
                File migrated = migrateLegacy(container);
                channelDir.mkdirs();
                if (!migrated.renameTo(new File(channelDir, migrated.getName()))) {
                    throw new IOException("Не удалось перенести старую версию в Stable");
                }
            }
            if (!channelDir.exists() && !channelDir.mkdirs()) throw new IOException("Не удалось создать канал " + channel);
            List<File> existing = list(channelDir);
            File prev = existing.isEmpty() ? null : existing.get(0);
            if (prev != null && !info.versionName.isEmpty()) {
                int[] cur = parseVersion(info.versionName), last = parseVersion(read(prev).versionName);
                if (cur != null && last != null && compareVersions(cur, last) <= 0) {
                    String nv = nextVersion(last);
                    if (setVersionName(tmp, nv)) info.versionName = nv;
                }
            }
            String vn = !info.versionName.isEmpty() ? info.versionName
                    : info.versionCode > 0 ? "code" + info.versionCode
                    : new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
            File target = uniqueDir(channelDir, Util.safeName(container.getName() + "_" + channel + "_v" + vn));
            if (!tmp.renameTo(target)) throw new IOException("Не удалось создать папку версии");
            writeMarker(target, info, System.currentTimeMillis());
            String savedZip = Util.safeName(zipName.toLowerCase(Locale.ROOT).endsWith(".zip") ? zipName : zipName + ".zip");
            if (new File(target, savedZip).exists()) savedZip = "source_" + savedZip;
            try (InputStream zin = new FileInputStream(zipCopy)) { Util.copy(zin, new File(target, savedZip)); }
            Util.write(new File(target, ".apkstudio-source-zip"), savedZip);
            if (prev != null) {
                // versionCode продолжает расти между версиями, чтобы обновление ставилось поверх.
                File pc = new File(prev, ".apkstudio-version-code");
                File nc = new File(target, ".apkstudio-version-code");
                if (pc.isFile() && !nc.exists()) {
                    try (InputStream in = new FileInputStream(pc)) { Util.copy(in, nc); }
                }
                r.report = compare(prev, target);
                Util.write(new File(target, CHANGES), r.report);
            }
            r.container = container; r.version = target; r.previous = prev;
            return r;
        } finally {
            if (tmp.exists()) Util.deleteRecursive(tmp);
            zipCopy.delete();
        }
    }

    private static Map<String, Long> crcMap(File dir) {
        Map<String, Long> m = new TreeMap<>();
        List<String> rel = new ArrayList<>();
        Util.listFiles(dir, dir, rel);
        byte[] buf = new byte[65536];
        for (String p : rel) {
            CRC32 crc = new CRC32();
            try (InputStream in = new FileInputStream(new File(dir, p))) {
                int n;
                while ((n = in.read(buf)) > 0) crc.update(buf, 0, n);
                m.put(p, crc.getValue());
            } catch (IOException ignored) { /* нечитаемый файл пропускаем */ }
        }
        return m;
    }

    /** Текстовый отчёт: что добавлено, удалено и изменено относительно предыдущей версии. */
    static String compare(File a, File b) {
        Map<String, Long> ma = crcMap(a), mb = crcMap(b);
        List<String> add = new ArrayList<>(), del = new ArrayList<>(), chg = new ArrayList<>();
        for (Map.Entry<String, Long> e : mb.entrySet()) {
            Long o = ma.get(e.getKey());
            if (o == null) add.add(e.getKey());
            else if (!o.equals(e.getValue())) chg.add(e.getKey());
        }
        for (String k : ma.keySet()) if (!mb.containsKey(k)) del.add(k);
        Info ia = read(a), ib = read(b);
        StringBuilder s = new StringBuilder("Сравнение с " + a.getName() + "\n");
        if (!ia.versionName.equals(ib.versionName))
            s.append("versionName: ").append(ia.versionName.isEmpty() ? "—" : ia.versionName)
                    .append(" → ").append(ib.versionName.isEmpty() ? "—" : ib.versionName).append('\n');
        if (ia.versionCode != ib.versionCode)
            s.append("versionCode: ").append(ia.versionCode).append(" → ").append(ib.versionCode).append('\n');
        section(s, "Добавлено", add);
        section(s, "Удалено", del);
        section(s, "Изменено", chg);
        if (add.isEmpty() && del.isEmpty() && chg.isEmpty()) s.append("Файлы идентичны\n");
        return s.toString();
    }

    private static void section(StringBuilder s, String title, List<String> items) {
        if (items.isEmpty()) return;
        s.append('\n').append(title).append(": ").append(items.size()).append('\n');
        for (int i = 0; i < items.size() && i < 15; i++) s.append("  ").append(items.get(i)).append('\n');
        if (items.size() > 15) s.append("  …и ещё ").append(items.size() - 15).append('\n');
    }
}
