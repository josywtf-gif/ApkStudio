package app.apkstudio;

import android.app.ActivityManager;
import android.content.Context;
import android.system.Os;
import android.os.Environment;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.zip.CRC32;

/** Debian arm64 rootfs run through proot. Gradle, JDK and Android SDK live inside it. */
final class Linux {
    static volatile Process current;
    private static volatile java.net.HttpURLConnection activeConnection;

    static void cancelCurrent() {
        Process p = current;
        if (p != null) p.destroyForcibly();
        java.net.HttpURLConnection c = activeConnection;
        if (c != null) c.disconnect();
    }

    private static final String JAVA_HOME = "/usr/lib/jvm/java-17-openjdk-arm64";

    private final Context ctx;
    private final File root;
    private final File tmp;
    private final File libDir;
    private final File nativeDir;
    private final File signingDir;
    private final File componentDir;
    private volatile boolean offlineInstall;

    Linux(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        File files = this.ctx.getFilesDir();
        root = new File(files, "rootfs");
        tmp = new File(files, "tmp");
        libDir = new File(files, "lib");
        // Runtime copies are app-private (executable on Android); durable originals are in
        // /storage/emulated/0/ApkStudio/components and survive uninstall/reinstall.
        nativeDir = new File(files, "native-components");
        signingDir = new File(files, "gradle-signing");
        componentDir = Util.componentDir(this.ctx);
    }

    boolean unpacked() { return new File(root, ".unpacked").exists(); }

    boolean installed() { return new File(root, "opt/.setup-done").exists(); }

    /**
     * Restore native tools from the uninstall-persistent shared folder. On first install,
     * seed that folder from the APK's extracted native libraries. Then copy them into the
     * app-private executable directory used by Android (shared storage is not executable).
     */
    private void seedPersistentComponents(Runner.Log log) throws IOException {
        if (!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            throw new IOException("Внутренняя память недоступна: невозможно открыть /ApkStudio/components");
        }
        if (!Util.hasSharedStoragePermission(ctx)) {
            throw new IOException("Нет доступа к общей памяти. Разрешите ApkStudio доступ к файлам, " +
                    "чтобы использовать /ApkStudio/components и сохранять компоненты после удаления приложения.");
        }
        if (!componentDir.exists() && !componentDir.mkdirs())
            throw new IOException("Не удалось создать постоянную папку: " + componentDir.getPath());
        File apkNativeDir = new File(ctx.getApplicationInfo().nativeLibraryDir);
        String[] nativeFiles = {"libproot.so", "libproot-loader.so", "libtalloc.so", "libandroid-shmem.so", "libaapt2.so"};
        for (String name : nativeFiles) {
            File saved = new File(componentDir, name);
            File bundled = new File(apkNativeDir, name);
            if (!saved.isFile() || saved.length() == 0) {
                if (!bundled.isFile() || bundled.length() == 0)
                    throw new IOException("Компонент отсутствует и в ApkStudio/components, и в APK: " + name);
                copyAtomic(bundled, saved);
                log.log("Компонент впервые сохранён в ApkStudio/components: " + name);
            }
            File runtime = new File(nativeDir, name);
            if (!runtime.isFile() || runtime.length() != saved.length()) {
                copyAtomic(saved, runtime);
                try { Os.chmod(runtime.getPath(), 0755); } catch (Exception ignored) { }
                log.log("Компонент восстановлен из ApkStudio/components: " + name);
            }
        }
        File rootfs = new File(componentDir, "rootfs.tar.gz");
        if (!rootfs.isFile() || rootfs.length() < 10_000_000L) {
            try (InputStream in = ctx.getAssets().open("rootfs.tar.gz")) {
                File part = new File(rootfs.getPath() + ".part");
                Util.copy(in, part);
                if (rootfs.exists() && !rootfs.delete()) throw new IOException("Не удалось заменить rootfs");
                if (!part.renameTo(rootfs)) throw new IOException("Не удалось сохранить rootfs в components");
                log.log("Компонент впервые сохранён в ApkStudio/components: rootfs.tar.gz");
            } catch (IOException ignored) {
                // Older APKs may download rootfs on first setup; openRootfs() caches it afterwards.
            }
        }
    }

    /**
     * Fresh rootfs has no unzip yet, so cached system packages and the JDK are restored here
     * (symlinks and permissions included) before setup.sh runs. Failures are non-fatal.
     */
    private void restoreSystemCaches(Runner.Log log) {
        try {
            File debDir = new File(componentDir, "deb-cache");
            File debZip = new File(componentDir, "system-packages-debian-bookworm-arm64.zip");
            String[] debs = debDir.list((d, n) -> n.endsWith(".deb"));
            if (debZip.isFile() && debZip.length() > 0 && (debs == null || debs.length == 0)) {
                log.log("=== Восстановление кеша системных пакетов из Component");
                extractZip(debZip, componentDir);
            }
            File javac = new File(root, "usr/lib/jvm/java-17-openjdk-arm64/bin/javac");
            File jdkZip = new File(componentDir, "jdk-17-openjdk-arm64.zip");
            if (jdkZip.isFile() && jdkZip.length() > 0 && !javac.exists()) {
                log.log("=== Восстановление JDK 17 из Component");
                File jvm = new File(root, "usr/lib/jvm");
                jvm.mkdirs();
                extractZip(jdkZip, jvm);
            }
        } catch (Exception e) {
            log.log("WARN: не удалось восстановить кеш из Component: " + e.getMessage());
        }
    }

    private static void extractZip(File zip, File dest) throws IOException {
        String base = dest.getCanonicalPath() + File.separator;
        try (org.apache.commons.compress.archivers.zip.ZipFile zf = new org.apache.commons.compress.archivers.zip.ZipFile(zip)) {
            java.util.Enumeration<org.apache.commons.compress.archivers.zip.ZipArchiveEntry> en = zf.getEntries();
            while (en.hasMoreElements()) {
                org.apache.commons.compress.archivers.zip.ZipArchiveEntry e = en.nextElement();
                File out = new File(dest, e.getName());
                if (!out.getCanonicalFile().getPath().startsWith(base) && !(out.getCanonicalPath() + File.separator).equals(base))
                    throw new IOException("Bad zip entry: " + e.getName());
                if (e.isDirectory()) { out.mkdirs(); continue; }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                if (e.isUnixSymlink()) {
                    String target;
                    try (InputStream in = zf.getInputStream(e)) { target = new String(readAll(in), StandardCharsets.UTF_8); }
                    Files.deleteIfExists(out.toPath());
                    Files.createSymbolicLink(out.toPath(), java.nio.file.Paths.get(target));
                    continue;
                }
                try (InputStream in = zf.getInputStream(e)) { Util.copy(in, out); }
                int mode = e.getUnixMode() & 0777;
                if (mode != 0) { try { Os.chmod(out.getPath(), mode); } catch (Exception ignored) { } }
            }
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toByteArray();
    }

    private static void copyAtomic(File source, File target) throws IOException {
        File parent = target.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs())
            throw new IOException("Не удалось создать каталог: " + parent);
        File part = new File(target.getPath() + ".part");
        try (InputStream in = new FileInputStream(source)) { Util.copy(in, part); }
        if (target.exists() && !target.delete()) throw new IOException("Не удалось обновить компонент: " + target);
        if (!part.renameTo(target)) throw new IOException("Не удалось сохранить компонент: " + target);
    }

    // ------------------------------------------------------------ components

    private static String prop(File f, String key) {
        try {
            for (String line : Util.read(f).split("\\r?\\n")) {
                if (line.startsWith(key + "=")) return line.substring(key.length() + 1).replace("\"", "").trim();
            }
        } catch (IOException ignored) { /* файла нет */ }
        return null;
    }

    private static String firstLine(File f) {
        try {
            String[] l = Util.read(f).split("\\r?\\n");
            return l.length == 0 || l[0].trim().isEmpty() ? null : l[0].trim();
        } catch (IOException e) { return null; }
    }

    /** Установленные компоненты и версии: читается из файлов rootfs, без запуска proot. */
    List<String[]> components() {
        List<String[]> r = new ArrayList<>();
        if (!unpacked()) return r;
        String deb = firstLine(new File(root, "etc/debian_version"));
        r.add(new String[]{"Debian", deb == null ? "?" : deb});
        String jdk = prop(new File(root, "usr/lib/jvm/java-17-openjdk-arm64/release"), "JAVA_VERSION");
        r.add(new String[]{"JDK", jdk == null ? "не установлен" : jdk});

        String gradle = null;
        File[] gl = new File(root, "opt/gradle/lib").listFiles(
                (d, n) -> n.startsWith("gradle-launcher-") && n.endsWith(".jar"));
        if (gl != null && gl.length > 0) {
            String n = gl[0].getName();
            gradle = n.substring("gradle-launcher-".length(), n.length() - 4);
        }
        r.add(new String[]{"Gradle", gradle == null ? "не установлен" : gradle});

        File sdk = new File(root, "opt/android-sdk");
        String cmd = prop(new File(sdk, "cmdline-tools/latest/source.properties"), "Pkg.Revision");
        r.add(new String[]{"Android cmdline-tools", cmd == null ? "не установлен" : cmd});
        File[] platforms = new File(sdk, "platforms").listFiles(File::isDirectory);
        if (platforms == null || platforms.length == 0) {
            r.add(new String[]{"Android Platform", "не установлен"});
        } else {
            java.util.Arrays.sort(platforms);
            for (File pl : platforms) {
                String rev = prop(new File(pl, "source.properties"), "Pkg.Revision");
                r.add(new String[]{"Android Platform", pl.getName() + (rev == null ? "" : " (rev " + rev + ")")});
            }
        }
        File[] bt = new File(sdk, "build-tools").listFiles(File::isDirectory);
        if (bt == null || bt.length == 0) {
            r.add(new String[]{"Build Tools", "не установлен"});
        } else {
            java.util.Arrays.sort(bt);
            for (File b : bt) r.add(new String[]{"Build Tools", b.getName()});
        }
        String aapt2 = firstLine(new File(root, "opt/aapt2.version"));
        r.add(new String[]{"aapt2", aapt2 == null ? "встроен в APK (версия появится после «Обновить»)" : aapt2});

        java.util.Map<String, String> pk = new java.util.LinkedHashMap<>();
        for (String n : new String[]{"git", "curl", "unzip", "zip", "rsync"}) pk.put(n, null);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                new FileInputStream(new File(root, "var/lib/dpkg/status")), StandardCharsets.UTF_8))) {
            String line, pkg = null, ver = null;
            boolean ok = false;
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    if (pkg != null && ok && ver != null && pk.containsKey(pkg)) pk.put(pkg, ver);
                    pkg = null; ver = null; ok = false;
                } else if (line.startsWith("Package: ")) pkg = line.substring(9).trim();
                else if (line.startsWith("Version: ")) ver = line.substring(9).trim();
                else if (line.startsWith("Status: ")) ok = line.endsWith("installed") && !line.contains("not-installed");
            }
            if (pkg != null && ok && ver != null && pk.containsKey(pkg)) pk.put(pkg, ver);
        } catch (IOException ignored) { /* dpkg ещё не инициализирован */ }
        for (Map.Entry<String, String> e : pk.entrySet())
            r.add(new String[]{e.getKey(), e.getValue() == null ? "не установлен" : e.getValue()});
        return r;
    }

    void remove() {
        Util.deleteRecursive(root);
        Util.deleteRecursive(tmp);
    }

    // ---------------------------------------------------------------- rootfs

    void unpack(Runner.Log log) throws Exception {
        seedPersistentComponents(log);
        if (unpacked()) return;
        Util.deleteRecursive(root);
        root.mkdirs();
        log.log("Распаковка rootfs (один раз)...");
        log.log("APKSTUDIO_PROGRESS:2:Распаковка базовой Linux-системы");
        int n = 0;
        try (InputStream raw = openRootfs(log);
             TarArchiveInputStream tar = new TarArchiveInputStream(
                     new GZIPInputStream(new BufferedInputStream(raw, 1 << 16), 1 << 16))) {
            TarArchiveEntry e;
            while ((e = tar.getNextTarEntry()) != null) {
                if (Runner.get().isCancelRequested()) throw new IOException("Распаковка остановлена пользователем");
                String name = clean(e.getName());
                if (name.isEmpty() || hasDotDot(name)) continue;
                File f = new File(root, name);
                int mode = e.getMode() & 07777;
                if (e.isDirectory()) {
                    f.mkdirs();
                    Os.chmod(f.getPath(), mode | 0700);
                } else if (e.isSymbolicLink()) {
                    removeEntry(f);
                    mkParent(f);
                    Os.symlink(e.getLinkName(), f.getPath());
                } else if (e.isLink()) {
                    String t = clean(e.getLinkName());
                    if (t.isEmpty() || hasDotDot(t)) continue;
                    removeEntry(f);
                    mkParent(f);
                    try (InputStream in = new FileInputStream(new File(root, t))) {
                        Util.copy(in, f);
                    }
                    Os.chmod(f.getPath(), mode | 0600);
                } else if (e.isFile()) {
                    removeEntry(f);
                    mkParent(f);
                    Util.copy(tar, f);
                    Os.chmod(f.getPath(), mode | 0600);
                }
                if (++n % 3000 == 0) {
                    log.log("  ... " + n + " файлов");
                    int pct = Math.min(34, 2 + n / 4500);
                    log.log("APKSTUDIO_PROGRESS:" + pct + ":Распаковано записей: " + n);
                }
            }
        }
        new File(ctx.getFilesDir(), "rootfs.tar.gz").delete();
        new File(root, ".unpacked").createNewFile();
        log.log("APKSTUDIO_PROGRESS:36:Базовая Linux-система распакована");
        log.log("rootfs распакован: " + n + " записей");
    }

    private static final String ROOTFS_URL =
            "https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/"
                    + "dist-arm64v8/bookworm/slim/oci/blobs/rootfs.tar.gz";

    /** rootfs is reused from ApkStudio/components; older installs are migrated from the ZIP cache. */
    private InputStream openRootfs(Runner.Log log) throws IOException {
        File persistentRootfs = new File(componentDir, "rootfs.tar.gz");
        if (persistentRootfs.isFile() && persistentRootfs.length() > 10_000_000L)
            return new FileInputStream(persistentRootfs);
        try {
            InputStream asset = ctx.getAssets().open("rootfs.tar.gz");
            File part = new File(persistentRootfs.getPath() + ".part");
            try (InputStream in = asset) { Util.copy(in, part); }
            if (!persistentRootfs.exists() || persistentRootfs.delete()) part.renameTo(persistentRootfs);
            if (persistentRootfs.isFile() && persistentRootfs.length() > 10_000_000L)
                return new FileInputStream(persistentRootfs);
        } catch (IOException e) {
            // Older APK may not bundle rootfs; try the saved ZIP or download it.
        }
        File f = new File(ctx.getFilesDir(), "rootfs.tar.gz");
        File cached = new File(componentDir, "debian-bookworm-arm64-rootfs.zip");
        if ((!f.isFile() || f.length() < 10_000_000L) && cached.isFile() && cached.length() > 10_000_000L) {
            log.log("Восстановление Debian rootfs из components...");
            try (ZipInputStream zi = new ZipInputStream(new FileInputStream(cached))) {
                ZipEntry entry = zi.getNextEntry();
                if (entry == null || !"rootfs.tar.gz".equals(entry.getName()))
                    throw new IOException("Некорректный архив Debian rootfs в components");
                try (java.io.OutputStream out = new FileOutputStream(f)) {
                    byte[] buffer = new byte[65536]; int count;
                    while ((count = zi.read(buffer)) > 0) out.write(buffer, 0, count);
                }
            } catch (IOException badCache) {
                log.log("WARN: архив rootfs в components повреждён, загружаю заново: " + badCache.getMessage());
                f.delete(); cached.delete();
            }
        }
        if (!f.isFile() || f.length() < 10_000_000L) {
            if (offlineInstall)
                throw new IOException("Автономная установка: rootfs.tar.gz отсутствует или повреждён в ApkStudio/components");
            log.log("rootfs.tar.gz нет в APK/components, скачиваю из интернета (~28 МБ)...");
            File part = new File(f.getPath() + ".part");
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(ROOTFS_URL).openConnection();
            activeConnection = c;
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            try {
                if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode() + " " + ROOTFS_URL);
                try (InputStream in = c.getInputStream();
                     java.io.OutputStream out = new java.io.FileOutputStream(part)) {
                    byte[] buf = new byte[1 << 16];
                    long total = 0, next = 5L << 20;
                    long expected = c.getContentLengthLong();
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (Runner.get().isCancelRequested()) throw new IOException("Загрузка остановлена пользователем");
                        out.write(buf, 0, n);
                        total += n;
                        if (total >= next) {
                            log.log("  ... " + (total >> 20) + " МБ");
                            if (expected > 0) {
                                int pct = 2 + (int) Math.min(14, 14L * total / expected);
                                log.log("APKSTUDIO_PROGRESS:" + pct + ":Загрузка Linux rootfs: " + (total >> 20) + " МБ");
                            }
                            next += 5L << 20;
                        }
                    }
                }
            } finally {
                c.disconnect();
                if (activeConnection == c) activeConnection = null;
            }
            f.delete();
            if (!part.renameTo(f)) throw new IOException("не удалось сохранить rootfs");
            try {
                File saved = new File(componentDir, "rootfs.tar.gz");
                File partSaved = new File(saved.getPath() + ".part");
                try (InputStream in = new FileInputStream(f)) { Util.copy(in, partSaved); }
                if (saved.exists()) saved.delete();
                if (!partSaved.renameTo(saved)) throw new IOException("не удалось сохранить rootfs в components");
                cacheRootfsZip(f, cached);
                log.log("rootfs сохранён в ApkStudio/components/rootfs.tar.gz");
            } catch (Exception cacheError) { log.log("WARN: не удалось сохранить rootfs в components: " + cacheError.getMessage()); }
        }
        return new FileInputStream(f);
    }

    /** Store the already-compressed rootfs tarball in a ZIP without recompressing its contents. */
    private static void cacheRootfsZip(File source, File destination) throws IOException {
        CRC32 crc = new CRC32();
        try (InputStream in = new FileInputStream(source)) {
            byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) > 0) crc.update(b, 0, n);
        }
        File temp = new File(destination.getPath() + ".part");
        try (ZipOutputStream zip = new ZipOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(temp)));
             InputStream in = new FileInputStream(source)) {
            ZipEntry entry = new ZipEntry("rootfs.tar.gz");
            entry.setMethod(ZipEntry.STORED);
            entry.setSize(source.length());
            entry.setCompressedSize(source.length());
            entry.setCrc(crc.getValue());
            zip.putNextEntry(entry);
            byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) > 0) zip.write(b, 0, n);
            zip.closeEntry();
        }
        if (destination.exists() && !destination.delete()) throw new IOException("не удалось заменить кеш rootfs");
        if (!temp.renameTo(destination)) throw new IOException("не удалось сохранить ZIP rootfs");
    }

    private static String clean(String s) {
        while (s.startsWith("./") || s.startsWith("/")) s = s.substring(s.startsWith("./") ? 2 : 1);
        return s.equals(".") ? "" : s;
    }

    private static boolean hasDotDot(String s) {
        for (String p : s.split("/")) if (p.equals("..")) return true;
        return false;
    }

    private static void removeEntry(File f) {
        if (Files.isSymbolicLink(f.toPath()) || f.isFile()) f.delete();
    }

    private static void mkParent(File f) {
        File p = f.getParentFile();
        if (p != null) p.mkdirs();
    }

    /** Cheap, idempotent preparation done before every proot launch. */
    void prepare() throws Exception {
        seedPersistentComponents(new Runner.Log() { @Override public void log(String line) { } });
        tmp.mkdirs();
        libDir.mkdirs();
        File link = new File(libDir, "libtalloc.so.2");
        link.delete();
        Os.symlink(new File(nativeDir, "libtalloc.so").getPath(), link.getPath());

        new File(root, "project").mkdirs();
        new File(root, "opt/native").mkdirs();
        new File(root, "root").mkdirs();
        new File(root, "root/.android").mkdirs();
        signingDir.mkdirs();
        // Migrate the old Gradle debug key before binding the persistent directory.
        File stableKey = new File(signingDir, "debug.keystore");
        File oldKey = new File(root, "root/.android/debug.keystore");
        if (!stableKey.exists() && oldKey.isFile()) {
            try (InputStream in = new FileInputStream(oldKey)) {
                Util.copy(in, stableKey);
            }
        }
        File rt = new File(root, "tmp");
        rt.mkdirs();
        Os.chmod(rt.getPath(), 01777);

        File resolv = new File(root, "etc/resolv.conf");
        removeEntry(resolv);
        Util.write(resolv, "nameserver 8.8.8.8\nnameserver 1.1.1.1\n");
        File hosts = new File(root, "etc/hosts");
        removeEntry(hosts);
        Util.write(hosts, "127.0.0.1 localhost\n::1 localhost\n");

        for (String s : new String[]{"setup.sh", "build.sh"}) {
            File out = new File(root, "opt/" + s);
            try (InputStream in = ctx.getAssets().open(s)) {
                Util.copy(in, out);
            }
            Os.chmod(out.getPath(), 0755);
        }
    }

    // ---------------------------------------------------------------- exec

    private int heapMb() {
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long mb = mi.availMem / (1024 * 1024) - 1536;
            return (int) Math.max(1024, Math.min(3072, mb));
        } catch (Exception e) {
            return 2048;
        }
    }

    /** Runs a command inside the rootfs. project is bound at /project (may be null). */
    int exec(Runner.Log log, File project, String... guestCmd) throws Exception {
        if (!unpacked()) throw new IOException("rootfs не распакован");
        File proot = new File(nativeDir, "libproot.so");
        if (!proot.exists()) throw new IOException("libproot.so отсутствует в APK");

        List<String> cmd = new ArrayList<>(Arrays.asList(
                proot.getPath(), "-r", root.getPath(), "-0", "--link2symlink", "--kill-on-exit",
                "--kernel-release=6.2.0-ApkStudio",
                "-b", "/dev", "-b", "/proc", "-b", "/sys",
                "-b", signingDir.getPath() + ":/root/.android",
                "-b", nativeDir.getPath() + ":/opt/native",
                "-b", componentDir.getPath() + ":/opt/apkstudio-components"));
        if (project != null) {
            cmd.add("-b");
            cmd.add(project.getPath() + ":/project");
        }
        cmd.addAll(Arrays.asList("-w", "/root", "/usr/bin/env", "-i",
                "HOME=/root", "USER=root", "LANG=C.UTF-8", "TERM=dumb", "TMPDIR=/tmp",
                "PATH=/opt/gradle/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=" + JAVA_HOME,
                "ANDROID_HOME=/opt/android-sdk", "ANDROID_SDK_ROOT=/opt/android-sdk",
                "JAVA_OPTS=-XX:-UseContainerSupport", "GRADLE_OPTS=-XX:-UseContainerSupport",
                "DEBIAN_FRONTEND=noninteractive", "BUILD_XMX=" + heapMb(),
                "BUILD_WORKERS=" + Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() - 1)),
                "BUILD_PROJECT_KEY=" + (project == null ? "project" : Util.safeName(project.getName())),
                "BUILD_CHANNEL=" + (project == null ? "stable" : ReleaseChannels.normalize(project.getParentFile().getName()))));
        cmd.addAll(Arrays.asList(guestCmd));

        ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true);
        Map<String, String> env = pb.environment();
        env.put("PROOT_LOADER", new File(nativeDir, "libproot-loader.so").getPath());
        env.put("PROOT_TMP_DIR", tmp.getPath());
        env.put("LD_LIBRARY_PATH", libDir.getPath() + ":" + nativeDir.getPath());
        env.put("PROOT_NO_SECCOMP", "1");

        Process p = pb.start();
        current = p;
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) log.log(line);
        } catch (IOException readError) {
            // destroyForcibly() / Android's process reaper can close the pipe
            // while readLine() is blocked. Report the real process exit code
            // instead of masking it with "read interrupted by close()".
            if (p.isAlive()) throw readError;
            log.log("WARN: поток вывода процесса закрыт при завершении: " + readError.getMessage());
        }
        int exit = p.waitFor();
        if (exit != 0) log.log("Процесс завершился с кодом " + exit);
        return exit;
    }

    /** Download missing tools/dependencies online, without deleting a working environment. */
    void setup(Runner.Log log) throws Exception { setup(log, false); }

    /** Legacy force-refresh entry point retained for callers that explicitly request it. */
    void setup(Runner.Log log, boolean fresh) throws Exception {
        if (fresh) {
            log.log("=== Очистка кеша компонентов для повторной загрузки");
            clearComponentCache();
        } else {
            extractBundle(log);
        }
        runSetup(log, false);
    }

    /** Download/build the complete reusable component bundle. A previously installed environment is preserved. */
    void downloadAllComponents(Runner.Log log) throws Exception {
        boolean hadEnvironment = unpacked();
        File backup = new File(root.getPath() + ".download-backup");
        if (hadEnvironment) {
            if (backup.exists()) throw new IOException("Найден незавершённый backup Linux-среды: " + backup);
            if (!root.renameTo(backup)) throw new IOException("Не удалось временно сохранить текущую Linux-среду");
            log.log("=== Текущая Linux-среда временно сохранена без изменений");
        }
        log.log("=== Загрузка полного комплекта компонентов");
        try {
            setup(log, false);
            if (!bundleFile().isFile() || bundleFile().length() == 0 || !isBundle(bundleFile()))
                throw new IOException("Не удалось сформировать архив компонентов");
            log.log("✔ Полный архив компонентов сохранён: " + bundleFile().getAbsolutePath());
        } finally {
            // Download uses a disposable rootfs. Never replace an already installed environment.
            remove();
            if (hadEnvironment && backup.exists() && !backup.renameTo(root))
                throw new IOException("Архив компонентов подготовлен, но не удалось восстановить прежнюю Linux-среду из " + backup);
            log.log("=== Временная Linux-среда очищена; сохранённый архив компонентов не затронут");
        }
    }

    /** Install strictly from the saved bundle. No network fallback is allowed. */
    void setupFromBundle(Runner.Log log) throws Exception {
        File bundle = bundleFile();
        if (!bundle.isFile() || bundle.length() == 0 || !isBundle(bundle))
            throw new IOException("Общий архив компонентов не найден. Сначала нажмите «Скачать все компоненты» или добавьте ApkStudio-components.zip.");
        String[] required = {
                "rootfs.tar.gz",
                "system-packages-debian-bookworm-arm64.zip",
                "jdk-17-openjdk-arm64.zip",
                "android-commandlinetools-11076708.zip",
                "android-sdk-full.zip",
                "gradle-8.9-bin.zip",
                "gradle-deps-cache.zip"
        };
        List<String> missing = new ArrayList<>();
        try (org.apache.commons.compress.archivers.zip.ZipFile zf = new org.apache.commons.compress.archivers.zip.ZipFile(bundle)) {
            for (String name : required) {
                org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = zf.getEntry(name);
                if (entry == null || entry.isDirectory() || entry.getSize() <= 0) missing.add(name);
            }
        }
        if (!missing.isEmpty())
            throw new IOException("В общем архиве отсутствуют компоненты: " + android.text.TextUtils.join(", ", missing)
                    + ". Подключите интернет и нажмите «Скачать все компоненты».");
        extractBundle(log);
        offlineInstall = true;
        try {
            runSetup(log, true);
        } finally {
            offlineInstall = false;
        }
    }

    private void runSetup(Runner.Log log, boolean offline) throws Exception {
        unpack(log);
        prepare();
        restoreSystemCaches(log);
        int code = offline
                ? exec(log, null, "/bin/bash", "/opt/setup.sh", "--offline")
                : exec(log, null, "/bin/bash", "/opt/setup.sh");
        if (code != 0) throw new IOException("setup.sh завершился с кодом " + code);
        log.log("APKSTUDIO_PROGRESS:99:Проверка и упаковка компонентов");
        createBundle(log);
        log.log(offline ? "APKSTUDIO_PROGRESS:100:Среда восстановлена без интернета"
                : "APKSTUDIO_PROGRESS:100:Среда готова, архив компонентов обновлён");
    }

    // ------------------------------------------------------- component bundle

    static final String BUNDLE = "ApkStudio-components.zip";
    private static final String BUNDLE_MARK = ".apkstudio-bundle";

    File bundleFile() { return new File(componentDir, BUNDLE); }

    static boolean isBundle(File zip) {
        try (org.apache.commons.compress.archivers.zip.ZipFile zf = new org.apache.commons.compress.archivers.zip.ZipFile(zip)) {
            return zf.getEntry(BUNDLE_MARK) != null;
        } catch (Exception e) { return false; }
    }

    /** Unpack the single components ZIP into the components folder (existing equal-size files are kept). */
    void extractBundle(Runner.Log log) throws IOException {
        File bundle = bundleFile();
        if (!bundle.isFile() || bundle.length() == 0) return;
        if (!componentDir.exists() && !componentDir.mkdirs())
            throw new IOException("Не удалось создать папку: " + componentDir.getPath());
        log.log("=== Восстановление компонентов из " + BUNDLE);
        try (org.apache.commons.compress.archivers.zip.ZipFile zf = new org.apache.commons.compress.archivers.zip.ZipFile(bundle)) {
            java.util.Enumeration<org.apache.commons.compress.archivers.zip.ZipArchiveEntry> en = zf.getEntries();
            while (en.hasMoreElements()) {
                org.apache.commons.compress.archivers.zip.ZipArchiveEntry e = en.nextElement();
                String name = e.getName();
                if (e.isDirectory() || name.equals(BUNDLE_MARK) || name.contains("/") || name.contains("..")) continue;
                File out = new File(componentDir, name);
                if (out.isFile() && out.length() == e.getSize() && out.lastModified() >= bundle.lastModified()) continue;
                File part = new File(out.getPath() + ".part");
                try (InputStream in = zf.getInputStream(e)) { Util.copy(in, part); }
                if (out.exists() && !out.delete()) throw new IOException("Не удалось заменить " + name);
                if (!part.renameTo(out)) throw new IOException("Не удалось сохранить " + name);
                log.log("  " + name);
            }
        }
    }

    /** Pack every component file into one ZIP, then drop the loose copies that setup can restore from it. */
    void createBundle(Runner.Log log) throws IOException {
        File[] files = componentDir.listFiles(f -> f.isFile() && !f.getName().equals(BUNDLE) && !f.getName().endsWith(".part"));
        if (files == null || files.length == 0) return;
        Arrays.sort(files);
        File temp = new File(componentDir, BUNDLE + ".part");
        try (java.util.zip.ZipOutputStream zip = new java.util.zip.ZipOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(temp)))) {
            zip.setLevel(java.util.zip.Deflater.NO_COMPRESSION);
            zip.putNextEntry(new ZipEntry(BUNDLE_MARK));
            zip.closeEntry();
            byte[] buf = new byte[65536];
            for (File f : files) {
                zip.putNextEntry(new ZipEntry(f.getName()));
                try (InputStream in = new FileInputStream(f)) {
                    int n;
                    while ((n = in.read(buf)) > 0) zip.write(buf, 0, n);
                }
                zip.closeEntry();
            }
        }
        File bundle = bundleFile();
        if (bundle.exists() && !bundle.delete()) throw new IOException("Не удалось заменить " + BUNDLE);
        if (!temp.renameTo(bundle)) throw new IOException("Не удалось сохранить " + BUNDLE);
        log.log("Компоненты упакованы: " + BUNDLE + " (" + files.length + " файлов)");
        for (File f : files) if (f.getName().endsWith(".zip")) f.delete();
        Util.deleteRecursive(new File(componentDir, "deb-cache"));
    }

    /** Forget cached component archives so that the next setup downloads them again. */
    void clearComponentCache() {
        File[] files = componentDir.listFiles();
        if (files != null) for (File f : files)
            if (f.isFile() && f.getName().endsWith(".zip") && !f.getName().equals(BUNDLE)) f.delete();
        Util.deleteRecursive(new File(componentDir, "deb-cache"));
    }

    /** Add a user-chosen ZIP: the whole components bundle, or a single component archive. */
    String importComponentZip(InputStream in, String displayName, Runner.Log log) throws IOException {
        if (!componentDir.exists() && !componentDir.mkdirs())
            throw new IOException("Не удалось создать папку: " + componentDir.getPath());
        File part = new File(componentDir, ".import.part");
        Util.copy(in, part);
        if (isBundle(part)) {
            File bundle = bundleFile();
            if (bundle.exists() && !bundle.delete()) throw new IOException("Не удалось заменить " + BUNDLE);
            if (!part.renameTo(bundle)) throw new IOException("Не удалось сохранить " + BUNDLE);
            return "Общий ZIP компонентов добавлен. Нажмите «Установить».";
        }
        String name = new File(displayName == null || displayName.isEmpty() ? "component.zip" : displayName).getName();
        File out = new File(componentDir, name);
        if (out.exists() && !out.delete()) throw new IOException("Не удалось заменить " + name);
        if (!part.renameTo(out)) throw new IOException("Не удалось сохранить " + name);
        return "Компонент добавлен: " + name + ". Нажмите «Установить».";
    }

    void build(Runner.Log log, File project, List<String> gradleArgs) throws Exception {
        prepare();
        List<String> a = new ArrayList<>(Arrays.asList("/bin/bash", "/opt/build.sh"));
        a.addAll(gradleArgs);
        int code = exec(log, project, a.toArray(new String[0]));
        if (code != 0) throw new IOException("сборка завершилась с кодом " + code);
    }

    void shell(Runner.Log log, File project, String command) throws Exception {
        prepare();
        exec(log, project, "/bin/bash", "-lc", command);
    }
}
