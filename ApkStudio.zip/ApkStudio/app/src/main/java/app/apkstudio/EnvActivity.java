package app.apkstudio;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

/** Component manager: download a complete reusable bundle or install it offline. */
public class EnvActivity extends LogActivity {
    private Linux linux;
    private TextView status, componentsView;
    private Button bSetup, bDownload, bRun, bComponents, bAddZip;
    private static final int REQ_COMPONENT_ZIP = 51;
    private volatile String activeOperation = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout content = new LinearLayout(this);
        Ui.page(content, this);
        content.setPadding(dp(16), dp(14), dp(16), dp(10));
        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(false);
        pageScroll.setClipToPadding(false);
        pageScroll.addView(content);
        root.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        content.addView(Ui.header(this, "Компоненты", "BUILD COMPONENTS", true, null));
        status = new TextView(this);
        Ui.body(status);
        LinearLayout statusCard = Ui.card(this);
        statusCard.addView(status);
        Ui.add(content, statusCard, this, 0);

        TextView compTitle = new TextView(this);
        compTitle.setText("Установленные компоненты"); Ui.title(compTitle, 15);
        componentsView = new TextView(this);
        Ui.body(componentsView);
        componentsView.setTypeface(android.graphics.Typeface.MONOSPACE);
        componentsView.setTextSize(12);
        LinearLayout compCard = Ui.card(this);
        compCard.addView(compTitle);
        compCard.addView(componentsView);
        Ui.add(content, compCard, this, 8);

        bDownload = new Button(this);
        bDownload.setText("Скачать"); Ui.button(bDownload, this, true);
        bSetup = new Button(this);
        bSetup.setText("Установить"); Ui.button(bSetup, this, false);
        Ui.add(content, Ui.row(this, bDownload, bSetup), this, 12);

        bAddZip = new Button(this);
        bAddZip.setText("Добавить архив компонентов"); Ui.button(bAddZip, this, false);
        Ui.add(content, bAddZip, this, 8);
        bComponents = new Button(this);
        bComponents.setText("Файлы в components"); Ui.button(bComponents, this, false);
        Ui.add(content, bComponents, this, 8);

        LinearLayout sh = new LinearLayout(this);
        EditText cmd = new EditText(this);
        cmd.setHint("shell-команда в Linux"); Ui.input(cmd, this);
        cmd.setSingleLine();
        bRun = new Button(this);
        bRun.setText("Выполнить"); Ui.button(bRun, this, false);
        sh.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sh.addView(cmd, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, dp(48));
        rp.leftMargin = dp(8);
        sh.addView(bRun, rp);
        Ui.add(content, sh, this, 8);

        // The operation/progress/log dock is outside the scroll view and stays at screen bottom.
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setPadding(dp(12), dp(4), dp(12), dp(8));
        dock.setBackgroundColor(Ui.BG);
        dock.addView(makeProgressView(), new LinearLayout.LayoutParams(-1, -2));
        dock.addView(makeLogCard(), new LinearLayout.LayoutParams(-1, -2));
        root.addView(dock, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        File crash = new File(getFilesDir(), "crash.txt");
        if (crash.isFile()) {
            try {
                Runner.get().claim(owner());
                Runner.get().log("=== Последний сбой приложения:\n" + Util.read(crash));
            } catch (Exception ignored) { }
            crash.delete();
        }

        bDownload.setOnClickListener(v -> {
            if (Runner.get().isRunning()) { if ("download".equals(activeOperation)) Runner.get().cancel(); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Скачать все компоненты?")
                    .setMessage("Будут загружены Linux, JDK, Android SDK, Gradle и кеш зависимостей. Компоненты сохранятся в ApkStudio/components/ApkStudio-components.zip. Потребуется интернет и несколько ГБ свободного места.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Скачать", (d, w) -> startOperation("download"))
                    .show();
        });
        bSetup.setOnClickListener(v -> {
            if (Runner.get().isRunning()) { if ("install".equals(activeOperation)) Runner.get().cancel(); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Установить компоненты?")
                    .setMessage("Среда будет восстановлена только из сохранённого архива components. Интернет для установки не требуется.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Установить", (d, w) -> startOperation("install"))
                    .show();
        });
        bAddZip.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            i.setType("application/zip");
            startActivityForResult(i, REQ_COMPONENT_ZIP);
        });
        bComponents.setOnClickListener(v -> showComponents());
        bRun.setOnClickListener(v -> {
            String c = cmd.getText().toString().trim();
            if (c.isEmpty()) return;
            if (!linux.unpacked()) {
                Toast.makeText(this, "Сначала установите среду", Toast.LENGTH_LONG).show();
                return;
            }
            Runner.get().start(this, owner(), "shell", log -> {
                log.log("$ " + c);
                linux.shell(log, null, c);
            });
        });
    }

    private void startOperation(String operation) {
        activeOperation = operation;
        Runner.get().clear();
        logView.setText("");
        if ("download".equals(operation)) {
            Runner.get().start(this, owner(), "Загрузка всех компонентов", log -> linux.downloadAllComponents(log));
        } else {
            Runner.get().start(this, owner(), "Установка компонентов из архива", log -> linux.setupFromBundle(log));
        }
    }

    @Override
    protected void onActivityResult(int request, int result, android.content.Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_COMPONENT_ZIP || result != RESULT_OK || data == null || data.getData() == null) return;
        final android.net.Uri uri = data.getData();
        String n = "component.zip";
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) n = c.getString(i);
            }
        } catch (Exception ignored) { }
        final String name = n;
        Runner.get().clear();
        logView.setText("");
        Runner.get().start(this, owner(), "Добавление архива компонентов", log -> {
            try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                log.log(linux.importComponentZip(in, name, log));
            }
        });
    }

    private void showComponents() {
        File dir = Util.componentDir(this);
        File[] files = dir.listFiles();
        java.util.Arrays.sort(files == null ? new File[0] : files);
        java.util.List<String> rows = new ArrayList<>();
        if (files != null) for (File f : files) {
            if (f.isFile()) rows.add(f.getName() + "  ·  " + android.text.format.Formatter.formatFileSize(this, f.length()));
        }
        String message = rows.isEmpty()
                ? "Компоненты появятся здесь после скачивания."
                : "Папка: " + dir.getAbsolutePath() + "\n\n" + android.text.TextUtils.join("\n", rows);
        new AlertDialog.Builder(this).setTitle("components · кеш инструментов")
                .setMessage(message).setPositiveButton("Понятно", null).show();
    }

    @Override String owner() { return "env"; }

    @Override
    void stateChanged(boolean running) {
        String s = linux.installed() ? "Среда установлена"
                : linux.unpacked() ? "Linux распакован, инструменты не установлены"
                : "Компоненты ещё не установлены";
        status.setText(s + (running ? " · выполняется операция" : ""));
        boolean downloadActive = running && "download".equals(activeOperation);
        boolean installActive = running && "install".equals(activeOperation);
        bDownload.setEnabled(!running || downloadActive);
        bSetup.setEnabled(!running || installActive);
        bDownload.setText(downloadActive ? "Остановить" : "Скачать");
        bSetup.setText(installActive ? "Остановить" : "Установить");
        styleOperationButton(bDownload, downloadActive);
        styleOperationButton(bSetup, installActive);
        bAddZip.setEnabled(!running);
        bComponents.setEnabled(!running);
        bRun.setEnabled(!running);
        if (!running) {
            activeOperation = "";
            loadComponents();
        }
    }

    private void styleOperationButton(Button button, boolean stop) {
        if (stop) {
            button.setTextColor(android.graphics.Color.WHITE);
            button.setBackground(Ui.shape(Ui.DANGER, Ui.DANGER, 14,
                    getResources().getDisplayMetrics().density));
        } else {
            boolean primary = button == bDownload;
            Ui.button(button, this, primary);
        }
    }

    private void loadComponents() {
        new Thread(() -> {
            java.util.List<String[]> list = linux.components();
            StringBuilder sb = new StringBuilder();
            for (String[] c : list) sb.append(c[0]).append(": ").append(c[1]).append('\n');
            String text = list.isEmpty() ? "Среда не установлена" : sb.toString().trim();
            runOnUiThread(() -> componentsView.setText(text));
        }).start();
    }
}
