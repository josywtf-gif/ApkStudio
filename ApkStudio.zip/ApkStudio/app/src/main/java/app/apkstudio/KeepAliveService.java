package app.apkstudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the process alive (foreground) while a build or setup job runs. */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "job";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent != null ? intent.getStringExtra("title") : null;
        try {
            Notification.Builder nb;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL, "ApkStudio", NotificationManager.IMPORTANCE_LOW));
                nb = new Notification.Builder(this, CHANNEL);
            } else {
                nb = new Notification.Builder(this);
            }
            Notification n = nb
                    .setContentTitle("ApkStudio")
                    .setContentText(title == null ? "Работает" : title)
                    .setSmallIcon(android.R.drawable.stat_sys_download)
                    .setOngoing(true)
                    .build();
            startForeground(1, n);
        } catch (Throwable t) {
            Runner.get().log("WARN: foreground service: " + t);
        }
        if (intent != null && intent.getBooleanExtra("stop", false)) {
            stopForeground(true);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
