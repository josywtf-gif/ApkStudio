package app.apkstudio;

import java.io.File;

/** Stable/Beta channel metadata and package identity rules. */
final class ReleaseChannels {
    static final String STABLE = "stable";
    static final String BETA = "beta";
    private ReleaseChannels() {}
    static String normalize(String value) { return BETA.equalsIgnoreCase(value) ? BETA : STABLE; }
    static String title(String value) { return BETA.equals(normalize(value)) ? "Бета" : "Стабильный"; }
    static String suffix(String value) { return BETA.equals(normalize(value)) ? ".b.app" : ".s.app"; }
    static File channelDir(File project, String channel) { return new File(project, normalize(channel)); }
}
