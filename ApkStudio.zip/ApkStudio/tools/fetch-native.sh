#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JNI="$ROOT/app/src/main/jniLibs/arm64-v8a"
ASSETS="$ROOT/app/src/main/assets"
mkdir -p "$JNI" "$ASSETS"
required=(libproot.so libproot-loader.so libtalloc.so libandroid-shmem.so libaapt2.so)
complete=1
[ -s "$ASSETS/rootfs.tar.gz" ] || complete=0
for f in "${required[@]}"; do [ -s "$JNI/$f" ] || complete=0; done
if [ "$complete" = 1 ]; then
  echo "Native payload already present"
  exit 0
fi
for c in curl dpkg-deb unzip; do
  command -v "$c" >/dev/null || { echo "Missing host tool: $c"; exit 1; }
done
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
REPO=https://packages.termux.dev/apt/termux-main
curl -fsSL --retry 3 "$REPO/dists/stable/main/binary-aarch64/Packages" -o "$T/Packages"
deb_path() {
  awk -v p="$1" 'BEGIN{RS="";FS="\n"}
    {n="";f="";for(i=1;i<=NF;i++){if($i~/^Package: /)n=substr($i,10);if($i~/^Filename: /)f=substr($i,11)}
     if(n==p){print f;exit}}' "$T/Packages"
}
for pkg in proot libtalloc libandroid-shmem; do
  f="$(deb_path "$pkg")"
  [ -n "$f" ] || { echo "Package $pkg not found in Termux repository"; exit 1; }
  curl -fsSL --retry 3 "$REPO/$f" -o "$T/$pkg.deb"
  mkdir -p "$T/$pkg"
  dpkg-deb -x "$T/$pkg.deb" "$T/$pkg"
done
PROOT="$(find "$T/proot" -type f -name proot | head -n1)"
LOADER="$(find "$T/proot" -type f -name loader | head -n1)"
TALLOC="$(find "$T/libtalloc" -type f -name 'libtalloc.so.2*' | head -n1)"
SHMEM="$(find "$T/libandroid-shmem" \( -type f -o -type l \) -name libandroid-shmem.so | head -n1)"
[ -n "$PROOT" ] && [ -n "$LOADER" ] && [ -n "$TALLOC" ] && [ -n "$SHMEM" ] || {
  echo "Could not locate proot native binaries in downloaded packages"; exit 1;
}
cp "$PROOT" "$JNI/libproot.so"
cp "$LOADER" "$JNI/libproot-loader.so"
cp "$TALLOC" "$JNI/libtalloc.so"
cp -L "$SHMEM" "$JNI/libandroid-shmem.so"
curl -fsSL --retry 3 -o "$T/tools.zip" \
  https://github.com/lzhiyong/android-sdk-tools/releases/download/35.0.2/android-sdk-tools-static-aarch64.zip
mkdir -p "$T/tools"
unzip -q "$T/tools.zip" -d "$T/tools"
AAPT2="$(find "$T/tools" -type f -name aapt2 | head -n1)"
[ -n "$AAPT2" ] || { echo "aapt2 not found"; exit 1; }
cp "$AAPT2" "$JNI/libaapt2.so"
chmod 0755 "$JNI"/*.so
for f in "${required[@]}"; do
  [ -s "$JNI/$f" ] || { echo "Native payload incomplete: $f"; exit 1; }
done
echo "== Debian arm64 rootfs"
ROOTFS_URL=https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/dist-arm64v8/bookworm/slim/oci/blobs/rootfs.tar.gz
curl -fsSL --retry 3 "$ROOTFS_URL" -o "$ASSETS/rootfs.tar.gz"
tar -tzf "$ASSETS/rootfs.tar.gz" > "$T/rootfs.list"
grep -q 'etc/debian_version' "$T/rootfs.list" || { echo "Downloaded rootfs archive is invalid"; exit 1; }
echo "Native payload installed:"
ls -lh "$JNI" "$ASSETS/rootfs.tar.gz"
