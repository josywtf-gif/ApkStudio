#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
SDK=/opt/android-sdk
GRADLE_VER=8.9

echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/99apkstudio
echo 'force-unsafe-io' > /etc/dpkg/dpkg.cfg.d/99apkstudio

if ! command -v javac >/dev/null || ! command -v curl >/dev/null || ! command -v unzip >/dev/null; then
  echo "=== apt: JDK 17 + utils"
  apt-get update
  apt-get install -y --no-install-recommends ca-certificates curl unzip git openjdk-17-jdk-headless
fi

mkdir -p /opt/tools /root/.gradle
ln -sf /opt/native/libaapt2.so /opt/tools/aapt2

if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "=== Android cmdline-tools"
  mkdir -p "$SDK/cmdline-tools"
  curl -fL --retry 3 -o /tmp/cmdline-tools.zip \
    https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q -o /tmp/cmdline-tools.zip -d "$SDK/cmdline-tools"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -f /tmp/cmdline-tools.zip
fi

export PATH="$SDK/cmdline-tools/latest/bin:$PATH"
echo "=== Android SDK licenses and packages"
yes | sdkmanager --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true
sdkmanager --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0"

if [ ! -x /opt/gradle/bin/gradle ]; then
  echo "=== Gradle $GRADLE_VER"
  curl -fL --retry 3 -o /tmp/gradle.zip \
    "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip"
  unzip -q -o /tmp/gradle.zip -d /opt
  rm -rf /opt/gradle
  mv "/opt/gradle-$GRADLE_VER" /opt/gradle
  rm -f /tmp/gradle.zip
fi

cat > /root/.gradle/gradle.properties <<'EOF'
android.aapt2FromMavenOverride=/opt/tools/aapt2
org.gradle.daemon=false
org.gradle.parallel=false
org.gradle.vfs.watch=false
EOF

echo "=== versions"
java -version 2>&1 | head -1
/opt/gradle/bin/gradle --version 2>&1 | grep -E '^Gradle' || true
/opt/tools/aapt2 version || echo "WARN: aapt2 did not start"

touch /opt/.setup-done
echo "=== Environment ready"
