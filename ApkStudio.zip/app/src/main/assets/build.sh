#!/bin/bash
set -e
XMX=${BUILD_XMX:-1024}
W=/root/work/project

echo "APKSTUDIO_PROGRESS:2:Копирование исходников проекта"
rm -rf "$W"
mkdir -p "$W"
cd /project
tar --no-wildcards-match-slash \
  --exclude='./build' --exclude='./.gradle' --exclude='./.git' \
  --exclude='./*/build' --exclude='./*/.gradle' \
  -cf - . | tar -C "$W" -xf -

cd "$W"
# The packaged project template may request 4 GiB regardless of the phone's
# available RAM. Respect the heap size selected by ApkStudio instead.
if [ -f gradle.properties ]; then
  if grep -q '^org.gradle.jvmargs=' gradle.properties; then
    sed -i -E "s/^org\.gradle\.jvmargs=.*/org.gradle.jvmargs=-Xmx${XMX}m -Dfile.encoding=UTF-8/" gradle.properties
  else
    printf '\norg.gradle.jvmargs=-Xmx%s m -Dfile.encoding=UTF-8\n' "$XMX" >> gradle.properties
    sed -i 's/ -Xmx\([0-9]*\) m/ -Xmx\1m/' gradle.properties
  fi
else
  printf 'org.gradle.jvmargs=-Xmx%s m -Dfile.encoding=UTF-8\n' "$XMX" > gradle.properties
  sed -i 's/ -Xmx\([0-9]*\) m/ -Xmx\1m/' gradle.properties
fi

if [ -f gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  G=(sh ./gradlew)
else
  G=(/opt/gradle/bin/gradle)
fi

ARGS=("$@")
if [ ${#ARGS[@]} -eq 0 ]; then ARGS=(assembleDebug); fi

# Gradle reports actual task graph completion. If it pauses before the first
# task, --info below exposes dependency resolution and daemon diagnostics.
cat > /tmp/apkstudio-progress.init.gradle <<'EOF'
gradle.taskGraph.whenReady { graph ->
    def tasks = graph.allTasks
    def total = Math.max(1, tasks.size())
    def done = 0
    gradle.taskGraph.afterTask { task, state ->
        done++
        def pct = 15 + (70.0 * done / total).intValue()
        println "APKSTUDIO_PROGRESS:${pct}:Задача ${done}/${total}: ${task.path}"
    }
}
EOF

echo "APKSTUDIO_PROGRESS:8:Запуск Gradle, проверка зависимостей"
echo "=== ${G[*]} ${ARGS[*]} (Xmx${XMX}m)"
"${G[@]}" --no-daemon --console=plain --stacktrace --info --max-workers=2 \
  -I /tmp/apkstudio-progress.init.gradle \
  -Dorg.gradle.parallel=false -Dorg.gradle.vfs.watch=false \
  -Dorg.gradle.native=false "${ARGS[@]}"

echo "APKSTUDIO_PROGRESS:90:Поиск и копирование APK"
mkdir -p /project/build/apk
rm -f /project/build/apk/*.apk
find "$W" -path '*/build/outputs/apk/*' -name '*.apk' -exec cp {} /project/build/apk/ \;
echo "=== APK:"
ls -la /project/build/apk
