#!/bin/bash
set -e
XMX=${BUILD_XMX:-2048}
W=/root/work/project

rm -rf "$W"
mkdir -p "$W"
cd /project
tar --no-wildcards-match-slash \
  --exclude='./build' --exclude='./.gradle' --exclude='./.git' \
  --exclude='./*/build' --exclude='./*/.gradle' \
  -cf - . | tar -C "$W" -xf -

cd "$W"
if [ -f gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  G=(sh ./gradlew)
else
  G=(/opt/gradle/bin/gradle)
fi

ARGS=("$@")
if [ ${#ARGS[@]} -eq 0 ]; then ARGS=(assembleDebug); fi

echo "=== ${G[*]} ${ARGS[*]} (Xmx${XMX}m)"
"${G[@]}" --no-daemon --console=plain \
  "-Dorg.gradle.jvmargs=-Xmx${XMX}m -XX:-UseContainerSupport -Dfile.encoding=UTF-8" \
  -Dorg.gradle.native=false \
  "${ARGS[@]}"

mkdir -p /project/build/apk
rm -f /project/build/apk/*.apk
find "$W" -path '*/build/outputs/apk/*' -name '*.apk' -exec cp {} /project/build/apk/ \;
echo "=== APK:"
ls -la /project/build/apk
