package app.apkstudio;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;

import java.util.concurrent.CopyOnWriteArrayList;

/** Single background job with a shared log that survives Activity recreation. */
final class Runner {
    interface Log { void log(String line); }
    interface Task { void run(Log log) throws Exception; }
    interface Listener {
        void onLog(String line);
        void onState(boolean running);
    }

    private static final Runner I = new Runner();
    private static final int MAX_LOG = 300_000;

    static Runner get() { return I; }

    private final StringBuilder buf = new StringBuilder();
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private boolean running;

    private Runner() {}

    synchronized boolean isRunning() { return running; }

    synchronized String attach(Listener l) {
        listeners.add(l);
        return buf.toString();
    }

    void detach(Listener l) { listeners.remove(l); }

    synchronized void clear() { buf.setLength(0); }

    void log(String line) {
        synchronized (this) {
            buf.append(line).append('\n');
            if (buf.length() > MAX_LOG) buf.delete(0, buf.length() - MAX_LOG / 2);
        }
        for (Listener l : listeners) l.onLog(line);
    }

    void cancel() {
        Process p = Linux.current;
        if (p != null) p.destroyForcibly();
    }

    boolean start(Context ctx, String title, Task task) {
        final Context app = ctx.getApplicationContext();
        synchronized (this) {
            if (running) return false;
            running = true;
        }
        for (Listener l : listeners) l.onState(true);

        final Intent svc = new Intent(app, KeepAliveService.class).putExtra("title", title);
        try {
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(svc);
            else app.startService(svc);
        } catch (Exception e) {
            log("WARN: foreground service: " + e);
        }
        PowerManager.WakeLock wl = null;
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apkstudio:job");
            wl.acquire(3L * 60 * 60 * 1000);
        } catch (Exception ignored) {
            // wake lock is best-effort
        }
        final PowerManager.WakeLock lock = wl;

        new Thread(null, () -> {
            try {
                log("=== " + title);
                task.run(this::log);
                log("=== OK");
            } catch (Throwable t) {
                log("=== FAILED: " + t.getMessage());
            } finally {
                Linux.current = null;
                synchronized (this) { running = false; }
                try {
                    if (lock != null && lock.isHeld()) lock.release();
                } catch (Exception ignored) {
                    // already released
                }
                app.stopService(svc);
                for (Listener l : listeners) l.onState(false);
            }
        }, "job", 16L * 1024 * 1024).start();
        return true;
    }
}
