package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;

public class EditorActivity extends Activity {
    private File file;
    private EditText edit;
    private boolean loaded;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        File project = new File(getIntent().getStringExtra("project"));
        String rel = getIntent().getStringExtra("path");
        file = new File(project, rel);
        setTitle(rel);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        Button save = new Button(this);
        save.setText("Сохранить");
        root.addView(save);

        edit = new EditText(this);
        edit.setTypeface(Typeface.MONOSPACE);
        edit.setTextSize(13);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        edit.setHorizontallyScrolling(false);
        root.addView(edit, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        try {
            if (file.length() > 1024 * 1024) throw new Exception("Файл больше 1 МБ");
            edit.setText(Util.read(file));
            loaded = true;
        } catch (Exception e) {
            edit.setText("");
            edit.setEnabled(false);
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        save.setOnClickListener(v -> {
            if (save()) Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean save() {
        if (!loaded) return false;
        try {
            Util.write(file, edit.getText().toString());
            return true;
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }
}
