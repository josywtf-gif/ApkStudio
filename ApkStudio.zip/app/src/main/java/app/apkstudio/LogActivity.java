package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.widget.ScrollView;
import android.widget.TextView;

/** Base for screens that show the shared job log. */
abstract class LogActivity extends Activity implements Runner.Listener {
    protected TextView logView;
    protected ScrollView logScroll;

    protected int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    protected ScrollView makeLogView() {
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(11);
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.addView(logView);
        return logScroll;
    }

    abstract void stateChanged(boolean running);

    @Override
    protected void onResume() {
        super.onResume();
        String s = Runner.get().attach(this);
        logView.setText(s);
        scrollDown();
        stateChanged(Runner.get().isRunning());
    }

    @Override
    protected void onPause() {
        super.onPause();
        Runner.get().detach(this);
    }

    private void scrollDown() {
        logScroll.post(() -> logScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    public void onLog(String line) {
        runOnUiThread(() -> {
            logView.append(line + "\n");
            scrollDown();
        });
    }

    @Override
    public void onState(boolean running) {
        runOnUiThread(() -> stateChanged(running));
    }
}
