package app.apkstudio;

import android.app.Activity;
import android.graphics.Typeface;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Base for screens that show the shared job log. */
abstract class LogActivity extends Activity implements Runner.Listener {
    protected TextView logView;
    protected ScrollView logScroll;
    private ProgressBar progressBar;
    private TextView progressText;

    protected int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    protected LinearLayout makeProgressView() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        progressText = new TextView(this);
        progressText.setText("Ожидание");
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        box.addView(progressText);
        box.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(8)));
        return box;
    }

    protected ScrollView makeLogView() {
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(11);
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.addView(logView);
        return logScroll;
    }

    abstract void stateChanged(boolean running);

    @Override
    protected void onResume() {
        super.onResume();
        String s = Runner.get().attach(this);
        logView.setText(s);
        scrollDown();
        onProgress(Runner.get().getProgress(), Runner.get().getProgressMessage());
        stateChanged(Runner.get().isRunning());
    }

    @Override
    protected void onPause() {
        super.onPause();
        Runner.get().detach(this);
    }

    private void scrollDown() {
        logScroll.post(() -> logScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    public void onLog(String line) {
        runOnUiThread(() -> {
            logView.append(line + "\n");
            scrollDown();
        });
    }

    @Override
    public void onProgress(int percent, String message) {
        runOnUiThread(() -> {
            if (progressBar != null) progressBar.setProgress(percent);
            if (progressText != null) progressText.setText(percent + "% — " + message);
        });
    }

    @Override
    public void onState(boolean running) {
        runOnUiThread(() -> stateChanged(running));
    }
}
