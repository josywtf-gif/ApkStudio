package app.apkstudio;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class EnvActivity extends LogActivity {
    private Linux linux;
    private TextView status;
    private Button bSetup, bRemove, bCancel, bRun;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("Среда сборки");
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        status = new TextView(this);
        status.setTextSize(15);
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        bSetup = new Button(this);
        bSetup.setText("Установить");
        bRemove = new Button(this);
        bRemove.setText("Удалить");
        bCancel = new Button(this);
        bCancel.setText("Стоп");
        row.addView(bSetup, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bRemove, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bCancel, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        LinearLayout sh = new LinearLayout(this);
        EditText cmd = new EditText(this);
        cmd.setHint("shell-команда в Linux");
        cmd.setSingleLine();
        bRun = new Button(this);
        bRun.setText("Run");
        sh.addView(cmd, new LinearLayout.LayoutParams(0, -2, 1));
        sh.addView(bRun, new LinearLayout.LayoutParams(-2, -2));
        root.addView(sh);

        root.addView(makeProgressView());
        root.addView(makeLogView(), new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        File crash = new File(getFilesDir(), "crash.txt");
        if (crash.isFile()) {
            try {
                Runner.get().log("=== Последний сбой приложения:\n" + Util.read(crash));
            } catch (Exception ignored) {
                // unreadable crash file
            }
            crash.delete();
        }

        bSetup.setOnClickListener(v -> {
            Runner.get().clear();
            logView.setText("");
            Runner.get().start(this, "Установка среды", log -> linux.setup(log));
        });
        bRemove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Удалить Linux-среду (~1.5 ГБ)?")
                .setPositiveButton("Удалить", (d, w) -> {
                    Runner.get().start(this, "Удаление среды", log -> {
                        linux.remove();
                        log.log("Удалено");
                    });
                })
                .setNegativeButton("Отмена", null)
                .show());
        bCancel.setOnClickListener(v -> Runner.get().cancel());
        bRun.setOnClickListener(v -> {
            String c = cmd.getText().toString().trim();
            if (c.isEmpty()) return;
            if (!linux.unpacked()) {
                Toast.makeText(this, "Сначала установите среду", Toast.LENGTH_LONG).show();
                return;
            }
            Runner.get().start(this, "shell", log -> {
                log.log("$ " + c);
                linux.shell(log, null, c);
            });
        });
    }

    @Override
    void stateChanged(boolean running) {
        String s = linux.installed() ? "Среда установлена"
                : linux.unpacked() ? "rootfs распакован, SDK/JDK/Gradle не установлены"
                : "Среда не установлена";
        status.setText(s + (running ? " (выполняется задача)" : ""));
        bSetup.setEnabled(!running);
        bRemove.setEnabled(!running);
        bRun.setEnabled(!running);
        bCancel.setEnabled(running);
        bSetup.setText(linux.installed() ? "Обновить" : "Установить");
    }
}
