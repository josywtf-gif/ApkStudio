package app.apkstudio;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/** Component manager: download a complete reusable bundle or install it offline. */
public class EnvActivity extends LogActivity {
    private Linux linux;
    private TextView status, componentsView;
    private Button bSetup, bDownload, bRun;
    private volatile String activeOperation = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.apply(this);
        linux = new Linux(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout content = new LinearLayout(this);
        Ui.page(content, this);
        content.setPadding(dp(16), dp(14), dp(16), dp(10));
        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(false);
        pageScroll.setClipToPadding(false);
        pageScroll.addView(content);
        root.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        content.addView(Ui.header(this, "Компоненты", "BUILD COMPONENTS", true, null));
        status = new TextView(this);
        Ui.body(status);
        LinearLayout statusCard = Ui.card(this);
        statusCard.addView(status);
        Ui.add(content, statusCard, this, 0);

        TextView compTitle = new TextView(this);
        compTitle.setText("Установленные компоненты"); Ui.title(compTitle, 15);
        componentsView = new TextView(this);
        Ui.body(componentsView);
        componentsView.setTypeface(android.graphics.Typeface.MONOSPACE);
        componentsView.setTextSize(12);
        LinearLayout compCard = Ui.card(this);
        compCard.addView(compTitle);
        compCard.addView(componentsView);
        Ui.add(content, compCard, this, 8);

        bDownload = new Button(this);
        bDownload.setText("Скачать"); Ui.button(bDownload, this, true);
        bSetup = new Button(this);
        bSetup.setText("Установить"); Ui.button(bSetup, this, false);
        Ui.add(content, Ui.row(this, bDownload, bSetup), this, 12);

        LinearLayout sh = new LinearLayout(this);
        EditText cmd = new EditText(this);
        cmd.setHint("shell-команда в Linux"); Ui.input(cmd, this);
        cmd.setSingleLine();
        bRun = new Button(this);
        bRun.setText("Выполнить"); Ui.button(bRun, this, false);
        sh.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sh.addView(cmd, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, dp(48));
        rp.leftMargin = dp(8);
        sh.addView(bRun, rp);
        Ui.add(content, sh, this, 8);

        // The operation/progress/log dock is outside the scroll view and stays at screen bottom.
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setPadding(dp(12), dp(4), dp(12), dp(8));
        dock.setBackgroundColor(Ui.BG);
        // Keep the expandable log above the progress bar so it opens upward
        // from the bottom dock instead of appearing underneath the progress.
        dock.addView(makeLogCard(), new LinearLayout.LayoutParams(-1, -2));
        dock.addView(makeProgressView(), new LinearLayout.LayoutParams(-1, -2));
        root.addView(dock, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        File crash = new File(getFilesDir(), "crash.txt");
        if (crash.isFile()) {
            try {
                Runner.get().claim(owner());
                Runner.get().log("=== Последний сбой приложения:\n" + Util.read(crash));
            } catch (Exception ignored) { }
            crash.delete();
        }

        bDownload.setOnClickListener(v -> {
            if (Runner.get().isRunning()) { if ("download".equals(activeOperation)) Runner.get().cancel(); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Скачать все компоненты?")
                    .setMessage("Будут загружены Linux, JDK, Android SDK, Gradle и кеш зависимостей. Компоненты сохранятся в ApkStudio/Component/ApkStudio-components.zip. Потребуется интернет и несколько ГБ свободного места.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Скачать", (d, w) -> startOperation("download"))
                    .show();
        });
        bSetup.setOnClickListener(v -> {
            if (Runner.get().isRunning()) { if ("install".equals(activeOperation)) Runner.get().cancel(); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Установить компоненты?")
                    .setMessage("Перед установкой скопируйте архив ApkStudio-components.zip или отдельные файлы компонентов в папку:\n\n"
                            + Util.componentDir(this).getAbsolutePath()
                            + "\n\nПосле нажатия «Установить» приложение сначала выведет этот путь в лог, затем проверит содержимое папки. Интернет для установки не требуется.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Установить", (d, w) -> startOperation("install"))
                    .show();
        });
        bRun.setOnClickListener(v -> {
            String c = cmd.getText().toString().trim();
            if (c.isEmpty()) return;
            if (!linux.unpacked()) {
                Toast.makeText(this, "Сначала установите среду", Toast.LENGTH_LONG).show();
                return;
            }
            Runner.get().start(this, owner(), "shell", log -> {
                log.log("$ " + c);
                linux.shell(log, null, c);
            });
        });
    }

    private void startOperation(String operation) {
        if (Runner.get().isRunning()) return;
        activeOperation = operation;
        Runner.get().clear();
        logView.setText("");
        boolean started;
        if ("download".equals(operation)) {
            started = Runner.get().start(this, owner(), "Загрузка всех компонентов",
                    log -> linux.downloadAllComponents(log));
        } else {
            started = Runner.get().start(this, owner(), "Установка компонентов из архива",
                    log -> linux.setupFromBundle(log));
        }
        if (!started) activeOperation = "";
        // Refresh immediately: only the button for the operation just started
        // becomes the highlighted Stop button; the other operation is disabled.
        updateOperationButtons(Runner.get().isRunning());
    }

    @Override String owner() { return "env"; }

    @Override
    void stateChanged(boolean running) {
        String s = linux.installed() ? "Среда установлена"
                : linux.unpacked() ? "Linux распакован, инструменты не установлены"
                : "Компоненты ещё не установлены";
        status.setText(s + (running ? " · выполняется операция" : ""));
        updateOperationButtons(running);
        bRun.setEnabled(!running);
        if (!running) {
            activeOperation = "";
            loadComponents();
        }
    }

    private void updateOperationButtons(boolean running) {
        boolean downloadActive = running && "download".equals(activeOperation);
        boolean installActive = running && "install".equals(activeOperation);
        bDownload.setEnabled(!running || downloadActive);
        bSetup.setEnabled(!running || installActive);
        bDownload.setText(downloadActive ? "Остановить" : "Скачать");
        bSetup.setText(installActive ? "Остановить" : "Установить");
        bDownload.setSelected(downloadActive);
        bSetup.setSelected(installActive);
        styleOperationButton(bDownload, downloadActive);
        styleOperationButton(bSetup, installActive);
    }

    private void styleOperationButton(Button button, boolean stop) {
        if (stop) {
            button.setTextColor(android.graphics.Color.WHITE);
            button.setBackground(Ui.shape(Ui.DANGER, Ui.DANGER, 14,
                    getResources().getDisplayMetrics().density));
        } else {
            boolean primary = button == bDownload;
            Ui.button(button, this, primary);
        }
    }

    private void loadComponents() {
        new Thread(() -> {
            java.util.List<String[]> list = linux.components();
            StringBuilder sb = new StringBuilder();
            for (String[] c : list) sb.append(c[0]).append(": ").append(c[1]).append('\n');
            String text = list.isEmpty() ? "Среда не установлена" : sb.toString().trim();
            runOnUiThread(() -> componentsView.setText(text));
        }).start();
    }
}
