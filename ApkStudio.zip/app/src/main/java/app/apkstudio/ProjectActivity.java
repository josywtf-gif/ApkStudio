package app.apkstudio;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProjectActivity extends LogActivity {
    private File project;
    private Linux linux;
    private final List<String> files = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private EditText tasks;
    private Button bBuild, bCancel;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        project = new File(Util.projectsDir(this), getIntent().getStringExtra("name"));
        linux = new Linux(this);
        setTitle(project.getName());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout row = new LinearLayout(this);
        bBuild = new Button(this);
        bBuild.setText("Build");
        Button bInstall = new Button(this);
        bInstall.setText("Install");
        bCancel = new Button(this);
        bCancel.setText("Стоп");
        Button bAdd = new Button(this);
        bAdd.setText("+ файл");
        row.addView(bBuild, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bInstall, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bCancel, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bAdd, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        tasks = new EditText(this);
        tasks.setSingleLine();
        tasks.setText("assembleDebug");
        tasks.setHint("Gradle-аргументы");
        root.addView(tasks);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, files);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(makeProgressView());
        root.addView(makeLogView(), new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        bBuild.setOnClickListener(v -> build());
        bInstall.setOnClickListener(v -> install());
        bCancel.setOnClickListener(v -> Runner.get().cancel());
        bAdd.setOnClickListener(v -> addFileDialog());
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, EditorActivity.class);
            i.putExtra("project", project.getPath());
            i.putExtra("path", files.get(pos));
            startActivity(i);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String rel = files.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Удалить " + rel + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        new File(project, rel).delete();
                        refresh();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    void stateChanged(boolean running) {
        bBuild.setEnabled(!running);
        bCancel.setEnabled(running);
        if (!running) refresh();
    }

    private void refresh() {
        files.clear();
        Util.listFiles(project, project, files);
        adapter.notifyDataSetChanged();
    }

    private void build() {
        if (!linux.installed()) {
            Toast.makeText(this, "Сначала установите среду сборки", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, EnvActivity.class));
            return;
        }
        String t = tasks.getText().toString().trim();
        List<String> args = t.isEmpty() ? new ArrayList<>() : new ArrayList<>(Arrays.asList(t.split("\\s+")));
        Runner.get().clear();
        logView.setText("");
        Runner.get().start(this, "Сборка " + project.getName(), log -> linux.build(log, project, args));
    }

    private File latestApk() {
        File[] apks = new File(project, "build/apk").listFiles((d, n) -> n.endsWith(".apk"));
        if (apks == null || apks.length == 0) return null;
        File best = apks[0];
        for (File f : apks) {
            boolean fd = f.getName().contains("debug");
            boolean bd = best.getName().contains("debug");
            if ((fd && !bd) || (fd == bd && f.lastModified() > best.lastModified())) best = f;
        }
        return best;
    }

    private void install() {
        File apk = latestApk();
        if (apk == null) {
            Toast.makeText(this, "Сначала соберите APK", Toast.LENGTH_LONG).show();
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Разрешите установку из этого источника", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private void addFileDialog() {
        EditText et = new EditText(this);
        et.setHint("например app/src/main/res/layout/main.xml");
        et.setSingleLine();
        new AlertDialog.Builder(this)
                .setTitle("Новый файл")
                .setView(et)
                .setPositiveButton("Создать", (d, w) -> {
                    String rel = et.getText().toString().trim();
                    if (rel.isEmpty()) return;
                    try {
                        File f = new File(project, rel);
                        if (!f.getCanonicalPath().startsWith(project.getCanonicalPath() + File.separator)) {
                            throw new Exception("Недопустимый путь");
                        }
                        if (!f.exists()) Util.write(f, "");
                        refresh();
                    } catch (Exception e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}
