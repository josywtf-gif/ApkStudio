package app.apkstudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;

    private final List<String> names = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("ApkStudio");
        title.setTextSize(26);
        root.addView(title);

        LinearLayout row = new LinearLayout(this);
        Button bNew = new Button(this);
        bNew.setText("Новый проект");
        Button bImport = new Button(this);
        bImport.setText("Импорт ZIP");
        Button bEnv = new Button(this);
        bEnv.setText("Среда");
        row.addView(bNew, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bImport, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(bEnv, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        bNew.setOnClickListener(v -> newProjectDialog());
        bEnv.setOnClickListener(v -> startActivity(new Intent(this, EnvActivity.class)));
        bImport.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IMPORT);
        });
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, ProjectActivity.class);
            i.putExtra("name", names.get(pos));
            startActivity(i);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            String n = names.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Удалить " + n + "?")
                    .setPositiveButton("Удалить", (d, w) -> {
                        Util.deleteRecursive(new File(Util.projectsDir(this), n));
                        refresh();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        names.clear();
        File[] dirs = Util.projectsDir(this).listFiles(File::isDirectory);
        if (dirs != null) {
            Arrays.sort(dirs);
            for (File d : dirs) names.add(d.getName());
        }
        adapter.notifyDataSetChanged();
    }

    private void newProjectDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText name = new EditText(this);
        name.setHint("Имя проекта");
        name.setSingleLine();
        EditText pkg = new EditText(this);
        pkg.setHint("Пакет, например com.example.app");
        pkg.setText("com.example.app");
        pkg.setSingleLine();
        box.addView(name);
        box.addView(pkg);
        new AlertDialog.Builder(this)
                .setTitle("Новый проект")
                .setView(box)
                .setPositiveButton("Создать", (d, w) -> {
                    String n = Util.safeName(name.getText().toString().trim());
                    String p = pkg.getText().toString().trim();
                    if (!p.matches("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+")) {
                        Toast.makeText(this, "Некорректный пакет", Toast.LENGTH_LONG).show();
                        return;
                    }
                    File dir = new File(Util.projectsDir(this), n);
                    if (dir.exists()) {
                        Toast.makeText(this, "Проект уже существует", Toast.LENGTH_LONG).show();
                        return;
                    }
                    try {
                        Templates.create(dir, p);
                        refresh();
                    } catch (Exception e) {
                        Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String n = "project";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) n = c.getString(i);
            }
        }
        if (n.toLowerCase().endsWith(".zip")) n = n.substring(0, n.length() - 4);
        final String base = Util.safeName(n);
        new Thread(() -> {
            String msg;
            try {
                File dir = new File(Util.projectsDir(this), base);
                if (dir.exists()) dir = new File(Util.projectsDir(this), base + "_" + System.currentTimeMillis());
                dir.mkdirs();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    Util.unzip(in, dir);
                }
                Util.flatten(dir);
                msg = Util.isProject(dir)
                        ? "Импортировано: " + dir.getName()
                        : "Импортировано, но AndroidManifest.xml / build.gradle в корне не найдены";
            } catch (Exception e) {
                msg = "Ошибка импорта: " + e;
            }
            final String m = msg;
            runOnUiThread(() -> {
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                refresh();
            });
        }).start();
    }
}
