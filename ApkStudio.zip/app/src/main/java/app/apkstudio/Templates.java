package app.apkstudio;

import java.io.File;
import java.io.IOException;

final class Templates {
    private Templates() {}

    static void create(File dir, String pkg) throws IOException {
        String name = dir.getName();
        Util.write(new File(dir, "settings.gradle"), """
                pluginManagement {
                    repositories {
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {
                        google()
                        mavenCentral()
                    }
                }
                rootProject.name = '%NAME%'
                include ':app'
                """.replace("%NAME%", name));
        Util.write(new File(dir, "build.gradle"), """
                plugins {
                    id 'com.android.application' version '8.5.2' apply false
                }
                """);
        Util.write(new File(dir, "gradle.properties"), """
                android.useAndroidX=false
                android.nonTransitiveRClass=true
                """);
        Util.write(new File(dir, "app/build.gradle"), """
                plugins {
                    id 'com.android.application'
                }

                android {
                    namespace '%PKG%'
                    compileSdk 34

                    defaultConfig {
                        applicationId '%PKG%'
                        minSdk 24
                        targetSdk 34
                        versionCode 1
                        versionName '1.0'
                    }

                    compileOptions {
                        sourceCompatibility JavaVersion.VERSION_17
                        targetCompatibility JavaVersion.VERSION_17
                    }
                }
                """.replace("%PKG%", pkg));
        Util.write(new File(dir, "app/src/main/AndroidManifest.xml"), """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                    <application
                        android:label="@string/app_name"
                        android:theme="@android:style/Theme.Material.Light.DarkActionBar">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
                """);
        Util.write(new File(dir, "app/src/main/res/values/strings.xml"), """
                <?xml version="1.0" encoding="utf-8"?>
                <resources>
                    <string name="app_name">%NAME%</string>
                    <string name="hello">Hello from ApkStudio!</string>
                </resources>
                """.replace("%NAME%", name));
        Util.write(new File(dir, "app/src/main/java/" + pkg.replace('.', '/') + "/MainActivity.java"), """
                package %PKG%;

                import android.app.Activity;
                import android.os.Bundle;
                import android.widget.TextView;

                public class MainActivity extends Activity {
                    @Override
                    protected void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);
                        TextView t = new TextView(this);
                        t.setText(getString(R.string.hello));
                        t.setTextSize(24);
                        t.setPadding(48, 48, 48, 48);
                        setContentView(t);
                    }
                }
                """.replace("%PKG%", pkg));
    }
}
