package app.apkstudio;

import android.app.ActivityManager;
import android.content.Context;
import android.system.Os;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Debian arm64 rootfs run through proot. Gradle, JDK and Android SDK live inside it. */
final class Linux {
    static volatile Process current;

    private static final String JAVA_HOME = "/usr/lib/jvm/java-17-openjdk-arm64";

    private final Context ctx;
    private final File root;
    private final File tmp;
    private final File libDir;
    private final File nativeDir;

    Linux(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        File files = this.ctx.getFilesDir();
        root = new File(files, "rootfs");
        tmp = new File(files, "tmp");
        libDir = new File(files, "lib");
        nativeDir = new File(this.ctx.getApplicationInfo().nativeLibraryDir);
    }

    boolean unpacked() { return new File(root, ".unpacked").exists(); }

    boolean installed() { return new File(root, "opt/.setup-done").exists(); }

    void remove() {
        Util.deleteRecursive(root);
        Util.deleteRecursive(tmp);
    }

    // ---------------------------------------------------------------- rootfs

    void unpack(Runner.Log log) throws Exception {
        if (unpacked()) return;
        Util.deleteRecursive(root);
        root.mkdirs();
        log.log("Распаковка rootfs (один раз)...");
        int n = 0;
        try (InputStream raw = ctx.getAssets().open("rootfs.tar.gz");
             TarArchiveInputStream tar = new TarArchiveInputStream(
                     new GZIPInputStream(new BufferedInputStream(raw, 1 << 16), 1 << 16))) {
            TarArchiveEntry e;
            while ((e = tar.getNextTarEntry()) != null) {
                String name = clean(e.getName());
                if (name.isEmpty() || hasDotDot(name)) continue;
                File f = new File(root, name);
                int mode = e.getMode() & 07777;
                if (e.isDirectory()) {
                    f.mkdirs();
                    Os.chmod(f.getPath(), mode | 0700);
                } else if (e.isSymbolicLink()) {
                    removeEntry(f);
                    mkParent(f);
                    Os.symlink(e.getLinkName(), f.getPath());
                } else if (e.isLink()) {
                    String t = clean(e.getLinkName());
                    if (t.isEmpty() || hasDotDot(t)) continue;
                    removeEntry(f);
                    mkParent(f);
                    try (InputStream in = new FileInputStream(new File(root, t))) {
                        Util.copy(in, f);
                    }
                    Os.chmod(f.getPath(), mode | 0600);
                } else if (e.isFile()) {
                    removeEntry(f);
                    mkParent(f);
                    Util.copy(tar, f);
                    Os.chmod(f.getPath(), mode | 0600);
                }
                if (++n % 3000 == 0) log.log("  ... " + n + " файлов");
            }
        }
        new File(root, ".unpacked").createNewFile();
        log.log("rootfs распакован: " + n + " записей");
    }

    private static String clean(String s) {
        while (s.startsWith("./") || s.startsWith("/")) s = s.substring(s.startsWith("./") ? 2 : 1);
        return s.equals(".") ? "" : s;
    }

    private static boolean hasDotDot(String s) {
        for (String p : s.split("/")) if (p.equals("..")) return true;
        return false;
    }

    private static void removeEntry(File f) {
        if (Files.isSymbolicLink(f.toPath()) || f.isFile()) f.delete();
    }

    private static void mkParent(File f) {
        File p = f.getParentFile();
        if (p != null) p.mkdirs();
    }

    /** Cheap, idempotent preparation done before every proot launch. */
    void prepare() throws Exception {
        tmp.mkdirs();
        libDir.mkdirs();
        File link = new File(libDir, "libtalloc.so.2");
        link.delete();
        Os.symlink(new File(nativeDir, "libtalloc.so").getPath(), link.getPath());

        new File(root, "project").mkdirs();
        new File(root, "opt/native").mkdirs();
        new File(root, "root").mkdirs();
        File rt = new File(root, "tmp");
        rt.mkdirs();
        Os.chmod(rt.getPath(), 01777);

        File resolv = new File(root, "etc/resolv.conf");
        removeEntry(resolv);
        Util.write(resolv, "nameserver 8.8.8.8\nnameserver 1.1.1.1\n");
        File hosts = new File(root, "etc/hosts");
        removeEntry(hosts);
        Util.write(hosts, "127.0.0.1 localhost\n::1 localhost\n");

        for (String s : new String[]{"setup.sh", "build.sh"}) {
            File out = new File(root, "opt/" + s);
            try (InputStream in = ctx.getAssets().open(s)) {
                Util.copy(in, out);
            }
            Os.chmod(out.getPath(), 0755);
        }
    }

    // ---------------------------------------------------------------- exec

    private int heapMb() {
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long mb = mi.totalMem / (1024 * 1024) / 2;
            return (int) Math.max(1024, Math.min(3072, mb));
        } catch (Exception e) {
            return 2048;
        }
    }

    /** Runs a command inside the rootfs. project is bound at /project (may be null). */
    int exec(Runner.Log log, File project, String... guestCmd) throws Exception {
        if (!unpacked()) throw new IOException("rootfs не распакован");
        File proot = new File(nativeDir, "libproot.so");
        if (!proot.exists()) throw new IOException("libproot.so отсутствует в APK");

        List<String> cmd = new ArrayList<>(Arrays.asList(
                proot.getPath(), "-r", root.getPath(), "-0", "--link2symlink", "--kill-on-exit",
                "--kernel-release=6.2.0-ApkStudio",
                "-b", "/dev", "-b", "/proc", "-b", "/sys",
                "-b", nativeDir.getPath() + ":/opt/native"));
        if (project != null) {
            cmd.add("-b");
            cmd.add(project.getPath() + ":/project");
        }
        cmd.addAll(Arrays.asList("-w", "/root", "/usr/bin/env", "-i",
                "HOME=/root", "USER=root", "LANG=C.UTF-8", "TERM=dumb", "TMPDIR=/tmp",
                "PATH=/opt/gradle/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=" + JAVA_HOME,
                "ANDROID_HOME=/opt/android-sdk", "ANDROID_SDK_ROOT=/opt/android-sdk",
                "JAVA_OPTS=-XX:-UseContainerSupport", "GRADLE_OPTS=-XX:-UseContainerSupport",
                "DEBIAN_FRONTEND=noninteractive", "BUILD_XMX=" + heapMb()));
        cmd.addAll(Arrays.asList(guestCmd));

        ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true);
        Map<String, String> env = pb.environment();
        env.put("PROOT_LOADER", new File(nativeDir, "libproot-loader.so").getPath());
        env.put("PROOT_TMP_DIR", tmp.getPath());
        env.put("LD_LIBRARY_PATH", libDir.getPath());
        env.put("PROOT_NO_SECCOMP", "1");

        Process p = pb.start();
        current = p;
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) log.log(line);
        }
        return p.waitFor();
    }

    /** Unpack + prepare + run /opt/setup.sh. */
    void setup(Runner.Log log) throws Exception {
        unpack(log);
        prepare();
        int code = exec(log, null, "/bin/bash", "/opt/setup.sh");
        if (code != 0) throw new IOException("setup.sh завершился с кодом " + code);
    }

    void build(Runner.Log log, File project, List<String> gradleArgs) throws Exception {
        prepare();
        List<String> a = new ArrayList<>(Arrays.asList("/bin/bash", "/opt/build.sh"));
        a.addAll(gradleArgs);
        int code = exec(log, project, a.toArray(new String[0]));
        if (code != 0) throw new IOException("сборка завершилась с кодом " + code);
    }

    void shell(Runner.Log log, File project, String command) throws Exception {
        prepare();
        exec(log, project, "/bin/bash", "-lc", command);
    }
}
